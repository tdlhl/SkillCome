
(define (problem plan_trial_T20190909_193854_783741)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53 - object
        Candle_bar__minus_00_dot_13_bar__plus_00_dot_92_bar__minus_01_dot_46 - object
        Candle_bar__minus_00_dot_24_bar__plus_00_dot_92_bar__minus_01_dot_46 - object
        Candle_bar__minus_00_dot_30_bar__plus_00_dot_76_bar__minus_02_dot_04 - object
        Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57 - object
        Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52 - object
        Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40 - object
        Faucet_bar__minus_00_dot_13_bar__plus_00_dot_71_bar__minus_02_dot_88 - object
        Faucet_bar__minus_02_dot_45_bar__plus_00_dot_94_bar__minus_01_dot_52 - object
        HandTowel_bar__minus_02_dot_50_bar__plus_01_dot_84_bar__minus_00_dot_91 - object
        HousePlant_bar__minus_00_dot_11_bar__plus_00_dot_87_bar__minus_01_dot_65 - object
        LightSwitch_bar__plus_00_dot_00_bar__plus_01_dot_32_bar__minus_01_dot_15 - object
        Mirror_bar__minus_02_dot_51_bar__plus_01_dot_76_bar__minus_01_dot_52 - object
        Plunger_bar__minus_02_dot_37_bar__plus_00_dot_00_bar__minus_00_dot_65 - object
        ScrubBrush_bar__minus_02_dot_11_bar__plus_00_dot_00_bar__minus_00_dot_70 - object
        ShowerCurtain_bar__minus_02_dot_44_bar__plus_01_dot_95_bar__minus_01_dot_92 - object
        Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52 - object
        SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57 - object
        SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34 - object
        SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04 - object
        SoapBottle_bar__minus_00_dot_13_bar__plus_00_dot_72_bar__minus_02_dot_12 - object
        SprayBottle_bar__minus_02_dot_31_bar__plus_01_dot_05_bar__minus_00_dot_49 - object
        SprayBottle_bar__minus_02_dot_34_bar__plus_01_dot_05_bar__minus_00_dot_30 - object
        ToiletPaper_bar__minus_01_dot_49_bar__plus_01_dot_05_bar__minus_00_dot_11 - object
        ToiletPaper_bar__minus_02_dot_34_bar__plus_00_dot_05_bar__minus_01_dot_07 - object
        Towel_bar__minus_02_dot_42_bar__plus_01_dot_54_bar__minus_02_dot_49 - object
        Window_bar__minus_01_dot_29_bar__plus_01_dot_82_bar__minus_03_dot_12 - object
        Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin - receptacle
        Drawer_bar__minus_00_dot_21_bar__plus_00_dot_77_bar__minus_01_dot_46 - receptacle
        GarbageCan_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_01 - receptacle
        HandTowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_94_bar__minus_00_dot_91 - receptacle
        SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46 - receptacle
        Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52_bar_SinkBasin - receptacle
        ToiletPaperHanger_bar__minus_01_dot_43_bar__plus_01_dot_05_bar__plus_00_dot_00 - receptacle
        Toilet_bar__minus_02_dot_05_bar__plus_00_dot_00_bar__minus_00_dot_36 - receptacle
        TowelHolder_bar__plus_00_dot_00_bar__plus_01_dot_53_bar__minus_02_dot_49 - receptacle
        TowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_53_bar__minus_02_dot_49 - receptacle
        loc_bar__minus_7_bar__minus_6_bar_3_bar__minus_15 - location
        loc_bar__minus_5_bar__minus_7_bar_2_bar_0 - location
        loc_bar__minus_3_bar__minus_6_bar_1_bar_60 - location
        loc_bar__minus_2_bar__minus_4_bar_1_bar_30 - location
        loc_bar__minus_3_bar__minus_7_bar_1_bar_15 - location
        loc_bar__minus_4_bar__minus_7_bar_1_bar_45 - location
        loc_bar__minus_7_bar__minus_4_bar_3_bar_60 - location
        loc_bar__minus_7_bar__minus_6_bar_0_bar_60 - location
        loc_bar__minus_6_bar__minus_7_bar_3_bar_0 - location
        loc_bar__minus_5_bar__minus_2_bar_0_bar_45 - location
        loc_bar__minus_7_bar__minus_4_bar_3_bar__minus_15 - location
        loc_bar__minus_5_bar__minus_7_bar_2_bar_60 - location
        loc_bar__minus_7_bar__minus_6_bar_3_bar_60 - location
        loc_bar__minus_4_bar__minus_5_bar_2_bar_30 - location
        )
    

(:init


        (receptacleType TowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_53_bar__minus_02_dot_49 TowelHolderType)
        (receptacleType Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin SinkBasinType)
        (receptacleType Toilet_bar__minus_02_dot_05_bar__plus_00_dot_00_bar__minus_00_dot_36 ToiletType)
        (receptacleType Drawer_bar__minus_00_dot_21_bar__plus_00_dot_77_bar__minus_01_dot_46 DrawerType)
        (receptacleType GarbageCan_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_01 GarbageCanType)
        (receptacleType Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52_bar_SinkBasin SinkBasinType)
        (receptacleType SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46 SideTableType)
        (receptacleType ToiletPaperHanger_bar__minus_01_dot_43_bar__plus_01_dot_05_bar__plus_00_dot_00 ToiletPaperHangerType)
        (receptacleType TowelHolder_bar__plus_00_dot_00_bar__plus_01_dot_53_bar__minus_02_dot_49 TowelHolderType)
        (receptacleType HandTowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_94_bar__minus_00_dot_91 HandTowelHolderType)
        (objectType SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04 SoapBarType)
        (objectType Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52 ClothType)
        (objectType SprayBottle_bar__minus_02_dot_31_bar__plus_01_dot_05_bar__minus_00_dot_49 SprayBottleType)
        (objectType Mirror_bar__minus_02_dot_51_bar__plus_01_dot_76_bar__minus_01_dot_52 MirrorType)
        (objectType Candle_bar__minus_00_dot_13_bar__plus_00_dot_92_bar__minus_01_dot_46 CandleType)
        (objectType ScrubBrush_bar__minus_02_dot_11_bar__plus_00_dot_00_bar__minus_00_dot_70 ScrubBrushType)
        (objectType Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52 SinkType)
        (objectType HousePlant_bar__minus_00_dot_11_bar__plus_00_dot_87_bar__minus_01_dot_65 HousePlantType)
        (objectType Candle_bar__minus_00_dot_30_bar__plus_00_dot_76_bar__minus_02_dot_04 CandleType)
        (objectType SprayBottle_bar__minus_02_dot_34_bar__plus_01_dot_05_bar__minus_00_dot_30 SprayBottleType)
        (objectType ToiletPaper_bar__minus_02_dot_34_bar__plus_00_dot_05_bar__minus_01_dot_07 ToiletPaperType)
        (objectType Candle_bar__minus_00_dot_24_bar__plus_00_dot_92_bar__minus_01_dot_46 CandleType)
        (objectType SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34 SoapBarType)
        (objectType Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57 ClothType)
        (objectType Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53 BathtubType)
        (objectType ToiletPaper_bar__minus_01_dot_49_bar__plus_01_dot_05_bar__minus_00_dot_11 ToiletPaperType)
        (objectType Window_bar__minus_01_dot_29_bar__plus_01_dot_82_bar__minus_03_dot_12 WindowType)
        (objectType Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40 ClothType)
        (objectType HandTowel_bar__minus_02_dot_50_bar__plus_01_dot_84_bar__minus_00_dot_91 HandTowelType)
        (objectType Towel_bar__minus_02_dot_42_bar__plus_01_dot_54_bar__minus_02_dot_49 TowelType)
        (objectType LightSwitch_bar__plus_00_dot_00_bar__plus_01_dot_32_bar__minus_01_dot_15 LightSwitchType)
        (objectType SoapBottle_bar__minus_00_dot_13_bar__plus_00_dot_72_bar__minus_02_dot_12 SoapBottleType)
        (objectType Plunger_bar__minus_02_dot_37_bar__plus_00_dot_00_bar__minus_00_dot_65 PlungerType)
        (objectType SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57 SoapBarType)
        (canContain TowelHolderType TowelType)
        (canContain SinkBasinType SoapBarType)
        (canContain SinkBasinType ClothType)
        (canContain SinkBasinType HandTowelType)
        (canContain ToiletType SoapBottleType)
        (canContain ToiletType HandTowelType)
        (canContain ToiletType ToiletPaperType)
        (canContain ToiletType ClothType)
        (canContain ToiletType CandleType)
        (canContain ToiletType SoapBarType)
        (canContain ToiletType SprayBottleType)
        (canContain DrawerType CandleType)
        (canContain DrawerType SoapBarType)
        (canContain DrawerType SprayBottleType)
        (canContain DrawerType ToiletPaperType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ClothType)
        (canContain DrawerType HandTowelType)
        (canContain GarbageCanType SoapBarType)
        (canContain GarbageCanType SprayBottleType)
        (canContain GarbageCanType ToiletPaperType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType ClothType)
        (canContain GarbageCanType HandTowelType)
        (canContain SinkBasinType SoapBarType)
        (canContain SinkBasinType ClothType)
        (canContain SinkBasinType HandTowelType)
        (canContain SideTableType CandleType)
        (canContain SideTableType SoapBarType)
        (canContain SideTableType SprayBottleType)
        (canContain SideTableType ToiletPaperType)
        (canContain SideTableType SoapBottleType)
        (canContain SideTableType ClothType)
        (canContain SideTableType HandTowelType)
        (canContain ToiletPaperHangerType ToiletPaperType)
        (canContain TowelHolderType TowelType)
        (canContain HandTowelHolderType HandTowelType)
        (pickupable SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04)
        (pickupable Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52)
        (pickupable SprayBottle_bar__minus_02_dot_31_bar__plus_01_dot_05_bar__minus_00_dot_49)
        (pickupable Candle_bar__minus_00_dot_13_bar__plus_00_dot_92_bar__minus_01_dot_46)
        (pickupable ScrubBrush_bar__minus_02_dot_11_bar__plus_00_dot_00_bar__minus_00_dot_70)
        (pickupable Candle_bar__minus_00_dot_30_bar__plus_00_dot_76_bar__minus_02_dot_04)
        (pickupable SprayBottle_bar__minus_02_dot_34_bar__plus_01_dot_05_bar__minus_00_dot_30)
        (pickupable ToiletPaper_bar__minus_02_dot_34_bar__plus_00_dot_05_bar__minus_01_dot_07)
        (pickupable Candle_bar__minus_00_dot_24_bar__plus_00_dot_92_bar__minus_01_dot_46)
        (pickupable SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34)
        (pickupable Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57)
        (pickupable ToiletPaper_bar__minus_01_dot_49_bar__plus_01_dot_05_bar__minus_00_dot_11)
        (pickupable Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40)
        (pickupable HandTowel_bar__minus_02_dot_50_bar__plus_01_dot_84_bar__minus_00_dot_91)
        (pickupable Towel_bar__minus_02_dot_42_bar__plus_01_dot_54_bar__minus_02_dot_49)
        (pickupable SoapBottle_bar__minus_00_dot_13_bar__plus_00_dot_72_bar__minus_02_dot_12)
        (pickupable Plunger_bar__minus_02_dot_37_bar__plus_00_dot_00_bar__minus_00_dot_65)
        (pickupable SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57)
        
        (openable Drawer_bar__minus_00_dot_21_bar__plus_00_dot_77_bar__minus_01_dot_46)
        
        (atLocation agent1 loc_bar__minus_4_bar__minus_5_bar_2_bar_30)
        
        (cleanable SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04)
        (cleanable Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52)
        (cleanable SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34)
        (cleanable Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57)
        (cleanable Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40)
        (cleanable SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57)
        
        
        
        
        
        
        
        
        
        
        (inReceptacle HousePlant_bar__minus_00_dot_11_bar__plus_00_dot_87_bar__minus_01_dot_65 SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46)
        (inReceptacle Candle_bar__minus_00_dot_24_bar__plus_00_dot_92_bar__minus_01_dot_46 SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46)
        (inReceptacle Candle_bar__minus_00_dot_13_bar__plus_00_dot_92_bar__minus_01_dot_46 SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46)
        (inReceptacle Towel_bar__minus_02_dot_42_bar__plus_01_dot_54_bar__minus_02_dot_49 TowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_53_bar__minus_02_dot_49)
        (inReceptacle ToiletPaper_bar__minus_01_dot_49_bar__plus_01_dot_05_bar__minus_00_dot_11 ToiletPaperHanger_bar__minus_01_dot_43_bar__plus_01_dot_05_bar__plus_00_dot_00)
        (inReceptacle HandTowel_bar__minus_02_dot_50_bar__plus_01_dot_84_bar__minus_00_dot_91 HandTowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_94_bar__minus_00_dot_91)
        (inReceptacle SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04 GarbageCan_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_01)
        (inReceptacle ToiletPaper_bar__minus_02_dot_34_bar__plus_00_dot_05_bar__minus_01_dot_07 GarbageCan_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_01)
        (inReceptacle Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57 Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin)
        (inReceptacle Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52 Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin)
        (inReceptacle Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40 Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin)
        (inReceptacle SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57 Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin)
        (inReceptacle SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34 Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin)
        (inReceptacle SprayBottle_bar__minus_02_dot_34_bar__plus_01_dot_05_bar__minus_00_dot_30 Toilet_bar__minus_02_dot_05_bar__plus_00_dot_00_bar__minus_00_dot_36)
        (inReceptacle SprayBottle_bar__minus_02_dot_31_bar__plus_01_dot_05_bar__minus_00_dot_49 Toilet_bar__minus_02_dot_05_bar__plus_00_dot_00_bar__minus_00_dot_36)
        
        
        (receptacleAtLocation Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53_bar_SinkBasin loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__minus_00_dot_21_bar__plus_00_dot_77_bar__minus_01_dot_46 loc_bar__minus_4_bar__minus_7_bar_1_bar_45)
        (receptacleAtLocation GarbageCan_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_01 loc_bar__minus_7_bar__minus_4_bar_3_bar_60)
        (receptacleAtLocation HandTowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_94_bar__minus_00_dot_91 loc_bar__minus_7_bar__minus_4_bar_3_bar__minus_15)
        (receptacleAtLocation SideTable_bar__minus_00_dot_16_bar__plus_00_dot_00_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_6_bar_1_bar_60)
        (receptacleAtLocation Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52_bar_SinkBasin loc_bar__minus_7_bar__minus_6_bar_3_bar_60)
        (receptacleAtLocation ToiletPaperHanger_bar__minus_01_dot_43_bar__plus_01_dot_05_bar__plus_00_dot_00 loc_bar__minus_5_bar__minus_2_bar_0_bar_45)
        (receptacleAtLocation Toilet_bar__minus_02_dot_05_bar__plus_00_dot_00_bar__minus_00_dot_36 loc_bar__minus_7_bar__minus_6_bar_0_bar_60)
        (receptacleAtLocation TowelHolder_bar__plus_00_dot_00_bar__plus_01_dot_53_bar__minus_02_dot_49 loc_bar__minus_3_bar__minus_7_bar_1_bar_15)
        (receptacleAtLocation TowelHolder_bar__minus_02_dot_53_bar__plus_01_dot_53_bar__minus_02_dot_49 loc_bar__minus_6_bar__minus_7_bar_3_bar_0)
        (objectAtLocation SprayBottle_bar__minus_02_dot_31_bar__plus_01_dot_05_bar__minus_00_dot_49 loc_bar__minus_7_bar__minus_6_bar_0_bar_60)
        (objectAtLocation Cloth_bar__minus_01_dot_01_bar__plus_00_dot_29_bar__minus_02_dot_57 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation SoapBar_bar__minus_02_dot_04_bar__plus_00_dot_29_bar__minus_02_dot_34 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation SoapBar_bar__minus_02_dot_28_bar__plus_00_dot_05_bar__minus_01_dot_04 loc_bar__minus_7_bar__minus_4_bar_3_bar_60)
        (objectAtLocation Candle_bar__minus_00_dot_13_bar__plus_00_dot_92_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_6_bar_1_bar_60)
        (objectAtLocation Cloth_bar__minus_01_dot_52_bar__plus_00_dot_29_bar__minus_02_dot_52 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation Bathtub_bar__minus_01_dot_28_bar__plus_00_dot_28_bar__minus_02_dot_53 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation Mirror_bar__minus_02_dot_51_bar__plus_01_dot_76_bar__minus_01_dot_52 loc_bar__minus_7_bar__minus_6_bar_3_bar__minus_15)
        (objectAtLocation Sink_bar__minus_02_dot_27_bar__plus_00_dot_00_bar__minus_01_dot_52 loc_bar__minus_7_bar__minus_6_bar_3_bar_60)
        (objectAtLocation Towel_bar__minus_02_dot_42_bar__plus_01_dot_54_bar__minus_02_dot_49 loc_bar__minus_6_bar__minus_7_bar_3_bar_0)
        (objectAtLocation Candle_bar__minus_00_dot_24_bar__plus_00_dot_92_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_6_bar_1_bar_60)
        (objectAtLocation HandTowel_bar__minus_02_dot_50_bar__plus_01_dot_84_bar__minus_00_dot_91 loc_bar__minus_7_bar__minus_4_bar_3_bar__minus_15)
        (objectAtLocation Plunger_bar__minus_02_dot_37_bar__plus_00_dot_00_bar__minus_00_dot_65 loc_bar__minus_7_bar__minus_4_bar_3_bar_60)
        (objectAtLocation SoapBar_bar__minus_00_dot_76_bar__plus_00_dot_29_bar__minus_02_dot_57 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation ToiletPaper_bar__minus_01_dot_49_bar__plus_01_dot_05_bar__minus_00_dot_11 loc_bar__minus_5_bar__minus_2_bar_0_bar_45)
        (objectAtLocation LightSwitch_bar__plus_00_dot_00_bar__plus_01_dot_32_bar__minus_01_dot_15 loc_bar__minus_2_bar__minus_4_bar_1_bar_30)
        (objectAtLocation Cloth_bar__minus_01_dot_78_bar__plus_00_dot_29_bar__minus_02_dot_40 loc_bar__minus_5_bar__minus_7_bar_2_bar_60)
        (objectAtLocation ToiletPaper_bar__minus_02_dot_34_bar__plus_00_dot_05_bar__minus_01_dot_07 loc_bar__minus_7_bar__minus_4_bar_3_bar_60)
        (objectAtLocation Window_bar__minus_01_dot_29_bar__plus_01_dot_82_bar__minus_03_dot_12 loc_bar__minus_5_bar__minus_7_bar_2_bar_0)
        (objectAtLocation SprayBottle_bar__minus_02_dot_34_bar__plus_01_dot_05_bar__minus_00_dot_30 loc_bar__minus_7_bar__minus_6_bar_0_bar_60)
        (objectAtLocation ScrubBrush_bar__minus_02_dot_11_bar__plus_00_dot_00_bar__minus_00_dot_70 loc_bar__minus_7_bar__minus_4_bar_3_bar_60)
        (objectAtLocation HousePlant_bar__minus_00_dot_11_bar__plus_00_dot_87_bar__minus_01_dot_65 loc_bar__minus_3_bar__minus_6_bar_1_bar_60)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (exists (?o1 - object)
                                (and
                                    (objectType ?o1 ToiletPaperType)
                                    (receptacleType ?r SideTableType)
                                    (inReceptacle ?o1 ?r)
                                    (exists (?o2 - object)
                                        (and
                                            (not (= ?o1 ?o2))
                                            (objectType ?o2 ToiletPaperType)
                                            (receptacleType ?r SideTableType)
                                            (inReceptacle ?o2 ?r)
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            