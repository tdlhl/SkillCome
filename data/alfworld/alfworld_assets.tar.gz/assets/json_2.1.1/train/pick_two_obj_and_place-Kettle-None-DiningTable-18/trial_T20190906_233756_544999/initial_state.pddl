
(define (problem plan_trial_T20190906_233756_544999)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21 - object
        Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47 - object
        Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25 - object
        Blinds_bar__plus_01_dot_74_bar__plus_02_dot_56_bar__plus_02_dot_31 - object
        Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11 - object
        Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30 - object
        Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35 - object
        Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32 - object
        ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28 - object
        ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58 - object
        Chair_bar__plus_00_dot_29_bar__plus_00_dot_02_bar__plus_06_dot_14 - object
        Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38 - object
        Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25 - object
        Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94 - object
        DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41 - object
        Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18 - object
        Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88 - object
        Faucet_bar__plus_01_dot_54_bar__plus_01_dot_03_bar__plus_02_dot_37 - object
        Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74 - object
        Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40 - object
        HousePlant_bar__minus_00_dot_17_bar__plus_00_dot_75_bar__plus_06_dot_44 - object
        Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51 - object
        Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44 - object
        Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29 - object
        Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22 - object
        Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56 - object
        Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76 - object
        Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00 - object
        Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58 - object
        LightSwitch_bar__minus_02_dot_00_bar__plus_01_dot_55_bar__plus_06_dot_05 - object
        Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85 - object
        Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85 - object
        Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29 - object
        PaperTowelRoll_bar__minus_00_dot_10_bar__plus_00_dot_86_bar__plus_06_dot_94 - object
        PepperShaker_bar__plus_00_dot_17_bar__plus_01_dot_57_bar__plus_00_dot_30 - object
        Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79 - object
        Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98 - object
        Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47 - object
        Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79 - object
        Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38 - object
        SaltShaker_bar__plus_00_dot_15_bar__plus_00_dot_76_bar__plus_06_dot_35 - object
        SaltShaker_bar__minus_00_dot_44_bar__plus_00_dot_76_bar__plus_06_dot_85 - object
        Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33 - object
        SoapBottle_bar__plus_01_dot_67_bar__plus_00_dot_99_bar__plus_00_dot_21 - object
        SoapBottle_bar__plus_02_dot_06_bar__plus_00_dot_08_bar__plus_06_dot_47 - object
        Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79 - object
        Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75 - object
        Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56 - object
        Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35 - object
        StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_82 - object
        StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_99 - object
        StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_14 - object
        StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_31 - object
        Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24 - object
        Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03 - object
        Window_bar__plus_01_dot_76_bar__plus_02_dot_01_bar__plus_02_dot_30 - object
        Window_bar__minus_02_dot_07_bar__plus_01_dot_92_bar__plus_03_dot_63 - object
        Cabinet_bar__plus_00_dot_25_bar__plus_02_dot_13_bar__plus_00_dot_43 - receptacle
        Cabinet_bar__plus_00_dot_44_bar__plus_00_dot_42_bar__plus_00_dot_74 - receptacle
        Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_01_dot_71 - receptacle
        Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_94 - receptacle
        Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_99 - receptacle
        Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_04_dot_55 - receptacle
        Cabinet_bar__plus_01_dot_27_bar__plus_02_dot_13_bar__plus_00_dot_43 - receptacle
        Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_03_dot_61 - receptacle
        Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_04_dot_36 - receptacle
        Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_00_dot_52 - receptacle
        Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_01_dot_53 - receptacle
        Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_03_dot_10 - receptacle
        Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_04_dot_89 - receptacle
        Cabinet_bar__minus_00_dot_17_bar__plus_00_dot_42_bar__plus_00_dot_74 - receptacle
        Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43 - receptacle
        Cabinet_bar__minus_00_dot_78_bar__plus_00_dot_42_bar__plus_00_dot_74 - receptacle
        CoffeeMachine_bar__plus_01_dot_55_bar__plus_00_dot_98_bar__plus_00_dot_95 - receptacle
        CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90 - receptacle
        CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_04_dot_72 - receptacle
        DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47 - receptacle
        Drawer_bar__plus_00_dot_12_bar__plus_00_dot_80_bar__plus_00_dot_52 - receptacle
        Drawer_bar__plus_00_dot_74_bar__plus_00_dot_80_bar__plus_00_dot_52 - receptacle
        Drawer_bar__plus_01_dot_28_bar__plus_00_dot_80_bar__plus_03_dot_29 - receptacle
        Drawer_bar__plus_01_dot_28_bar__plus_00_dot_81_bar__plus_04_dot_72 - receptacle
        Drawer_bar__minus_00_dot_48_bar__plus_00_dot_80_bar__plus_00_dot_52 - receptacle
        Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63 - receptacle
        GarbageCan_bar__plus_02_dot_00_bar__plus_00_dot_00_bar__plus_06_dot_50 - receptacle
        Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26 - receptacle
        Safe_bar__plus_02_dot_05_bar__minus_00_dot_01_bar__plus_07_dot_06 - receptacle
        Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin - receptacle
        StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_03_dot_85 - receptacle
        StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_04_dot_29 - receptacle
        StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_03_dot_85 - receptacle
        StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_04_dot_29 - receptacle
        Toaster_bar__plus_01_dot_47_bar__plus_00_dot_98_bar__plus_04_dot_72 - receptacle
        loc_bar_3_bar_5_bar_1_bar__minus_30 - location
        loc_bar_2_bar_4_bar_2_bar__minus_30 - location
        loc_bar_0_bar_4_bar_2_bar__minus_30 - location
        loc_bar__minus_1_bar_7_bar_2_bar_45 - location
        loc_bar_3_bar_14_bar_1_bar__minus_30 - location
        loc_bar_4_bar_22_bar_1_bar_60 - location
        loc_bar__minus_6_bar_15_bar_3_bar__minus_30 - location
        loc_bar_3_bar_15_bar_1_bar_45 - location
        loc_bar_1_bar_10_bar_1_bar_60 - location
        loc_bar_3_bar_16_bar_1_bar_60 - location
        loc_bar_3_bar_18_bar_1_bar__minus_30 - location
        loc_bar_3_bar_17_bar_1_bar__minus_30 - location
        loc_bar_1_bar_13_bar_1_bar_45 - location
        loc_bar_3_bar_4_bar_1_bar__minus_30 - location
        loc_bar__minus_5_bar_5_bar_1_bar_45 - location
        loc_bar_0_bar_7_bar_2_bar_45 - location
        loc_bar__minus_6_bar_24_bar_3_bar_15 - location
        loc_bar_3_bar_9_bar_1_bar__minus_30 - location
        loc_bar_4_bar_24_bar_1_bar_60 - location
        loc_bar_3_bar_17_bar_1_bar_60 - location
        loc_bar_1_bar_14_bar_1_bar_60 - location
        loc_bar_3_bar_9_bar_1_bar__minus_15 - location
        loc_bar_1_bar_20_bar_1_bar_45 - location
        loc_bar__minus_3_bar_5_bar_1_bar_45 - location
        loc_bar_3_bar_9_bar_1_bar_45 - location
        loc_bar_3_bar_17_bar_1_bar_45 - location
        loc_bar_1_bar_17_bar_1_bar_60 - location
        loc_bar_4_bar_26_bar_1_bar_60 - location
        loc_bar_1_bar_22_bar_0_bar_60 - location
        loc_bar_0_bar_5_bar_1_bar_45 - location
        loc_bar_3_bar_15_bar_1_bar_60 - location
        loc_bar_1_bar_6_bar_2_bar_30 - location
        loc_bar_1_bar_7_bar_2_bar_45 - location
        loc_bar_3_bar_4_bar_1_bar_45 - location
        loc_bar_1_bar_7_bar_1_bar_60 - location
        loc_bar_3_bar_26_bar_3_bar_45 - location
        loc_bar_3_bar_19_bar_1_bar_45 - location
        loc_bar_3_bar_4_bar_2_bar__minus_30 - location
        loc_bar__minus_6_bar_17_bar_2_bar_30 - location
        )
    

(:init


        (receptacleType Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_99 CabinetType)
        (receptacleType Drawer_bar__plus_00_dot_12_bar__plus_00_dot_80_bar__plus_00_dot_52 DrawerType)
        (receptacleType CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90 CounterTopType)
        (receptacleType Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin SinkBasinType)
        (receptacleType Cabinet_bar__plus_01_dot_27_bar__plus_02_dot_13_bar__plus_00_dot_43 CabinetType)
        (receptacleType StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_04_dot_29 StoveBurnerType)
        (receptacleType StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_03_dot_85 StoveBurnerType)
        (receptacleType Cabinet_bar__minus_00_dot_17_bar__plus_00_dot_42_bar__plus_00_dot_74 CabinetType)
        (receptacleType Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_01_dot_71 CabinetType)
        (receptacleType GarbageCan_bar__plus_02_dot_00_bar__plus_00_dot_00_bar__plus_06_dot_50 GarbageCanType)
        (receptacleType Drawer_bar__plus_00_dot_74_bar__plus_00_dot_80_bar__plus_00_dot_52 DrawerType)
        (receptacleType Safe_bar__plus_02_dot_05_bar__minus_00_dot_01_bar__plus_07_dot_06 SafeType)
        (receptacleType StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_04_dot_29 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_44_bar__plus_00_dot_42_bar__plus_00_dot_74 CabinetType)
        (receptacleType DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47 DiningTableType)
        (receptacleType Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_04_dot_55 CabinetType)
        (receptacleType Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_04_dot_89 CabinetType)
        (receptacleType Drawer_bar__minus_00_dot_48_bar__plus_00_dot_80_bar__plus_00_dot_52 DrawerType)
        (receptacleType CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_04_dot_72 CounterTopType)
        (receptacleType Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_01_dot_53 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_28_bar__plus_00_dot_80_bar__plus_03_dot_29 DrawerType)
        (receptacleType Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_94 CabinetType)
        (receptacleType StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_03_dot_85 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_03_dot_61 CabinetType)
        (receptacleType Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_04_dot_36 CabinetType)
        (receptacleType Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43 CabinetType)
        (receptacleType Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_00_dot_52 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_25_bar__plus_02_dot_13_bar__plus_00_dot_43 CabinetType)
        (receptacleType Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_03_dot_10 CabinetType)
        (receptacleType Toaster_bar__plus_01_dot_47_bar__plus_00_dot_98_bar__plus_04_dot_72 ToasterType)
        (receptacleType Drawer_bar__plus_01_dot_28_bar__plus_00_dot_81_bar__plus_04_dot_72 DrawerType)
        (receptacleType CoffeeMachine_bar__plus_01_dot_55_bar__plus_00_dot_98_bar__plus_00_dot_95 CoffeeMachineType)
        (receptacleType Cabinet_bar__minus_00_dot_78_bar__plus_00_dot_42_bar__plus_00_dot_74 CabinetType)
        (receptacleType Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63 FridgeType)
        (receptacleType Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26 MicrowaveType)
        (objectType Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38 PotType)
        (objectType Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58 LettuceType)
        (objectType Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35 BowlType)
        (objectType Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51 KettleType)
        (objectType SaltShaker_bar__plus_00_dot_15_bar__plus_00_dot_76_bar__plus_06_dot_35 SaltShakerType)
        (objectType Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85 PanType)
        (objectType StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_99 StoveKnobType)
        (objectType Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98 PotatoType)
        (objectType SoapBottle_bar__plus_02_dot_06_bar__plus_00_dot_08_bar__plus_06_dot_47 SoapBottleType)
        (objectType SaltShaker_bar__minus_00_dot_44_bar__plus_00_dot_76_bar__plus_06_dot_85 SaltShakerType)
        (objectType Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29 KettleType)
        (objectType SoapBottle_bar__plus_01_dot_67_bar__plus_00_dot_99_bar__plus_00_dot_21 SoapBottleType)
        (objectType ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28 ButterKnifeType)
        (objectType StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_82 StoveKnobType)
        (objectType Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76 KnifeType)
        (objectType Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79 PlateType)
        (objectType Chair_bar__plus_00_dot_29_bar__plus_00_dot_02_bar__plus_06_dot_14 ChairType)
        (objectType Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74 ForkType)
        (objectType Blinds_bar__plus_01_dot_74_bar__plus_02_dot_56_bar__plus_02_dot_31 BlindsType)
        (objectType Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32 BreadType)
        (objectType Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85 MugType)
        (objectType StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_31 StoveKnobType)
        (objectType Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88 EggType)
        (objectType Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79 SpatulaType)
        (objectType Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25 CupType)
        (objectType Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38 CupType)
        (objectType HousePlant_bar__minus_00_dot_17_bar__plus_00_dot_75_bar__plus_06_dot_44 HousePlantType)
        (objectType Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47 AppleType)
        (objectType LightSwitch_bar__minus_02_dot_00_bar__plus_01_dot_55_bar__plus_06_dot_05 LightSwitchType)
        (objectType Window_bar__minus_02_dot_07_bar__plus_01_dot_92_bar__plus_03_dot_63 WindowType)
        (objectType Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21 AppleType)
        (objectType Window_bar__plus_01_dot_76_bar__plus_02_dot_01_bar__plus_02_dot_30 WindowType)
        (objectType Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24 TomatoType)
        (objectType PepperShaker_bar__plus_00_dot_17_bar__plus_01_dot_57_bar__plus_00_dot_30 PepperShakerType)
        (objectType Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11 BowlType)
        (objectType Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33 SinkType)
        (objectType Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22 KettleType)
        (objectType StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_14 StoveKnobType)
        (objectType Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29 PanType)
        (objectType Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94 CupType)
        (objectType Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75 SpoonType)
        (objectType Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30 BowlType)
        (objectType Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79 PotatoType)
        (objectType Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03 TomatoType)
        (objectType Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56 SpoonType)
        (objectType Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56 KnifeType)
        (objectType Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47 PotatoType)
        (objectType PaperTowelRoll_bar__minus_00_dot_10_bar__plus_00_dot_86_bar__plus_06_dot_94 PaperTowelRollType)
        (objectType Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40 ForkType)
        (objectType DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41 DishSpongeType)
        (objectType Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25 AppleType)
        (objectType Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44 KettleType)
        (objectType ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58 ButterKnifeType)
        (objectType Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00 LettuceType)
        (objectType Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35 SpoonType)
        (objectType Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18 EggType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType KettleType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType KettleType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType LettuceType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType LettuceType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType AppleType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DiningTableType SaltShakerType)
        (canContain DiningTableType BreadType)
        (canContain DiningTableType DishSpongeType)
        (canContain DiningTableType BowlType)
        (canContain DiningTableType KettleType)
        (canContain DiningTableType PotType)
        (canContain DiningTableType MugType)
        (canContain DiningTableType EggType)
        (canContain DiningTableType ForkType)
        (canContain DiningTableType SpoonType)
        (canContain DiningTableType SoapBottleType)
        (canContain DiningTableType LettuceType)
        (canContain DiningTableType PotatoType)
        (canContain DiningTableType ButterKnifeType)
        (canContain DiningTableType CupType)
        (canContain DiningTableType PlateType)
        (canContain DiningTableType PepperShakerType)
        (canContain DiningTableType TomatoType)
        (canContain DiningTableType KnifeType)
        (canContain DiningTableType AppleType)
        (canContain DiningTableType PanType)
        (canContain DiningTableType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType KettleType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CoffeeMachineType MugType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain FridgeType BreadType)
        (canContain FridgeType BowlType)
        (canContain FridgeType PotType)
        (canContain FridgeType MugType)
        (canContain FridgeType EggType)
        (canContain FridgeType LettuceType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType CupType)
        (canContain FridgeType PlateType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType PanType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BreadType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType BowlType)
        (pickupable Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38)
        (pickupable Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58)
        (pickupable Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35)
        (pickupable Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51)
        (pickupable SaltShaker_bar__plus_00_dot_15_bar__plus_00_dot_76_bar__plus_06_dot_35)
        (pickupable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85)
        (pickupable Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98)
        (pickupable SoapBottle_bar__plus_02_dot_06_bar__plus_00_dot_08_bar__plus_06_dot_47)
        (pickupable SaltShaker_bar__minus_00_dot_44_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (pickupable Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (pickupable SoapBottle_bar__plus_01_dot_67_bar__plus_00_dot_99_bar__plus_00_dot_21)
        (pickupable ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28)
        (pickupable Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76)
        (pickupable Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79)
        (pickupable Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74)
        (pickupable Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32)
        (pickupable Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (pickupable Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88)
        (pickupable Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79)
        (pickupable Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25)
        (pickupable Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38)
        (pickupable Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47)
        (pickupable Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21)
        (pickupable Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24)
        (pickupable PepperShaker_bar__plus_00_dot_17_bar__plus_01_dot_57_bar__plus_00_dot_30)
        (pickupable Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11)
        (pickupable Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22)
        (pickupable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (pickupable Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94)
        (pickupable Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75)
        (pickupable Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30)
        (pickupable Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79)
        (pickupable Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03)
        (pickupable Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56)
        (pickupable Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56)
        (pickupable Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47)
        (pickupable PaperTowelRoll_bar__minus_00_dot_10_bar__plus_00_dot_86_bar__plus_06_dot_94)
        (pickupable Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40)
        (pickupable DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41)
        (pickupable Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25)
        (pickupable Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44)
        (pickupable ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58)
        (pickupable Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00)
        (pickupable Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35)
        (pickupable Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18)
        (isReceptacleObject Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38)
        (isReceptacleObject Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35)
        (isReceptacleObject Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85)
        (isReceptacleObject Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79)
        (isReceptacleObject Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (isReceptacleObject Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25)
        (isReceptacleObject Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38)
        (isReceptacleObject Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11)
        (isReceptacleObject Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (isReceptacleObject Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94)
        (isReceptacleObject Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30)
        (openable Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_99)
        (openable Drawer_bar__plus_00_dot_12_bar__plus_00_dot_80_bar__plus_00_dot_52)
        (openable Cabinet_bar__plus_01_dot_27_bar__plus_02_dot_13_bar__plus_00_dot_43)
        (openable Cabinet_bar__minus_00_dot_17_bar__plus_00_dot_42_bar__plus_00_dot_74)
        (openable Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_01_dot_71)
        (openable Drawer_bar__plus_00_dot_74_bar__plus_00_dot_80_bar__plus_00_dot_52)
        (openable Safe_bar__plus_02_dot_05_bar__minus_00_dot_01_bar__plus_07_dot_06)
        (openable Cabinet_bar__plus_00_dot_44_bar__plus_00_dot_42_bar__plus_00_dot_74)
        (openable Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_04_dot_55)
        (openable Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_04_dot_89)
        (openable Drawer_bar__minus_00_dot_48_bar__plus_00_dot_80_bar__plus_00_dot_52)
        (openable Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_01_dot_53)
        (openable Drawer_bar__plus_01_dot_28_bar__plus_00_dot_80_bar__plus_03_dot_29)
        (openable Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_94)
        (openable Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43)
        (openable Cabinet_bar__plus_00_dot_25_bar__plus_02_dot_13_bar__plus_00_dot_43)
        (openable Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_03_dot_10)
        (openable Drawer_bar__plus_01_dot_28_bar__plus_00_dot_81_bar__plus_04_dot_72)
        (openable Cabinet_bar__minus_00_dot_78_bar__plus_00_dot_42_bar__plus_00_dot_74)
        (openable Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (openable Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26)
        
        (atLocation agent1 loc_bar__minus_6_bar_17_bar_2_bar_30)
        
        (cleanable Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38)
        (cleanable Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58)
        (cleanable Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35)
        (cleanable Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51)
        (cleanable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85)
        (cleanable Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98)
        (cleanable Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (cleanable ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28)
        (cleanable Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76)
        (cleanable Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79)
        (cleanable Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74)
        (cleanable Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (cleanable Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88)
        (cleanable Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79)
        (cleanable Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25)
        (cleanable Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38)
        (cleanable Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47)
        (cleanable Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21)
        (cleanable Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24)
        (cleanable Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11)
        (cleanable Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22)
        (cleanable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (cleanable Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94)
        (cleanable Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75)
        (cleanable Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30)
        (cleanable Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79)
        (cleanable Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03)
        (cleanable Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56)
        (cleanable Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56)
        (cleanable Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47)
        (cleanable Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40)
        (cleanable DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41)
        (cleanable Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25)
        (cleanable Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44)
        (cleanable ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58)
        (cleanable Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00)
        (cleanable Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35)
        (cleanable Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18)
        
        (heatable Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98)
        (heatable Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79)
        (heatable Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32)
        (heatable Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (heatable Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88)
        (heatable Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25)
        (heatable Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38)
        (heatable Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47)
        (heatable Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21)
        (heatable Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24)
        (heatable Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94)
        (heatable Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79)
        (heatable Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03)
        (heatable Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47)
        (heatable Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25)
        (heatable Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18)
        (coolable Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38)
        (coolable Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58)
        (coolable Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35)
        (coolable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85)
        (coolable Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98)
        (coolable Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79)
        (coolable Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32)
        (coolable Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85)
        (coolable Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88)
        (coolable Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25)
        (coolable Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38)
        (coolable Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47)
        (coolable Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21)
        (coolable Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24)
        (coolable Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11)
        (coolable Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29)
        (coolable Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94)
        (coolable Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30)
        (coolable Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79)
        (coolable Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03)
        (coolable Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47)
        (coolable Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25)
        (coolable Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00)
        (coolable Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18)
        
        
        
        
        
        (sliceable Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58)
        (sliceable Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98)
        (sliceable Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32)
        (sliceable Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88)
        (sliceable Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47)
        (sliceable Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21)
        (sliceable Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24)
        (sliceable Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79)
        (sliceable Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03)
        (sliceable Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47)
        (sliceable Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25)
        (sliceable Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00)
        (sliceable Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18)
        
        (inReceptacle Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75 Drawer_bar__plus_01_dot_28_bar__plus_00_dot_81_bar__plus_04_dot_72)
        (inReceptacle Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56 Drawer_bar__plus_00_dot_74_bar__plus_00_dot_80_bar__plus_00_dot_52)
        (inReceptacle Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85 StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_03_dot_85)
        (inReceptacle Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle PaperTowelRoll_bar__minus_00_dot_10_bar__plus_00_dot_86_bar__plus_06_dot_94 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle SaltShaker_bar__plus_00_dot_15_bar__plus_00_dot_76_bar__plus_06_dot_35 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle HousePlant_bar__minus_00_dot_17_bar__plus_00_dot_75_bar__plus_06_dot_44 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle SaltShaker_bar__minus_00_dot_44_bar__plus_00_dot_76_bar__plus_06_dot_85 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85 DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47)
        (inReceptacle Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29 StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_04_dot_29)
        (inReceptacle Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56 Drawer_bar__minus_00_dot_48_bar__plus_00_dot_80_bar__plus_00_dot_52)
        (inReceptacle Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29 StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_04_dot_29)
        (inReceptacle Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle SoapBottle_bar__plus_01_dot_67_bar__plus_00_dot_99_bar__plus_00_dot_21 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32 CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90)
        (inReceptacle Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35 Cabinet_bar__minus_00_dot_78_bar__plus_00_dot_42_bar__plus_00_dot_74)
        (inReceptacle Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51 Cabinet_bar__minus_00_dot_17_bar__plus_00_dot_42_bar__plus_00_dot_74)
        (inReceptacle DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41 Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_01_dot_53)
        (inReceptacle Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22 Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_99)
        (inReceptacle Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79 Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_94)
        (inReceptacle PepperShaker_bar__plus_00_dot_17_bar__plus_01_dot_57_bar__plus_00_dot_30 Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43)
        (inReceptacle Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30 Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43)
        (inReceptacle Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21 Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26)
        (inReceptacle Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18 Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26)
        (inReceptacle Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88 Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (inReceptacle Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25 Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (inReceptacle Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38 Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (inReceptacle Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25 Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (inReceptacle Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00 Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63)
        (inReceptacle Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03 Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin)
        (inReceptacle Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47 Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin)
        (inReceptacle Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98 Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin)
        (inReceptacle SoapBottle_bar__plus_02_dot_06_bar__plus_00_dot_08_bar__plus_06_dot_47 GarbageCan_bar__plus_02_dot_00_bar__plus_00_dot_00_bar__plus_06_dot_50)
        (inReceptacle Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47 GarbageCan_bar__plus_02_dot_00_bar__plus_00_dot_00_bar__plus_06_dot_50)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_25_bar__plus_02_dot_13_bar__plus_00_dot_43 loc_bar_2_bar_4_bar_2_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_44_bar__plus_00_dot_42_bar__plus_00_dot_74 loc_bar_1_bar_7_bar_2_bar_45)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_01_dot_71 loc_bar_1_bar_7_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_94 loc_bar_1_bar_10_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_02_dot_99 loc_bar_1_bar_14_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_05_bar__plus_00_dot_42_bar__plus_04_dot_55 loc_bar_1_bar_17_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_27_bar__plus_02_dot_13_bar__plus_00_dot_43 loc_bar_3_bar_4_bar_2_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_03_dot_61 loc_bar_3_bar_14_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_31_bar__plus_02_dot_46_bar__plus_04_dot_36 loc_bar_3_bar_17_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_00_dot_52 loc_bar_3_bar_4_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_01_dot_53 loc_bar_3_bar_5_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_03_dot_10 loc_bar_3_bar_14_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_32_bar__plus_02_dot_13_bar__plus_04_dot_89 loc_bar_3_bar_18_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_17_bar__plus_00_dot_42_bar__plus_00_dot_74 loc_bar__minus_1_bar_7_bar_2_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_26_bar__plus_02_dot_13_bar__plus_00_dot_43 loc_bar_0_bar_4_bar_2_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_78_bar__plus_00_dot_42_bar__plus_00_dot_74 loc_bar_0_bar_7_bar_2_bar_45)
        (receptacleAtLocation CoffeeMachine_bar__plus_01_dot_55_bar__plus_00_dot_98_bar__plus_00_dot_95 loc_bar_3_bar_4_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_00_dot_90 loc_bar_3_bar_4_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_01_dot_39_bar__plus_01_dot_03_bar__plus_04_dot_72 loc_bar_3_bar_19_bar_1_bar_45)
        (receptacleAtLocation DiningTable_bar__minus_00_dot_16_bar__plus_00_dot_67_bar__plus_06_dot_47 loc_bar_3_bar_26_bar_3_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_12_bar__plus_00_dot_80_bar__plus_00_dot_52 loc_bar__minus_3_bar_5_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_74_bar__plus_00_dot_80_bar__plus_00_dot_52 loc_bar_0_bar_5_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__plus_01_dot_28_bar__plus_00_dot_80_bar__plus_03_dot_29 loc_bar_1_bar_13_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__plus_01_dot_28_bar__plus_00_dot_81_bar__plus_04_dot_72 loc_bar_1_bar_20_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__minus_00_dot_48_bar__plus_00_dot_80_bar__plus_00_dot_52 loc_bar__minus_5_bar_5_bar_1_bar_45)
        (receptacleAtLocation Fridge_bar__plus_02_dot_04_bar__plus_00_dot_00_bar__plus_05_dot_63 loc_bar_4_bar_22_bar_1_bar_60)
        (receptacleAtLocation GarbageCan_bar__plus_02_dot_00_bar__plus_00_dot_00_bar__plus_06_dot_50 loc_bar_4_bar_24_bar_1_bar_60)
        (receptacleAtLocation Microwave_bar__plus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_26 loc_bar_1_bar_6_bar_2_bar_30)
        (receptacleAtLocation Safe_bar__plus_02_dot_05_bar__minus_00_dot_01_bar__plus_07_dot_06 loc_bar_4_bar_26_bar_1_bar_60)
        (receptacleAtLocation Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33_bar_SinkBasin loc_bar_3_bar_9_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_03_dot_85 loc_bar_3_bar_15_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_32_bar__plus_00_dot_98_bar__plus_04_dot_29 loc_bar_3_bar_17_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_03_dot_85 loc_bar_3_bar_15_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_56_bar__plus_00_dot_98_bar__plus_04_dot_29 loc_bar_3_bar_17_bar_1_bar_45)
        (receptacleAtLocation Toaster_bar__plus_01_dot_47_bar__plus_00_dot_98_bar__plus_04_dot_72 loc_bar_3_bar_19_bar_1_bar_45)
        (objectAtLocation Spoon_bar__plus_01_dot_41_bar__plus_00_dot_77_bar__plus_04_dot_75 loc_bar_1_bar_20_bar_1_bar_45)
        (objectAtLocation Cup_bar__plus_02_dot_09_bar__plus_01_dot_51_bar__plus_05_dot_25 loc_bar_4_bar_22_bar_1_bar_60)
        (objectAtLocation Tomato_bar__plus_01_dot_44_bar__plus_00_dot_94_bar__plus_02_dot_03 loc_bar_3_bar_9_bar_1_bar_45)
        (objectAtLocation Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_03_dot_85 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation ButterKnife_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_58 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Potato_bar__plus_01_dot_28_bar__plus_00_dot_93_bar__plus_01_dot_98 loc_bar_3_bar_9_bar_1_bar_45)
        (objectAtLocation SoapBottle_bar__plus_02_dot_06_bar__plus_00_dot_08_bar__plus_06_dot_47 loc_bar_4_bar_24_bar_1_bar_60)
        (objectAtLocation Lettuce_bar__plus_02_dot_05_bar__plus_01_dot_60_bar__plus_06_dot_00 loc_bar_4_bar_22_bar_1_bar_60)
        (objectAtLocation SaltShaker_bar__minus_00_dot_44_bar__plus_00_dot_76_bar__plus_06_dot_85 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Kettle_bar__plus_01_dot_41_bar__plus_00_dot_14_bar__plus_03_dot_22 loc_bar_1_bar_14_bar_1_bar_60)
        (objectAtLocation Apple_bar__plus_00_dot_06_bar__plus_01_dot_17_bar__plus_00_dot_21 loc_bar_1_bar_6_bar_2_bar_30)
        (objectAtLocation Fork_bar__plus_00_dot_02_bar__plus_00_dot_76_bar__plus_06_dot_74 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Knife_bar__minus_00_dot_53_bar__plus_00_dot_79_bar__plus_06_dot_76 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Egg_bar__plus_01_dot_97_bar__plus_01_dot_57_bar__plus_05_dot_88 loc_bar_4_bar_22_bar_1_bar_60)
        (objectAtLocation Bowl_bar__minus_00_dot_13_bar__plus_01_dot_58_bar__plus_00_dot_30 loc_bar_0_bar_4_bar_2_bar__minus_30)
        (objectAtLocation Apple_bar__plus_01_dot_96_bar__plus_00_dot_16_bar__plus_06_dot_47 loc_bar_4_bar_24_bar_1_bar_60)
        (objectAtLocation Bowl_bar__plus_00_dot_12_bar__plus_00_dot_76_bar__plus_06_dot_11 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Cup_bar__plus_02_dot_05_bar__plus_01_dot_51_bar__plus_05_dot_38 loc_bar_4_bar_22_bar_1_bar_60)
        (objectAtLocation Spoon_bar__minus_00_dot_41_bar__plus_00_dot_77_bar__plus_00_dot_56 loc_bar__minus_5_bar_5_bar_1_bar_45)
        (objectAtLocation Kettle_bar__plus_00_dot_26_bar__plus_00_dot_15_bar__plus_00_dot_51 loc_bar__minus_1_bar_7_bar_2_bar_45)
        (objectAtLocation Kettle_bar__plus_01_dot_31_bar__plus_00_dot_99_bar__plus_00_dot_44 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Potato_bar__minus_00_dot_29_bar__plus_00_dot_79_bar__plus_06_dot_79 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Sink_bar__plus_01_dot_39_bar__plus_01_dot_01_bar__plus_02_dot_33 loc_bar_3_bar_9_bar_1_bar_45)
        (objectAtLocation Bowl_bar__minus_00_dot_48_bar__plus_00_dot_14_bar__plus_00_dot_35 loc_bar_0_bar_7_bar_2_bar_45)
        (objectAtLocation Bread_bar__plus_01_dot_23_bar__plus_01_dot_06_bar__plus_03_dot_32 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Egg_bar__plus_00_dot_27_bar__plus_01_dot_15_bar__plus_00_dot_18 loc_bar_1_bar_6_bar_2_bar_30)
        (objectAtLocation Knife_bar__plus_00_dot_60_bar__plus_00_dot_80_bar__plus_00_dot_56 loc_bar_0_bar_5_bar_1_bar_45)
        (objectAtLocation Fork_bar__minus_00_dot_61_bar__plus_00_dot_99_bar__plus_00_dot_40 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Apple_bar__plus_01_dot_97_bar__plus_01_dot_59_bar__plus_05_dot_25 loc_bar_4_bar_22_bar_1_bar_60)
        (objectAtLocation Kettle_bar__plus_01_dot_32_bar__plus_00_dot_99_bar__plus_04_dot_29 loc_bar_3_bar_17_bar_1_bar_45)
        (objectAtLocation Plate_bar__plus_01_dot_57_bar__plus_00_dot_14_bar__plus_02_dot_79 loc_bar_1_bar_10_bar_1_bar_60)
        (objectAtLocation HousePlant_bar__minus_00_dot_17_bar__plus_00_dot_75_bar__plus_06_dot_44 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation SaltShaker_bar__plus_00_dot_15_bar__plus_00_dot_76_bar__plus_06_dot_35 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Lettuce_bar__minus_00_dot_46_bar__plus_01_dot_08_bar__plus_00_dot_58 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Window_bar__minus_02_dot_07_bar__plus_01_dot_92_bar__plus_03_dot_63 loc_bar__minus_6_bar_15_bar_3_bar__minus_30)
        (objectAtLocation Window_bar__plus_01_dot_76_bar__plus_02_dot_01_bar__plus_02_dot_30 loc_bar_3_bar_9_bar_1_bar__minus_15)
        (objectAtLocation SoapBottle_bar__plus_01_dot_67_bar__plus_00_dot_99_bar__plus_00_dot_21 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Spatula_bar__minus_00_dot_22_bar__plus_00_dot_78_bar__plus_06_dot_79 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation PaperTowelRoll_bar__minus_00_dot_10_bar__plus_00_dot_86_bar__plus_06_dot_94 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Pot_bar__plus_00_dot_73_bar__plus_00_dot_98_bar__plus_00_dot_38 loc_bar_3_bar_4_bar_1_bar_45)
        (objectAtLocation Potato_bar__plus_01_dot_44_bar__plus_00_dot_93_bar__plus_02_dot_47 loc_bar_3_bar_9_bar_1_bar_45)
        (objectAtLocation ButterKnife_bar__plus_00_dot_30_bar__plus_00_dot_76_bar__plus_06_dot_28 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_99 loc_bar_3_bar_16_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_31 loc_bar_3_bar_17_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_04_dot_14 loc_bar_3_bar_17_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_14_bar__plus_00_dot_93_bar__plus_03_dot_82 loc_bar_3_bar_15_bar_1_bar_60)
        (objectAtLocation PepperShaker_bar__plus_00_dot_17_bar__plus_01_dot_57_bar__plus_00_dot_30 loc_bar_0_bar_4_bar_2_bar__minus_30)
        (objectAtLocation Pan_bar__plus_01_dot_56_bar__plus_00_dot_99_bar__plus_04_dot_29 loc_bar_3_bar_17_bar_1_bar_45)
        (objectAtLocation Tomato_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__plus_06_dot_24 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation DishSponge_bar__plus_01_dot_41_bar__plus_01_dot_58_bar__plus_01_dot_41 loc_bar_3_bar_5_bar_1_bar__minus_30)
        (objectAtLocation Cup_bar__minus_00_dot_28_bar__plus_00_dot_76_bar__plus_06_dot_94 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation LightSwitch_bar__minus_02_dot_00_bar__plus_01_dot_55_bar__plus_06_dot_05 loc_bar__minus_6_bar_24_bar_3_bar_15)
        (objectAtLocation Chair_bar__plus_00_dot_29_bar__plus_00_dot_02_bar__plus_06_dot_14 loc_bar_1_bar_22_bar_0_bar_60)
        (objectAtLocation Spoon_bar__minus_00_dot_62_bar__plus_00_dot_76_bar__plus_06_dot_35 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Mug_bar__plus_00_dot_13_bar__plus_00_dot_76_bar__plus_06_dot_85 loc_bar_3_bar_26_bar_3_bar_45)
        (objectAtLocation Blinds_bar__plus_01_dot_74_bar__plus_02_dot_56_bar__plus_02_dot_31 loc_bar_3_bar_9_bar_1_bar__minus_30)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (exists (?o1 - object)
                                (and
                                    (objectType ?o1 KettleType)
                                    (receptacleType ?r DiningTableType)
                                    (inReceptacle ?o1 ?r)
                                    (exists (?o2 - object)
                                        (and
                                            (not (= ?o1 ?o2))
                                            (objectType ?o2 KettleType)
                                            (receptacleType ?r DiningTableType)
                                            (inReceptacle ?o2 ?r)
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            