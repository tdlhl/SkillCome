
(define (problem plan_trial_T20190908_040715_288858)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        AlarmClock_bar__minus_01_dot_51_bar__plus_01_dot_52_bar__minus_02_dot_29 - object
        AlarmClock_bar__minus_01_dot_54_bar__plus_01_dot_52_bar__minus_01_dot_57 - object
        BaseballBat_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_01_dot_99 - object
        BasketBall_bar__plus_01_dot_27_bar__plus_00_dot_12_bar__minus_01_dot_29 - object
        Blinds_bar__plus_00_dot_25_bar__plus_02_dot_19_bar__minus_02_dot_69 - object
        Blinds_bar__minus_00_dot_35_bar__plus_02_dot_19_bar__minus_02_dot_69 - object
        Blinds_bar__minus_00_dot_95_bar__plus_02_dot_19_bar__minus_02_dot_69 - object
        Book_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_01_dot_07 - object
        Boots_bar__plus_01_dot_29_bar__plus_00_dot_00_bar__minus_00_dot_96 - object
        Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25 - object
        Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93 - object
        Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90 - object
        Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61 - object
        CD_bar__plus_01_dot_28_bar__plus_00_dot_24_bar__minus_02_dot_03 - object
        CD_bar__minus_01_dot_33_bar__plus_00_dot_40_bar__minus_01_dot_73 - object
        CellPhone_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_00_dot_50 - object
        CellPhone_bar__minus_01_dot_39_bar__plus_00_dot_70_bar__minus_02_dot_19 - object
        Chair_bar__plus_00_dot_28_bar__plus_00_dot_00_bar__minus_02_dot_26 - object
        CreditCard_bar__plus_01_dot_17_bar__plus_00_dot_11_bar__minus_01_dot_71 - object
        CreditCard_bar__minus_01_dot_58_bar__plus_01_dot_52_bar__minus_01_dot_86 - object
        DeskLamp_bar__minus_01_dot_49_bar__plus_00_dot_69_bar__minus_02_dot_42 - object
        KeyChain_bar__plus_01_dot_16_bar__plus_00_dot_38_bar__plus_00_dot_05 - object
        KeyChain_bar__plus_01_dot_33_bar__plus_01_dot_41_bar__plus_00_dot_05 - object
        KeyChain_bar__minus_01_dot_64_bar__plus_01_dot_52_bar__minus_02_dot_44 - object
        Laptop_bar__plus_00_dot_08_bar__plus_00_dot_57_bar__minus_02_dot_46 - object
        Laptop_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__plus_00_dot_34 - object
        LightSwitch_bar__minus_00_dot_76_bar__plus_01_dot_18_bar__plus_02_dot_10 - object
        Mirror_bar__plus_00_dot_74_bar__plus_01_dot_49_bar__plus_02_dot_10 - object
        Pencil_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_90 - object
        Pen_bar__plus_00_dot_31_bar__plus_00_dot_58_bar__minus_02_dot_54 - object
        Pen_bar__plus_01_dot_26_bar__plus_00_dot_92_bar__minus_00_dot_54 - object
        Pillow_bar__minus_01_dot_08_bar__plus_00_dot_71_bar__minus_00_dot_22 - object
        Window_bar__plus_00_dot_24_bar__plus_00_dot_96_bar__minus_02_dot_68 - object
        Window_bar__minus_00_dot_36_bar__plus_00_dot_96_bar__minus_02_dot_68 - object
        Window_bar__minus_00_dot_96_bar__plus_00_dot_96_bar__minus_02_dot_68 - object
        Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27 - receptacle
        Desk_bar__plus_00_dot_45_bar_00_dot_00_bar__minus_02_dot_53 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_64 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_96 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_64 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_96 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_64 - receptacle
        Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_96 - receptacle
        Drawer_bar__minus_01_dot_35_bar__plus_00_dot_19_bar__minus_02_dot_05 - receptacle
        Drawer_bar__minus_01_dot_35_bar__plus_00_dot_48_bar__minus_02_dot_05 - receptacle
        Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05 - receptacle
        GarbageCan_bar__minus_01_dot_57_bar__plus_00_dot_00_bar__plus_01_dot_94 - receptacle
        Shelf_bar__plus_01_dot_22_bar__plus_00_dot_86_bar__minus_01_dot_80 - receptacle
        Shelf_bar__plus_01_dot_26_bar__plus_00_dot_38_bar__minus_00_dot_26 - receptacle
        Shelf_bar__plus_01_dot_26_bar__plus_00_dot_90_bar__minus_00_dot_27 - receptacle
        Shelf_bar__plus_01_dot_26_bar__plus_01_dot_40_bar__minus_00_dot_26 - receptacle
        Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03 - receptacle
        loc_bar_0_bar_0_bar_3_bar_60 - location
        loc_bar_0_bar__minus_6_bar_1_bar_60 - location
        loc_bar__minus_2_bar__minus_9_bar_2_bar__minus_30 - location
        loc_bar__minus_2_bar__minus_9_bar_2_bar_60 - location
        loc_bar_1_bar__minus_6_bar_1_bar_60 - location
        loc_bar_2_bar__minus_1_bar_1_bar_45 - location
        loc_bar_1_bar__minus_5_bar_1_bar_60 - location
        loc_bar__minus_2_bar_5_bar_3_bar_60 - location
        loc_bar_3_bar_6_bar_0_bar_15 - location
        loc_bar_2_bar__minus_6_bar_2_bar_60 - location
        loc_bar_2_bar__minus_6_bar_1_bar_45 - location
        loc_bar_4_bar_6_bar_0_bar_60 - location
        loc_bar__minus_2_bar__minus_9_bar_1_bar_45 - location
        loc_bar__minus_3_bar__minus_9_bar_3_bar_15 - location
        loc_bar__minus_3_bar__minus_8_bar_3_bar_60 - location
        loc_bar__minus_1_bar__minus_7_bar_3_bar_60 - location
        loc_bar__minus_3_bar__minus_9_bar_2_bar__minus_30 - location
        loc_bar__minus_3_bar_6_bar_0_bar_45 - location
        loc_bar__minus_3_bar__minus_9_bar_2_bar_60 - location
        loc_bar_2_bar__minus_1_bar_1_bar_60 - location
        loc_bar_2_bar__minus_5_bar_1_bar_60 - location
        loc_bar_2_bar__minus_1_bar_1_bar_15 - location
        loc_bar__minus_1_bar__minus_5_bar_1_bar_45 - location
        loc_bar__minus_2_bar__minus_9_bar_1_bar_60 - location
        loc_bar_0_bar__minus_5_bar_1_bar_60 - location
        loc_bar__minus_2_bar__minus_9_bar_1_bar__minus_30 - location
        loc_bar__minus_3_bar__minus_8_bar_3_bar_15 - location
        loc_bar_3_bar__minus_4_bar_1_bar_60 - location
        loc_bar__minus_6_bar_5_bar_1_bar_30 - location
        )
    

(:init


        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_64 DrawerType)
        (receptacleType Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03 ShelfType)
        (receptacleType Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05 DresserType)
        (receptacleType Drawer_bar__minus_01_dot_35_bar__plus_00_dot_19_bar__minus_02_dot_05 DrawerType)
        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_64 DrawerType)
        (receptacleType Shelf_bar__plus_01_dot_26_bar__plus_01_dot_40_bar__minus_00_dot_26 ShelfType)
        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_96 DrawerType)
        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_64 DrawerType)
        (receptacleType Shelf_bar__plus_01_dot_26_bar__plus_00_dot_38_bar__minus_00_dot_26 ShelfType)
        (receptacleType GarbageCan_bar__minus_01_dot_57_bar__plus_00_dot_00_bar__plus_01_dot_94 GarbageCanType)
        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_96 DrawerType)
        (receptacleType Shelf_bar__plus_01_dot_22_bar__plus_00_dot_86_bar__minus_01_dot_80 ShelfType)
        (receptacleType Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_96 DrawerType)
        (receptacleType Shelf_bar__plus_01_dot_26_bar__plus_00_dot_90_bar__minus_00_dot_27 ShelfType)
        (receptacleType Desk_bar__plus_00_dot_45_bar_00_dot_00_bar__minus_02_dot_53 DeskType)
        (receptacleType Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27 BedType)
        (receptacleType Drawer_bar__minus_01_dot_35_bar__plus_00_dot_48_bar__minus_02_dot_05 DrawerType)
        (objectType CreditCard_bar__plus_01_dot_17_bar__plus_00_dot_11_bar__minus_01_dot_71 CreditCardType)
        (objectType AlarmClock_bar__minus_01_dot_54_bar__plus_01_dot_52_bar__minus_01_dot_57 AlarmClockType)
        (objectType Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93 BowlType)
        (objectType KeyChain_bar__plus_01_dot_16_bar__plus_00_dot_38_bar__plus_00_dot_05 KeyChainType)
        (objectType Window_bar__minus_00_dot_96_bar__plus_00_dot_96_bar__minus_02_dot_68 WindowType)
        (objectType Book_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_01_dot_07 BookType)
        (objectType Blinds_bar__minus_00_dot_35_bar__plus_02_dot_19_bar__minus_02_dot_69 BlindsType)
        (objectType Laptop_bar__plus_00_dot_08_bar__plus_00_dot_57_bar__minus_02_dot_46 LaptopType)
        (objectType AlarmClock_bar__minus_01_dot_51_bar__plus_01_dot_52_bar__minus_02_dot_29 AlarmClockType)
        (objectType Boots_bar__plus_01_dot_29_bar__plus_00_dot_00_bar__minus_00_dot_96 BootsType)
        (objectType CellPhone_bar__minus_01_dot_39_bar__plus_00_dot_70_bar__minus_02_dot_19 CellPhoneType)
        (objectType KeyChain_bar__minus_01_dot_64_bar__plus_01_dot_52_bar__minus_02_dot_44 KeyChainType)
        (objectType Blinds_bar__plus_00_dot_25_bar__plus_02_dot_19_bar__minus_02_dot_69 BlindsType)
        (objectType Blinds_bar__minus_00_dot_95_bar__plus_02_dot_19_bar__minus_02_dot_69 BlindsType)
        (objectType KeyChain_bar__plus_01_dot_33_bar__plus_01_dot_41_bar__plus_00_dot_05 KeyChainType)
        (objectType DeskLamp_bar__minus_01_dot_49_bar__plus_00_dot_69_bar__minus_02_dot_42 DeskLampType)
        (objectType Chair_bar__plus_00_dot_28_bar__plus_00_dot_00_bar__minus_02_dot_26 ChairType)
        (objectType CD_bar__plus_01_dot_28_bar__plus_00_dot_24_bar__minus_02_dot_03 CDType)
        (objectType Pillow_bar__minus_01_dot_08_bar__plus_00_dot_71_bar__minus_00_dot_22 PillowType)
        (objectType Pen_bar__plus_00_dot_31_bar__plus_00_dot_58_bar__minus_02_dot_54 PenType)
        (objectType Laptop_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__plus_00_dot_34 LaptopType)
        (objectType CellPhone_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_00_dot_50 CellPhoneType)
        (objectType Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61 BowlType)
        (objectType Pen_bar__plus_01_dot_26_bar__plus_00_dot_92_bar__minus_00_dot_54 PenType)
        (objectType Window_bar__plus_00_dot_24_bar__plus_00_dot_96_bar__minus_02_dot_68 WindowType)
        (objectType BasketBall_bar__plus_01_dot_27_bar__plus_00_dot_12_bar__minus_01_dot_29 BasketBallType)
        (objectType Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90 BowlType)
        (objectType Pencil_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_90 PencilType)
        (objectType CreditCard_bar__minus_01_dot_58_bar__plus_01_dot_52_bar__minus_01_dot_86 CreditCardType)
        (objectType BaseballBat_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_01_dot_99 BaseballBatType)
        (objectType CD_bar__minus_01_dot_33_bar__plus_00_dot_40_bar__minus_01_dot_73 CDType)
        (objectType Window_bar__minus_00_dot_36_bar__plus_00_dot_96_bar__minus_02_dot_68 WindowType)
        (objectType Mirror_bar__plus_00_dot_74_bar__plus_01_dot_49_bar__plus_02_dot_10 MirrorType)
        (objectType Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25 BowlType)
        (objectType LightSwitch_bar__minus_00_dot_76_bar__plus_01_dot_18_bar__plus_02_dot_10 LightSwitchType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CDType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain DresserType PenType)
        (canContain DresserType BookType)
        (canContain DresserType BowlType)
        (canContain DresserType CDType)
        (canContain DresserType CellPhoneType)
        (canContain DresserType KeyChainType)
        (canContain DresserType CreditCardType)
        (canContain DresserType BasketBallType)
        (canContain DresserType LaptopType)
        (canContain DresserType PencilType)
        (canContain DresserType AlarmClockType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CDType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CDType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain GarbageCanType PenType)
        (canContain GarbageCanType CDType)
        (canContain GarbageCanType PencilType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CDType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CDType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain DeskType PenType)
        (canContain DeskType BookType)
        (canContain DeskType BowlType)
        (canContain DeskType CDType)
        (canContain DeskType CellPhoneType)
        (canContain DeskType KeyChainType)
        (canContain DeskType CreditCardType)
        (canContain DeskType BasketBallType)
        (canContain DeskType LaptopType)
        (canContain DeskType PencilType)
        (canContain DeskType AlarmClockType)
        (canContain BedType BasketBallType)
        (canContain BedType BaseballBatType)
        (canContain BedType LaptopType)
        (canContain BedType BookType)
        (canContain BedType CellPhoneType)
        (canContain BedType PillowType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (pickupable CreditCard_bar__plus_01_dot_17_bar__plus_00_dot_11_bar__minus_01_dot_71)
        (pickupable AlarmClock_bar__minus_01_dot_54_bar__plus_01_dot_52_bar__minus_01_dot_57)
        (pickupable Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93)
        (pickupable KeyChain_bar__plus_01_dot_16_bar__plus_00_dot_38_bar__plus_00_dot_05)
        (pickupable Book_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_01_dot_07)
        (pickupable Laptop_bar__plus_00_dot_08_bar__plus_00_dot_57_bar__minus_02_dot_46)
        (pickupable AlarmClock_bar__minus_01_dot_51_bar__plus_01_dot_52_bar__minus_02_dot_29)
        (pickupable Boots_bar__plus_01_dot_29_bar__plus_00_dot_00_bar__minus_00_dot_96)
        (pickupable CellPhone_bar__minus_01_dot_39_bar__plus_00_dot_70_bar__minus_02_dot_19)
        (pickupable KeyChain_bar__minus_01_dot_64_bar__plus_01_dot_52_bar__minus_02_dot_44)
        (pickupable KeyChain_bar__plus_01_dot_33_bar__plus_01_dot_41_bar__plus_00_dot_05)
        (pickupable CD_bar__plus_01_dot_28_bar__plus_00_dot_24_bar__minus_02_dot_03)
        (pickupable Pillow_bar__minus_01_dot_08_bar__plus_00_dot_71_bar__minus_00_dot_22)
        (pickupable Pen_bar__plus_00_dot_31_bar__plus_00_dot_58_bar__minus_02_dot_54)
        (pickupable Laptop_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__plus_00_dot_34)
        (pickupable CellPhone_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_00_dot_50)
        (pickupable Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61)
        (pickupable Pen_bar__plus_01_dot_26_bar__plus_00_dot_92_bar__minus_00_dot_54)
        (pickupable BasketBall_bar__plus_01_dot_27_bar__plus_00_dot_12_bar__minus_01_dot_29)
        (pickupable Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90)
        (pickupable Pencil_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_90)
        (pickupable CreditCard_bar__minus_01_dot_58_bar__plus_01_dot_52_bar__minus_01_dot_86)
        (pickupable BaseballBat_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_01_dot_99)
        (pickupable CD_bar__minus_01_dot_33_bar__plus_00_dot_40_bar__minus_01_dot_73)
        (pickupable Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25)
        (isReceptacleObject Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93)
        (isReceptacleObject Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61)
        (isReceptacleObject Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90)
        (isReceptacleObject Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_64)
        (openable Drawer_bar__minus_01_dot_35_bar__plus_00_dot_19_bar__minus_02_dot_05)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_64)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_96)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_64)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_96)
        (openable Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_96)
        
        (atLocation agent1 loc_bar__minus_6_bar_5_bar_1_bar_30)
        
        (cleanable Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93)
        (cleanable Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61)
        (cleanable Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90)
        (cleanable Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25)
        
        
        (coolable Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93)
        (coolable Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61)
        (coolable Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90)
        (coolable Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25)
        
        
        (toggleable DeskLamp_bar__minus_01_dot_49_bar__plus_00_dot_69_bar__minus_02_dot_42)
        
        
        
        
        (inReceptacle CD_bar__plus_01_dot_28_bar__plus_00_dot_24_bar__minus_02_dot_03 Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_96)
        (inReceptacle CD_bar__minus_01_dot_33_bar__plus_00_dot_40_bar__minus_01_dot_73 Drawer_bar__minus_01_dot_35_bar__plus_00_dot_48_bar__minus_02_dot_05)
        (inReceptacle Laptop_bar__plus_00_dot_08_bar__plus_00_dot_57_bar__minus_02_dot_46 Desk_bar__plus_00_dot_45_bar_00_dot_00_bar__minus_02_dot_53)
        (inReceptacle Pen_bar__plus_00_dot_31_bar__plus_00_dot_58_bar__minus_02_dot_54 Desk_bar__plus_00_dot_45_bar_00_dot_00_bar__minus_02_dot_53)
        (inReceptacle CellPhone_bar__minus_01_dot_39_bar__plus_00_dot_70_bar__minus_02_dot_19 Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05)
        (inReceptacle Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61 Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05)
        (inReceptacle Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90 Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05)
        (inReceptacle Pencil_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_90 Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05)
        (inReceptacle DeskLamp_bar__minus_01_dot_49_bar__plus_00_dot_69_bar__minus_02_dot_42 Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05)
        (inReceptacle Pillow_bar__minus_01_dot_08_bar__plus_00_dot_71_bar__minus_00_dot_22 Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27)
        (inReceptacle CellPhone_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_00_dot_50 Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27)
        (inReceptacle Laptop_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__plus_00_dot_34 Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27)
        (inReceptacle Book_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_01_dot_07 Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27)
        (inReceptacle Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93 Shelf_bar__plus_01_dot_22_bar__plus_00_dot_86_bar__minus_01_dot_80)
        (inReceptacle CreditCard_bar__plus_01_dot_17_bar__plus_00_dot_11_bar__minus_01_dot_71 Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_64)
        (inReceptacle Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25 Shelf_bar__plus_01_dot_26_bar__plus_00_dot_90_bar__minus_00_dot_27)
        (inReceptacle Pen_bar__plus_01_dot_26_bar__plus_00_dot_92_bar__minus_00_dot_54 Shelf_bar__plus_01_dot_26_bar__plus_00_dot_90_bar__minus_00_dot_27)
        (inReceptacle KeyChain_bar__plus_01_dot_16_bar__plus_00_dot_38_bar__plus_00_dot_05 Shelf_bar__plus_01_dot_26_bar__plus_00_dot_38_bar__minus_00_dot_26)
        (inReceptacle KeyChain_bar__plus_01_dot_33_bar__plus_01_dot_41_bar__plus_00_dot_05 Shelf_bar__plus_01_dot_26_bar__plus_01_dot_40_bar__minus_00_dot_26)
        (inReceptacle AlarmClock_bar__minus_01_dot_51_bar__plus_01_dot_52_bar__minus_02_dot_29 Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03)
        (inReceptacle AlarmClock_bar__minus_01_dot_54_bar__plus_01_dot_52_bar__minus_01_dot_57 Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03)
        (inReceptacle CreditCard_bar__minus_01_dot_58_bar__plus_01_dot_52_bar__minus_01_dot_86 Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03)
        
        
        (receptacleAtLocation Bed_bar__minus_01_dot_21_bar__plus_00_dot_02_bar__minus_00_dot_27 loc_bar_0_bar_0_bar_3_bar_60)
        (receptacleAtLocation Desk_bar__plus_00_dot_45_bar_00_dot_00_bar__minus_02_dot_53 loc_bar_2_bar__minus_6_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_64 loc_bar_0_bar__minus_5_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_14_bar__minus_01_dot_96 loc_bar_0_bar__minus_6_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_64 loc_bar__minus_1_bar__minus_5_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_27_bar__minus_01_dot_96 loc_bar_0_bar__minus_6_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_64 loc_bar_1_bar__minus_5_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_98_bar__plus_00_dot_40_bar__minus_01_dot_96 loc_bar_1_bar__minus_6_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__minus_01_dot_35_bar__plus_00_dot_19_bar__minus_02_dot_05 loc_bar__minus_1_bar__minus_7_bar_3_bar_60)
        (receptacleAtLocation Drawer_bar__minus_01_dot_35_bar__plus_00_dot_48_bar__minus_02_dot_05 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (receptacleAtLocation Dresser_bar__minus_01_dot_47_bar__plus_00_dot_03_bar__minus_02_dot_05 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_01_dot_57_bar__plus_00_dot_00_bar__plus_01_dot_94 loc_bar__minus_2_bar_5_bar_3_bar_60)
        (receptacleAtLocation Shelf_bar__plus_01_dot_22_bar__plus_00_dot_86_bar__minus_01_dot_80 loc_bar_2_bar__minus_6_bar_1_bar_45)
        (receptacleAtLocation Shelf_bar__plus_01_dot_26_bar__plus_00_dot_38_bar__minus_00_dot_26 loc_bar_2_bar__minus_1_bar_1_bar_60)
        (receptacleAtLocation Shelf_bar__plus_01_dot_26_bar__plus_00_dot_90_bar__minus_00_dot_27 loc_bar_2_bar__minus_1_bar_1_bar_45)
        (receptacleAtLocation Shelf_bar__plus_01_dot_26_bar__plus_01_dot_40_bar__minus_00_dot_26 loc_bar_2_bar__minus_1_bar_1_bar_15)
        (receptacleAtLocation Shelf_bar__minus_01_dot_58_bar__plus_01_dot_51_bar__minus_02_dot_03 loc_bar__minus_3_bar__minus_8_bar_3_bar_15)
        (objectAtLocation Bowl_bar__plus_01_dot_26_bar__plus_00_dot_91_bar__minus_00_dot_25 loc_bar_2_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CD_bar__minus_01_dot_33_bar__plus_00_dot_40_bar__minus_01_dot_73 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation AlarmClock_bar__minus_01_dot_51_bar__plus_01_dot_52_bar__minus_02_dot_29 loc_bar__minus_3_bar__minus_8_bar_3_bar_15)
        (objectAtLocation Pen_bar__plus_01_dot_26_bar__plus_00_dot_92_bar__minus_00_dot_54 loc_bar_2_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Laptop_bar__plus_00_dot_08_bar__plus_00_dot_57_bar__minus_02_dot_46 loc_bar_2_bar__minus_6_bar_2_bar_60)
        (objectAtLocation CreditCard_bar__minus_01_dot_58_bar__plus_01_dot_52_bar__minus_01_dot_86 loc_bar__minus_3_bar__minus_8_bar_3_bar_15)
        (objectAtLocation CellPhone_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_00_dot_50 loc_bar_0_bar_0_bar_3_bar_60)
        (objectAtLocation KeyChain_bar__plus_01_dot_33_bar__plus_01_dot_41_bar__plus_00_dot_05 loc_bar_2_bar__minus_1_bar_1_bar_15)
        (objectAtLocation KeyChain_bar__plus_01_dot_16_bar__plus_00_dot_38_bar__plus_00_dot_05 loc_bar_2_bar__minus_1_bar_1_bar_60)
        (objectAtLocation Bowl_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_61 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation Bowl_bar__minus_01_dot_33_bar__plus_00_dot_70_bar__minus_01_dot_90 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation Book_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__minus_01_dot_07 loc_bar_0_bar_0_bar_3_bar_60)
        (objectAtLocation Mirror_bar__plus_00_dot_74_bar__plus_01_dot_49_bar__plus_02_dot_10 loc_bar_3_bar_6_bar_0_bar_15)
        (objectAtLocation Chair_bar__plus_00_dot_28_bar__plus_00_dot_00_bar__minus_02_dot_26 loc_bar__minus_2_bar__minus_9_bar_1_bar_60)
        (objectAtLocation KeyChain_bar__minus_01_dot_64_bar__plus_01_dot_52_bar__minus_02_dot_44 loc_bar__minus_3_bar__minus_9_bar_3_bar_15)
        (objectAtLocation BaseballBat_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_01_dot_99 loc_bar_4_bar_6_bar_0_bar_60)
        (objectAtLocation BasketBall_bar__plus_01_dot_27_bar__plus_00_dot_12_bar__minus_01_dot_29 loc_bar_2_bar__minus_5_bar_1_bar_60)
        (objectAtLocation Pencil_bar__minus_01_dot_58_bar__plus_00_dot_70_bar__minus_01_dot_90 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation CellPhone_bar__minus_01_dot_39_bar__plus_00_dot_70_bar__minus_02_dot_19 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation CreditCard_bar__plus_01_dot_17_bar__plus_00_dot_11_bar__minus_01_dot_71 loc_bar_0_bar__minus_5_bar_1_bar_60)
        (objectAtLocation Laptop_bar__minus_01_dot_32_bar__plus_00_dot_61_bar__plus_00_dot_34 loc_bar_0_bar_0_bar_3_bar_60)
        (objectAtLocation Pillow_bar__minus_01_dot_08_bar__plus_00_dot_71_bar__minus_00_dot_22 loc_bar_0_bar_0_bar_3_bar_60)
        (objectAtLocation LightSwitch_bar__minus_00_dot_76_bar__plus_01_dot_18_bar__plus_02_dot_10 loc_bar__minus_3_bar_6_bar_0_bar_45)
        (objectAtLocation Boots_bar__plus_01_dot_29_bar__plus_00_dot_00_bar__minus_00_dot_96 loc_bar_3_bar__minus_4_bar_1_bar_60)
        (objectAtLocation Pen_bar__plus_00_dot_31_bar__plus_00_dot_58_bar__minus_02_dot_54 loc_bar_2_bar__minus_6_bar_2_bar_60)
        (objectAtLocation DeskLamp_bar__minus_01_dot_49_bar__plus_00_dot_69_bar__minus_02_dot_42 loc_bar__minus_3_bar__minus_8_bar_3_bar_60)
        (objectAtLocation AlarmClock_bar__minus_01_dot_54_bar__plus_01_dot_52_bar__minus_01_dot_57 loc_bar__minus_3_bar__minus_8_bar_3_bar_15)
        (objectAtLocation CD_bar__plus_01_dot_28_bar__plus_00_dot_24_bar__minus_02_dot_03 loc_bar_0_bar__minus_6_bar_1_bar_60)
        (objectAtLocation Window_bar__plus_00_dot_24_bar__plus_00_dot_96_bar__minus_02_dot_68 loc_bar__minus_2_bar__minus_9_bar_1_bar_45)
        (objectAtLocation Window_bar__minus_00_dot_36_bar__plus_00_dot_96_bar__minus_02_dot_68 loc_bar__minus_2_bar__minus_9_bar_2_bar_60)
        (objectAtLocation Window_bar__minus_00_dot_96_bar__plus_00_dot_96_bar__minus_02_dot_68 loc_bar__minus_3_bar__minus_9_bar_2_bar_60)
        (objectAtLocation Bowl_bar__plus_01_dot_27_bar__plus_00_dot_50_bar__minus_01_dot_93 loc_bar_2_bar__minus_6_bar_1_bar_45)
        (objectAtLocation Blinds_bar__minus_00_dot_35_bar__plus_02_dot_19_bar__minus_02_dot_69 loc_bar__minus_2_bar__minus_9_bar_2_bar__minus_30)
        (objectAtLocation Blinds_bar__plus_00_dot_25_bar__plus_02_dot_19_bar__minus_02_dot_69 loc_bar__minus_2_bar__minus_9_bar_1_bar__minus_30)
        (objectAtLocation Blinds_bar__minus_00_dot_95_bar__plus_02_dot_19_bar__minus_02_dot_69 loc_bar__minus_3_bar__minus_9_bar_2_bar__minus_30)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (exists (?o1 - object)
                                (and
                                    (objectType ?o1 BowlType)
                                    (receptacleType ?r DeskType)
                                    (inReceptacle ?o1 ?r)
                                    (exists (?o2 - object)
                                        (and
                                            (not (= ?o1 ?o2))
                                            (objectType ?o2 BowlType)
                                            (receptacleType ?r DeskType)
                                            (inReceptacle ?o2 ?r)
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            