
(define (problem plan_trial_T20190908_112534_364453)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51 - object
        Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44 - object
        Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74 - object
        Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08 - object
        Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54 - object
        Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49 - object
        Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11 - object
        ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22 - object
        ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53 - object
        CellPhone_bar__plus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 - object
        CellPhone_bar__plus_01_dot_61_bar__plus_00_dot_34_bar__plus_00_dot_67 - object
        CellPhone_bar__minus_01_dot_64_bar__plus_00_dot_91_bar__minus_00_dot_96 - object
        Chair_bar__minus_00_dot_06_bar__plus_00_dot_52_bar__plus_01_dot_37 - object
        Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81 - object
        Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 - object
        DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33 - object
        Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51 - object
        Faucet_bar__minus_00_dot_02_bar__plus_01_dot_14_bar__minus_01_dot_61 - object
        Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02 - object
        Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05 - object
        Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60 - object
        Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82 - object
        Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19 - object
        Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28 - object
        Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06 - object
        Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04 - object
        Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20 - object
        Ladle_bar__plus_01_dot_76_bar__plus_00_dot_50_bar__plus_00_dot_60 - object
        Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14 - object
        LightSwitch_bar__minus_00_dot_15_bar__plus_01_dot_29_bar__plus_03_dot_70 - object
        Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36 - object
        Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71 - object
        Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35 - object
        PepperShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_97 - object
        Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41 - object
        Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60 - object
        Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41 - object
        SaltShaker_bar__plus_00_dot_32_bar__plus_00_dot_92_bar__plus_00_dot_74 - object
        SaltShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_51 - object
        SaltShaker_bar__minus_00_dot_84_bar__plus_00_dot_91_bar__minus_01_dot_71 - object
        Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44 - object
        SoapBottle_bar__minus_00_dot_21_bar__plus_00_dot_93_bar__plus_01_dot_20 - object
        Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51 - object
        Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97 - object
        Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42 - object
        Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_46 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_52 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_57 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_63 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_68 - object
        StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_74 - object
        Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04 - object
        Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27 - object
        Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37 - object
        Window_bar__plus_02_dot_22_bar__plus_01_dot_57_bar__minus_00_dot_39 - object
        Window_bar__minus_00_dot_01_bar__plus_01_dot_58_bar__minus_01_dot_82 - object
        Window_bar__minus_03_dot_24_bar__plus_01_dot_62_bar__plus_02_dot_69 - object
        Cabinet_bar__plus_00_dot_41_bar__plus_00_dot_48_bar__plus_00_dot_45 - receptacle
        Cabinet_bar__plus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 - receptacle
        Cabinet_bar__plus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 - receptacle
        Cabinet_bar__plus_01_dot_71_bar__plus_02_dot_02_bar__minus_01_dot_45 - receptacle
        Cabinet_bar__plus_01_dot_79_bar__plus_02_dot_02_bar__minus_00_dot_82 - receptacle
        Cabinet_bar__minus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 - receptacle
        Cabinet_bar__minus_00_dot_63_bar__plus_02_dot_02_bar__minus_01_dot_45 - receptacle
        Cabinet_bar__minus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 - receptacle
        Cabinet_bar__minus_01_dot_70_bar__plus_02_dot_02_bar__minus_01_dot_45 - receptacle
        CoffeeMachine_bar__plus_01_dot_36_bar__plus_00_dot_90_bar__minus_01_dot_60 - receptacle
        CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51 - receptacle
        CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51 - receptacle
        Drawer_bar__plus_00_dot_81_bar__plus_00_dot_48_bar__minus_01_dot_16 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_14_bar__plus_00_dot_60 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__plus_01_dot_22 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__minus_00_dot_02 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_31_bar__plus_00_dot_60 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_43_bar__minus_00_dot_02 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_52_bar__plus_01_dot_22 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_54_bar__plus_00_dot_60 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_60_bar__minus_00_dot_02 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__plus_00_dot_61 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__minus_00_dot_02 - receptacle
        Drawer_bar__plus_01_dot_50_bar__plus_00_dot_78_bar__plus_01_dot_22 - receptacle
        Drawer_bar__minus_00_dot_70_bar__plus_00_dot_48_bar__minus_01_dot_16 - receptacle
        Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01 - receptacle
        GarbageCan_bar__minus_01_dot_80_bar__plus_00_dot_00_bar__plus_01_dot_33 - receptacle
        Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77 - receptacle
        Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44_bar_SinkBasin - receptacle
        StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_38 - receptacle
        StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_60 - receptacle
        StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_82 - receptacle
        StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_38 - receptacle
        StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_60 - receptacle
        StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_82 - receptacle
        Toaster_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__minus_00_dot_34 - receptacle
        loc_bar_4_bar__minus_3_bar_1_bar__minus_30 - location
        loc_bar_3_bar_1_bar_1_bar_60 - location
        loc_bar_5_bar_2_bar_1_bar_60 - location
        loc_bar_3_bar_4_bar_1_bar_60 - location
        loc_bar_2_bar_7_bar_1_bar_60 - location
        loc_bar__minus_3_bar__minus_1_bar_2_bar_60 - location
        loc_bar__minus_3_bar__minus_2_bar_2_bar_60 - location
        loc_bar_4_bar__minus_3_bar_1_bar_45 - location
        loc_bar_0_bar__minus_3_bar_2_bar_45 - location
        loc_bar_5_bar_3_bar_1_bar_60 - location
        loc_bar_3_bar_7_bar_2_bar_60 - location
        loc_bar_0_bar_8_bar_2_bar_60 - location
        loc_bar_3_bar_3_bar_1_bar_60 - location
        loc_bar_5_bar_0_bar_1_bar_60 - location
        loc_bar_5_bar_0_bar_2_bar_45 - location
        loc_bar_5_bar_4_bar_3_bar_60 - location
        loc_bar__minus_10_bar_11_bar_3_bar_0 - location
        loc_bar_4_bar_3_bar_2_bar_60 - location
        loc_bar__minus_5_bar_6_bar_3_bar_60 - location
        loc_bar__minus_3_bar_0_bar_3_bar_60 - location
        loc_bar__minus_3_bar__minus_3_bar_3_bar__minus_15 - location
        loc_bar__minus_1_bar_12_bar_0_bar_30 - location
        loc_bar_5_bar_3_bar_1_bar_45 - location
        loc_bar__minus_3_bar__minus_3_bar_2_bar_45 - location
        loc_bar__minus_3_bar__minus_3_bar_2_bar__minus_30 - location
        loc_bar_4_bar__minus_3_bar_2_bar_45 - location
        loc_bar_5_bar_2_bar_1_bar_45 - location
        loc_bar_3_bar__minus_1_bar_2_bar_60 - location
        loc_bar_3_bar_6_bar_1_bar_45 - location
        loc_bar_3_bar_2_bar_3_bar_45 - location
        loc_bar_4_bar__minus_1_bar_1_bar_45 - location
        loc_bar_0_bar__minus_3_bar_2_bar_60 - location
        loc_bar__minus_1_bar_11_bar_0_bar_30 - location
        )
    

(:init


        (receptacleType StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_82 StoveBurnerType)
        (receptacleType Cabinet_bar__minus_01_dot_70_bar__plus_02_dot_02_bar__minus_01_dot_45 CabinetType)
        (receptacleType CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51 CounterTopType)
        (receptacleType Cabinet_bar__plus_01_dot_79_bar__plus_02_dot_02_bar__minus_00_dot_82 CabinetType)
        (receptacleType Cabinet_bar__minus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__plus_00_dot_61 DrawerType)
        (receptacleType Drawer_bar__minus_00_dot_70_bar__plus_00_dot_48_bar__minus_01_dot_16 DrawerType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_78_bar__plus_01_dot_22 DrawerType)
        (receptacleType Cabinet_bar__minus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_41_bar__plus_00_dot_48_bar__plus_00_dot_45 CabinetType)
        (receptacleType CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51 CounterTopType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_31_bar__plus_00_dot_60 DrawerType)
        (receptacleType Toaster_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__minus_00_dot_34 ToasterType)
        (receptacleType CoffeeMachine_bar__plus_01_dot_36_bar__plus_00_dot_90_bar__minus_01_dot_60 CoffeeMachineType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_14_bar__plus_00_dot_60 DrawerType)
        (receptacleType Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77 MicrowaveType)
        (receptacleType StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_60 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__minus_00_dot_02 DrawerType)
        (receptacleType Cabinet_bar__minus_00_dot_63_bar__plus_02_dot_02_bar__minus_01_dot_45 CabinetType)
        (receptacleType Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44_bar_SinkBasin SinkBasinType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_43_bar__minus_00_dot_02 DrawerType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_54_bar__plus_00_dot_60 DrawerType)
        (receptacleType Cabinet_bar__plus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 CabinetType)
        (receptacleType StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_38 StoveBurnerType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__minus_00_dot_02 DrawerType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__plus_01_dot_22 DrawerType)
        (receptacleType StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_82 StoveBurnerType)
        (receptacleType StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_38 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_01_dot_71_bar__plus_02_dot_02_bar__minus_01_dot_45 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_60_bar__minus_00_dot_02 DrawerType)
        (receptacleType StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_60 StoveBurnerType)
        (receptacleType Drawer_bar__plus_01_dot_50_bar__plus_00_dot_52_bar__plus_01_dot_22 DrawerType)
        (receptacleType GarbageCan_bar__minus_01_dot_80_bar__plus_00_dot_00_bar__plus_01_dot_33 GarbageCanType)
        (receptacleType Drawer_bar__plus_00_dot_81_bar__plus_00_dot_48_bar__minus_01_dot_16 DrawerType)
        (receptacleType Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01 FridgeType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_46 StoveKnobType)
        (objectType LightSwitch_bar__minus_00_dot_15_bar__plus_01_dot_29_bar__plus_03_dot_70 LightSwitchType)
        (objectType Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44 AppleType)
        (objectType Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97 SpoonType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_68 StoveKnobType)
        (objectType Ladle_bar__plus_01_dot_76_bar__plus_00_dot_50_bar__plus_00_dot_60 LadleType)
        (objectType SoapBottle_bar__minus_00_dot_21_bar__plus_00_dot_93_bar__plus_01_dot_20 SoapBottleType)
        (objectType Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36 MugType)
        (objectType Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19 KnifeType)
        (objectType Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41 PlateType)
        (objectType Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06 KnifeType)
        (objectType Window_bar__plus_02_dot_22_bar__plus_01_dot_57_bar__minus_00_dot_39 WindowType)
        (objectType Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49 BowlType)
        (objectType DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33 DishSpongeType)
        (objectType Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51 EggType)
        (objectType Chair_bar__minus_00_dot_06_bar__plus_00_dot_52_bar__plus_01_dot_37 ChairType)
        (objectType Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41 PotType)
        (objectType Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28 KnifeType)
        (objectType PepperShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_97 PepperShakerType)
        (objectType SaltShaker_bar__plus_00_dot_32_bar__plus_00_dot_92_bar__plus_00_dot_74 SaltShakerType)
        (objectType Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82 KettleType)
        (objectType Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37 TomatoType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_52 StoveKnobType)
        (objectType Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14 LettuceType)
        (objectType Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 CupType)
        (objectType Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05 KettleType)
        (objectType Window_bar__minus_00_dot_01_bar__plus_01_dot_58_bar__minus_01_dot_82 WindowType)
        (objectType Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20 LadleType)
        (objectType Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27 TomatoType)
        (objectType Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44 SinkType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_63 StoveKnobType)
        (objectType Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60 PotatoType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_57 StoveKnobType)
        (objectType Window_bar__minus_03_dot_24_bar__plus_01_dot_62_bar__plus_02_dot_69 WindowType)
        (objectType Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11 BreadType)
        (objectType StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_74 StoveKnobType)
        (objectType Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71 PanType)
        (objectType ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22 ButterKnifeType)
        (objectType Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04 LadleType)
        (objectType Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51 AppleType)
        (objectType Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06 SpoonType)
        (objectType Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81 CupType)
        (objectType Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60 KettleType)
        (objectType SaltShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_51 SaltShakerType)
        (objectType Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51 SpatulaType)
        (objectType Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02 ForkType)
        (objectType CellPhone_bar__plus_01_dot_61_bar__plus_00_dot_34_bar__plus_00_dot_67 CellPhoneType)
        (objectType Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08 AppleType)
        (objectType Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74 AppleType)
        (objectType CellPhone_bar__plus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 CellPhoneType)
        (objectType Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54 BowlType)
        (objectType SaltShaker_bar__minus_00_dot_84_bar__plus_00_dot_91_bar__minus_01_dot_71 SaltShakerType)
        (objectType ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53 ButterKnifeType)
        (objectType CellPhone_bar__minus_01_dot_64_bar__plus_00_dot_91_bar__minus_00_dot_96 CellPhoneType)
        (objectType Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04 TomatoType)
        (objectType Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42 SpoonType)
        (objectType Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35 PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType KettleType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType LadleType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType KettleType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType LadleType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CoffeeMachineType MugType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BreadType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType BowlType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType KettleType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType LadleType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType LettuceType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType KettleType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType LadleType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain StoveBurnerType KettleType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType LettuceType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType AppleType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType LadleType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain FridgeType BreadType)
        (canContain FridgeType BowlType)
        (canContain FridgeType PotType)
        (canContain FridgeType MugType)
        (canContain FridgeType EggType)
        (canContain FridgeType LettuceType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType CupType)
        (canContain FridgeType PlateType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType PanType)
        (pickupable Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44)
        (pickupable Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97)
        (pickupable Ladle_bar__plus_01_dot_76_bar__plus_00_dot_50_bar__plus_00_dot_60)
        (pickupable SoapBottle_bar__minus_00_dot_21_bar__plus_00_dot_93_bar__plus_01_dot_20)
        (pickupable Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36)
        (pickupable Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19)
        (pickupable Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41)
        (pickupable Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06)
        (pickupable Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49)
        (pickupable DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33)
        (pickupable Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (pickupable Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41)
        (pickupable Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28)
        (pickupable PepperShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_97)
        (pickupable SaltShaker_bar__plus_00_dot_32_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (pickupable Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82)
        (pickupable Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37)
        (pickupable Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14)
        (pickupable Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (pickupable Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05)
        (pickupable Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20)
        (pickupable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27)
        (pickupable Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60)
        (pickupable Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11)
        (pickupable Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71)
        (pickupable ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22)
        (pickupable Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04)
        (pickupable Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (pickupable Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06)
        (pickupable Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81)
        (pickupable Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60)
        (pickupable SaltShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_51)
        (pickupable Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51)
        (pickupable Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02)
        (pickupable CellPhone_bar__plus_01_dot_61_bar__plus_00_dot_34_bar__plus_00_dot_67)
        (pickupable Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        (pickupable Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74)
        (pickupable CellPhone_bar__plus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (pickupable Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54)
        (pickupable SaltShaker_bar__minus_00_dot_84_bar__plus_00_dot_91_bar__minus_01_dot_71)
        (pickupable ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53)
        (pickupable CellPhone_bar__minus_01_dot_64_bar__plus_00_dot_91_bar__minus_00_dot_96)
        (pickupable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04)
        (pickupable Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42)
        (pickupable Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35)
        (isReceptacleObject Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36)
        (isReceptacleObject Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41)
        (isReceptacleObject Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49)
        (isReceptacleObject Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41)
        (isReceptacleObject Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (isReceptacleObject Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71)
        (isReceptacleObject Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81)
        (isReceptacleObject Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54)
        (isReceptacleObject Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35)
        (openable Cabinet_bar__minus_01_dot_70_bar__plus_02_dot_02_bar__minus_01_dot_45)
        (openable Cabinet_bar__plus_01_dot_79_bar__plus_02_dot_02_bar__minus_00_dot_82)
        (openable Cabinet_bar__minus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__plus_00_dot_61)
        (openable Drawer_bar__minus_00_dot_70_bar__plus_00_dot_48_bar__minus_01_dot_16)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_78_bar__plus_01_dot_22)
        (openable Cabinet_bar__minus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (openable Cabinet_bar__plus_00_dot_41_bar__plus_00_dot_48_bar__plus_00_dot_45)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_14_bar__plus_00_dot_60)
        (openable Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77)
        (openable Cabinet_bar__plus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__minus_00_dot_02)
        (openable Cabinet_bar__minus_00_dot_63_bar__plus_02_dot_02_bar__minus_01_dot_45)
        (openable Cabinet_bar__plus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__plus_01_dot_22)
        (openable Cabinet_bar__plus_01_dot_71_bar__plus_02_dot_02_bar__minus_01_dot_45)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_60_bar__minus_00_dot_02)
        (openable Drawer_bar__plus_01_dot_50_bar__plus_00_dot_52_bar__plus_01_dot_22)
        (openable Drawer_bar__plus_00_dot_81_bar__plus_00_dot_48_bar__minus_01_dot_16)
        (openable Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01)
        
        (atLocation agent1 loc_bar__minus_1_bar_11_bar_0_bar_30)
        
        (cleanable Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44)
        (cleanable Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97)
        (cleanable Ladle_bar__plus_01_dot_76_bar__plus_00_dot_50_bar__plus_00_dot_60)
        (cleanable Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36)
        (cleanable Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19)
        (cleanable Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41)
        (cleanable Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06)
        (cleanable Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49)
        (cleanable DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33)
        (cleanable Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (cleanable Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41)
        (cleanable Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28)
        (cleanable Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82)
        (cleanable Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37)
        (cleanable Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14)
        (cleanable Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (cleanable Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05)
        (cleanable Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20)
        (cleanable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27)
        (cleanable Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60)
        (cleanable Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71)
        (cleanable ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22)
        (cleanable Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04)
        (cleanable Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (cleanable Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06)
        (cleanable Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81)
        (cleanable Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60)
        (cleanable Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51)
        (cleanable Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02)
        (cleanable Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        (cleanable Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74)
        (cleanable Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54)
        (cleanable ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53)
        (cleanable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04)
        (cleanable Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42)
        (cleanable Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35)
        
        (heatable Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44)
        (heatable Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36)
        (heatable Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41)
        (heatable Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (heatable Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37)
        (heatable Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (heatable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27)
        (heatable Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60)
        (heatable Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11)
        (heatable Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (heatable Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81)
        (heatable Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        (heatable Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74)
        (heatable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04)
        (coolable Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44)
        (coolable Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36)
        (coolable Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41)
        (coolable Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49)
        (coolable Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (coolable Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41)
        (coolable Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37)
        (coolable Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14)
        (coolable Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74)
        (coolable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27)
        (coolable Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60)
        (coolable Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11)
        (coolable Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71)
        (coolable Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (coolable Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81)
        (coolable Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        (coolable Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74)
        (coolable Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54)
        (coolable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04)
        (coolable Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35)
        
        (isCool Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        
        
        
        (sliceable Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44)
        (sliceable Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (sliceable Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37)
        (sliceable Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14)
        (sliceable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27)
        (sliceable Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60)
        (sliceable Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11)
        (sliceable Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51)
        (sliceable Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08)
        (sliceable Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74)
        (sliceable Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04)
        
        (inReceptacle Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41 Cabinet_bar__minus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (inReceptacle DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33 Drawer_bar__plus_00_dot_81_bar__plus_00_dot_48_bar__minus_01_dot_16)
        (inReceptacle Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02 Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__minus_00_dot_02)
        (inReceptacle Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05 Cabinet_bar__plus_01_dot_79_bar__plus_02_dot_02_bar__minus_00_dot_82)
        (inReceptacle ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53 Drawer_bar__plus_01_dot_50_bar__plus_00_dot_14_bar__plus_00_dot_60)
        (inReceptacle Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54 Cabinet_bar__plus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15)
        (inReceptacle CellPhone_bar__plus_01_dot_61_bar__plus_00_dot_34_bar__plus_00_dot_67 Drawer_bar__plus_01_dot_50_bar__plus_00_dot_31_bar__plus_00_dot_60)
        (inReceptacle Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60 StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_60)
        (inReceptacle ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22 Drawer_bar__plus_01_dot_50_bar__plus_00_dot_52_bar__plus_01_dot_22)
        (inReceptacle Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle SaltShaker_bar__minus_00_dot_84_bar__plus_00_dot_91_bar__minus_01_dot_71 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Window_bar__plus_02_dot_22_bar__plus_01_dot_57_bar__minus_00_dot_39 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle CellPhone_bar__minus_01_dot_64_bar__plus_00_dot_91_bar__minus_00_dot_96 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Window_bar__minus_00_dot_01_bar__plus_01_dot_58_bar__minus_01_dot_82 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35 CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51)
        (inReceptacle PepperShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_97 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle SaltShaker_bar__plus_00_dot_32_bar__plus_00_dot_92_bar__plus_00_dot_74 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle SaltShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_51 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle SoapBottle_bar__minus_00_dot_21_bar__plus_00_dot_93_bar__plus_01_dot_20 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle CellPhone_bar__plus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04 CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51)
        (inReceptacle Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28 Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__plus_01_dot_22)
        (inReceptacle Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82 StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_82)
        (inReceptacle Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37 GarbageCan_bar__minus_01_dot_80_bar__plus_00_dot_00_bar__plus_01_dot_33)
        (inReceptacle Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81 Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77)
        (inReceptacle Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60 Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77)
        (inReceptacle Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36 CoffeeMachine_bar__plus_01_dot_36_bar__plus_00_dot_90_bar__minus_01_dot_60)
        (inReceptacle Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08 Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01)
        (inReceptacle Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11 Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01)
        (inReceptacle Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14 Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01)
        (inReceptacle Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49 Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44_bar_SinkBasin)
        (inReceptacle Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44 Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44_bar_SinkBasin)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_41_bar__plus_00_dot_48_bar__plus_00_dot_45 loc_bar_5_bar_4_bar_3_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 loc_bar_3_bar__minus_1_bar_2_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 loc_bar_3_bar__minus_1_bar_2_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_71_bar__plus_02_dot_02_bar__minus_01_dot_45 loc_bar_4_bar__minus_3_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_01_dot_79_bar__plus_02_dot_02_bar__minus_00_dot_82 loc_bar_4_bar__minus_3_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_50_bar__plus_00_dot_48_bar__minus_01_dot_15 loc_bar__minus_3_bar__minus_1_bar_2_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_63_bar__plus_02_dot_02_bar__minus_01_dot_45 loc_bar__minus_3_bar__minus_3_bar_2_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_39_bar__plus_00_dot_48_bar__minus_01_dot_15 loc_bar__minus_3_bar__minus_1_bar_2_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_70_bar__plus_02_dot_02_bar__minus_01_dot_45 loc_bar__minus_3_bar__minus_3_bar_3_bar__minus_15)
        (receptacleAtLocation CoffeeMachine_bar__plus_01_dot_36_bar__plus_00_dot_90_bar__minus_01_dot_60 loc_bar_4_bar__minus_3_bar_2_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_01_dot_51 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (receptacleAtLocation CounterTop_bar__minus_00_dot_02_bar__plus_00_dot_96_bar__plus_00_dot_51 loc_bar_3_bar_2_bar_3_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_81_bar__plus_00_dot_48_bar__minus_01_dot_16 loc_bar_5_bar_0_bar_2_bar_45)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_14_bar__plus_00_dot_60 loc_bar_3_bar_7_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__plus_01_dot_22 loc_bar_2_bar_7_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_20_bar__minus_00_dot_02 loc_bar_5_bar_0_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_31_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_43_bar__minus_00_dot_02 loc_bar_5_bar_0_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_52_bar__plus_01_dot_22 loc_bar_3_bar_3_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_54_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_60_bar__minus_00_dot_02 loc_bar_4_bar_3_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__plus_00_dot_61 loc_bar_3_bar_4_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_63_bar__minus_00_dot_02 loc_bar_3_bar_1_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_50_bar__plus_00_dot_78_bar__plus_01_dot_22 loc_bar_3_bar_6_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__minus_00_dot_70_bar__plus_00_dot_48_bar__minus_01_dot_16 loc_bar__minus_3_bar__minus_2_bar_2_bar_60)
        (receptacleAtLocation Fridge_bar__minus_01_dot_76_bar__plus_00_dot_00_bar__plus_00_dot_01 loc_bar__minus_3_bar_0_bar_3_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_01_dot_80_bar__plus_00_dot_00_bar__plus_01_dot_33 loc_bar__minus_5_bar_6_bar_3_bar_60)
        (receptacleAtLocation Microwave_bar__plus_01_dot_93_bar__plus_00_dot_90_bar__minus_00_dot_77 loc_bar_4_bar__minus_3_bar_1_bar_45)
        (receptacleAtLocation Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44_bar_SinkBasin loc_bar_0_bar__minus_3_bar_2_bar_60)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_38 loc_bar_5_bar_2_bar_1_bar_60)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_60)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_77_bar__plus_00_dot_90_bar__plus_00_dot_82 loc_bar_5_bar_3_bar_1_bar_60)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_38 loc_bar_5_bar_2_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_82 loc_bar_5_bar_3_bar_1_bar_45)
        (receptacleAtLocation Toaster_bar__plus_01_dot_98_bar__plus_00_dot_90_bar__minus_00_dot_34 loc_bar_4_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Bowl_bar_00_dot_00_bar__plus_00_dot_76_bar__minus_01_dot_49 loc_bar_0_bar__minus_3_bar_2_bar_60)
        (objectAtLocation Spoon_bar__plus_00_dot_32_bar__plus_00_dot_93_bar__plus_00_dot_97 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_27 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation ButterKnife_bar__plus_01_dot_71_bar__plus_00_dot_46_bar__plus_01_dot_22 loc_bar_3_bar_3_bar_1_bar_60)
        (objectAtLocation CellPhone_bar__minus_01_dot_64_bar__plus_00_dot_91_bar__minus_00_dot_96 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation SaltShaker_bar__minus_00_dot_84_bar__plus_00_dot_91_bar__minus_01_dot_71 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Knife_bar__plus_01_dot_76_bar__plus_00_dot_25_bar__plus_01_dot_28 loc_bar_2_bar_7_bar_1_bar_60)
        (objectAtLocation Apple_bar__minus_01_dot_65_bar__plus_01_dot_52_bar__minus_00_dot_08 loc_bar__minus_3_bar_0_bar_3_bar_60)
        (objectAtLocation Pan_bar__minus_01_dot_29_bar__plus_00_dot_90_bar__minus_01_dot_35 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Kettle_bar__plus_01_dot_92_bar__plus_01_dot_66_bar__minus_01_dot_05 loc_bar_4_bar__minus_3_bar_1_bar__minus_30)
        (objectAtLocation Ladle_bar__plus_01_dot_76_bar__plus_00_dot_50_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_60)
        (objectAtLocation Cup_bar__minus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Apple_bar__plus_00_dot_26_bar__plus_00_dot_81_bar__minus_01_dot_44 loc_bar_0_bar__minus_3_bar_2_bar_60)
        (objectAtLocation Apple_bar__minus_00_dot_21_bar__plus_00_dot_98_bar__plus_00_dot_74 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation SaltShaker_bar__plus_00_dot_32_bar__plus_00_dot_92_bar__plus_00_dot_74 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Tomato_bar__minus_00_dot_32_bar__plus_00_dot_98_bar__plus_00_dot_04 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Knife_bar__plus_00_dot_00_bar__plus_00_dot_95_bar__minus_00_dot_19 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Spoon_bar__minus_01_dot_90_bar__plus_00_dot_91_bar__minus_01_dot_06 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_82 loc_bar_5_bar_3_bar_1_bar_45)
        (objectAtLocation Ladle_bar__plus_00_dot_00_bar__plus_00_dot_97_bar__plus_00_dot_04 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation CellPhone_bar__plus_00_dot_11_bar__plus_00_dot_92_bar__plus_00_dot_74 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Window_bar__minus_00_dot_01_bar__plus_01_dot_58_bar__minus_01_dot_82 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Sink_bar__plus_00_dot_00_bar__plus_00_dot_89_bar__minus_01_dot_44 loc_bar_0_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Window_bar__plus_02_dot_22_bar__plus_01_dot_57_bar__minus_00_dot_39 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Chair_bar__minus_00_dot_06_bar__plus_00_dot_52_bar__plus_01_dot_37 loc_bar_0_bar_8_bar_2_bar_60)
        (objectAtLocation Window_bar__minus_03_dot_24_bar__plus_01_dot_62_bar__plus_02_dot_69 loc_bar__minus_10_bar_11_bar_3_bar_0)
        (objectAtLocation SoapBottle_bar__minus_00_dot_21_bar__plus_00_dot_93_bar__plus_01_dot_20 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Cup_bar__plus_01_dot_96_bar__plus_01_dot_00_bar__minus_00_dot_81 loc_bar_4_bar__minus_3_bar_1_bar_45)
        (objectAtLocation LightSwitch_bar__minus_00_dot_15_bar__plus_01_dot_29_bar__plus_03_dot_70 loc_bar__minus_1_bar_12_bar_0_bar_30)
        (objectAtLocation Pot_bar__plus_00_dot_89_bar__plus_00_dot_90_bar__minus_01_dot_41 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_57 loc_bar_5_bar_2_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_63 loc_bar_5_bar_3_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_74 loc_bar_5_bar_3_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_68 loc_bar_5_bar_3_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_46 loc_bar_5_bar_2_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_60_bar__plus_00_dot_92_bar__plus_00_dot_52 loc_bar_5_bar_2_bar_1_bar_60)
        (objectAtLocation Fork_bar__plus_01_dot_76_bar__plus_00_dot_70_bar__minus_00_dot_02 loc_bar_3_bar_1_bar_1_bar_60)
        (objectAtLocation Ladle_bar__plus_00_dot_11_bar__plus_00_dot_97_bar__plus_01_dot_20 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Kettle_bar__plus_01_dot_98_bar__plus_00_dot_94_bar__plus_00_dot_60 loc_bar_5_bar_2_bar_1_bar_45)
        (objectAtLocation Egg_bar__minus_00_dot_11_bar__plus_00_dot_98_bar__plus_00_dot_51 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Plate_bar__minus_00_dot_25_bar__plus_00_dot_11_bar__minus_01_dot_41 loc_bar__minus_3_bar__minus_1_bar_2_bar_60)
        (objectAtLocation Pan_bar__plus_01_dot_80_bar__plus_00_dot_91_bar__minus_01_dot_71 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Lettuce_bar__minus_01_dot_71_bar__plus_00_dot_88_bar__minus_00_dot_14 loc_bar__minus_3_bar_0_bar_3_bar_60)
        (objectAtLocation Spatula_bar__plus_00_dot_11_bar__plus_00_dot_94_bar__plus_00_dot_51 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Apple_bar__plus_00_dot_00_bar__plus_00_dot_98_bar__plus_00_dot_51 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation Knife_bar__minus_01_dot_64_bar__plus_00_dot_93_bar__minus_01_dot_06 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation SaltShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_51 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation PepperShaker_bar__minus_00_dot_21_bar__plus_00_dot_92_bar__plus_00_dot_97 loc_bar_3_bar_2_bar_3_bar_45)
        (objectAtLocation CellPhone_bar__plus_01_dot_61_bar__plus_00_dot_34_bar__plus_00_dot_67 loc_bar_5_bar_2_bar_1_bar_60)
        (objectAtLocation ButterKnife_bar__plus_01_dot_77_bar__plus_00_dot_12_bar__plus_00_dot_53 loc_bar_3_bar_7_bar_2_bar_60)
        (objectAtLocation Bread_bar__minus_01_dot_80_bar__plus_01_dot_55_bar__plus_00_dot_11 loc_bar__minus_3_bar_0_bar_3_bar_60)
        (objectAtLocation Tomato_bar__minus_01_dot_80_bar__plus_00_dot_10_bar__plus_01_dot_37 loc_bar__minus_5_bar_6_bar_3_bar_60)
        (objectAtLocation Potato_bar__plus_02_dot_02_bar__plus_01_dot_03_bar__minus_00_dot_60 loc_bar_4_bar__minus_3_bar_1_bar_45)
        (objectAtLocation DishSponge_bar__plus_00_dot_65_bar__plus_00_dot_67_bar__minus_01_dot_33 loc_bar_5_bar_0_bar_2_bar_45)
        (objectAtLocation Spoon_bar__minus_01_dot_05_bar__plus_00_dot_91_bar__minus_01_dot_42 loc_bar__minus_3_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Mug_bar__plus_01_dot_36_bar__plus_00_dot_96_bar__minus_01_dot_36 loc_bar_4_bar__minus_3_bar_2_bar_45)
        (objectAtLocation Bowl_bar__plus_01_dot_23_bar__plus_00_dot_11_bar__minus_01_dot_54 loc_bar_3_bar__minus_1_bar_2_bar_60)
        )
    

        (:goal
            (and
                (exists (?r - receptacle)
                    (exists (?o - object)
                        (and
                            (heatable ?o)
                            (objectType ?o AppleType)
                            (receptacleType ?r CounterTopType)
                            (isHot ?o)
                            (inReceptacle ?o ?r)
                        )
                    )
                )
            )
        )
    )
    