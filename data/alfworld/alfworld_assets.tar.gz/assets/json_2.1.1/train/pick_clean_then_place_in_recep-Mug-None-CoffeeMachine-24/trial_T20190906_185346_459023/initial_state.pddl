
(define (problem plan_trial_T20190906_185346_459023)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25 - object
        Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84 - object
        Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68 - object
        Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33 - object
        Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45 - object
        ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35 - object
        Chair_bar__minus_00_dot_87_bar__plus_00_dot_49_bar__plus_01_dot_50 - object
        Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85 - object
        DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92 - object
        DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35 - object
        Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56 - object
        Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86 - object
        Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73 - object
        Faucet_bar__minus_01_dot_37_bar__plus_00_dot_81_bar__plus_03_dot_99 - object
        Faucet_bar__minus_01_dot_84_bar__plus_00_dot_81_bar__plus_03_dot_99 - object
        Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98 - object
        Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14 - object
        Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90 - object
        Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36 - object
        LightSwitch_bar__plus_00_dot_83_bar__plus_01_dot_40_bar__plus_04_dot_08 - object
        Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25 - object
        Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17 - object
        Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74 - object
        PaperTowelRoll_bar__minus_00_dot_66_bar__plus_01_dot_00_bar__plus_01_dot_04 - object
        PepperShaker_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_98 - object
        PepperShaker_bar__minus_02_dot_62_bar__plus_01_dot_85_bar__plus_01_dot_85 - object
        Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20 - object
        Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90 - object
        Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90 - object
        Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39 - object
        Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77 - object
        SaltShaker_bar__minus_00_dot_59_bar__plus_00_dot_16_bar__plus_03_dot_81 - object
        Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83 - object
        SoapBottle_bar__plus_00_dot_95_bar__plus_00_dot_82_bar__plus_00_dot_98 - object
        Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94 - object
        Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50 - object
        Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56 - object
        StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_32 - object
        StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_48 - object
        StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_73 - object
        StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_89 - object
        Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28 - object
        Window_bar__minus_01_dot_13_bar__plus_01_dot_67_bar__plus_00_dot_81 - object
        Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_00_dot_82 - receptacle
        Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_36 - receptacle
        Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_69 - receptacle
        Cabinet_bar__minus_00_dot_42_bar__plus_00_dot_67_bar__plus_03_dot_74 - receptacle
        Cabinet_bar__minus_00_dot_42_bar__plus_01_dot_70_bar__plus_03_dot_74 - receptacle
        Cabinet_bar__minus_01_dot_10_bar__plus_01_dot_93_bar__plus_03_dot_73 - receptacle
        Cabinet_bar__minus_01_dot_14_bar__plus_00_dot_39_bar__plus_03_dot_52 - receptacle
        Cabinet_bar__minus_01_dot_96_bar__plus_01_dot_93_bar__plus_03_dot_73 - receptacle
        Cabinet_bar__minus_01_dot_97_bar__plus_00_dot_39_bar__plus_03_dot_52 - receptacle
        Cabinet_bar__minus_01_dot_98_bar__plus_01_dot_78_bar__plus_03_dot_73 - receptacle
        Cabinet_bar__minus_01_dot_99_bar__plus_00_dot_39_bar__plus_03_dot_51 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_00_dot_64_bar__plus_01_dot_68 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_41_bar__plus_01_dot_68 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_69_bar__plus_02_dot_57 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_93_bar__plus_01_dot_69 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_06 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_69 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_02_dot_56 - receptacle
        Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_03_dot_18 - receptacle
        Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_17 - receptacle
        Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_42 - receptacle
        Cabinet_bar__minus_02_dot_62_bar__plus_01_dot_93_bar__plus_03_dot_73 - receptacle
        Cabinet_bar__minus_02_dot_95_bar__plus_01_dot_93_bar__plus_03_dot_73 - receptacle
        CoffeeMachine_bar__minus_01_dot_00_bar__plus_00_dot_89_bar__plus_01_dot_03 - receptacle
        CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98 - receptacle
        CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_02_dot_37 - receptacle
        CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80 - receptacle
        DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32 - receptacle
        Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_00_dot_98 - receptacle
        Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_20 - receptacle
        Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_53 - receptacle
        Drawer_bar__minus_02_dot_11_bar__plus_00_dot_71_bar__plus_03_dot_66 - receptacle
        Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13 - receptacle
        GarbageCan_bar__plus_00_dot_93_bar__plus_00_dot_00_bar__plus_02_dot_92 - receptacle
        Microwave_bar__minus_01_dot_53_bar__plus_01_dot_25_bar__plus_03_dot_88 - receptacle
        Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83_bar_SinkBasin - receptacle
        StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_38 - receptacle
        StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_77 - receptacle
        StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_38 - receptacle
        StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_77 - receptacle
        Toaster_bar__minus_02_dot_25_bar__plus_00_dot_81_bar__plus_03_dot_86 - receptacle
        loc_bar__minus_6_bar_13_bar_0_bar_60 - location
        loc_bar__minus_7_bar_11_bar_3_bar_0 - location
        loc_bar__minus_5_bar_13_bar_3_bar_45 - location
        loc_bar_1_bar_10_bar_1_bar_45 - location
        loc_bar_0_bar_6_bar_1_bar_30 - location
        loc_bar_0_bar_7_bar_1_bar_45 - location
        loc_bar__minus_7_bar_6_bar_3_bar_15 - location
        loc_bar__minus_7_bar_11_bar_0_bar_0 - location
        loc_bar__minus_6_bar_13_bar_0_bar__minus_30 - location
        loc_bar__minus_3_bar_12_bar_0_bar_60 - location
        loc_bar_2_bar_12_bar_1_bar_60 - location
        loc_bar_0_bar_5_bar_1_bar_60 - location
        loc_bar__minus_3_bar_10_bar_0_bar_45 - location
        loc_bar__minus_1_bar_10_bar_1_bar_45 - location
        loc_bar__minus_6_bar_9_bar_3_bar__minus_15 - location
        loc_bar_0_bar_7_bar_2_bar_45 - location
        loc_bar__minus_7_bar_12_bar_3_bar__minus_30 - location
        loc_bar__minus_5_bar_10_bar_0_bar_45 - location
        loc_bar__minus_6_bar_13_bar_0_bar_30 - location
        loc_bar_0_bar_7_bar_1_bar_30 - location
        loc_bar__minus_7_bar_9_bar_3_bar_60 - location
        loc_bar__minus_4_bar_8_bar_2_bar_45 - location
        loc_bar_0_bar_8_bar_1_bar_30 - location
        loc_bar__minus_1_bar_12_bar_1_bar_60 - location
        loc_bar__minus_3_bar_8_bar_2_bar_60 - location
        loc_bar__minus_7_bar_7_bar_3_bar__minus_30 - location
        loc_bar_2_bar_14_bar_0_bar_30 - location
        loc_bar__minus_7_bar_12_bar_0_bar_60 - location
        loc_bar__minus_4_bar_8_bar_2_bar_60 - location
        loc_bar__minus_6_bar_13_bar_3_bar__minus_15 - location
        loc_bar_0_bar_5_bar_1_bar_45 - location
        loc_bar_0_bar_5_bar_1_bar_30 - location
        loc_bar__minus_5_bar_8_bar_3_bar_45 - location
        loc_bar_0_bar_6_bar_1_bar_45 - location
        loc_bar__minus_7_bar_12_bar_0_bar_45 - location
        loc_bar__minus_7_bar_6_bar_3_bar__minus_30 - location
        loc_bar__minus_3_bar_13_bar_0_bar_0 - location
        loc_bar__minus_1_bar_11_bar_1_bar_60 - location
        loc_bar__minus_7_bar_6_bar_2_bar_0 - location
        loc_bar__minus_6_bar_12_bar_3_bar_60 - location
        loc_bar__minus_1_bar_12_bar_1_bar_45 - location
        loc_bar_1_bar_10_bar_0_bar_30 - location
        )
    

(:init


        (receptacleType Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_36 CabinetType)
        (receptacleType CoffeeMachine_bar__minus_01_dot_00_bar__plus_00_dot_89_bar__plus_01_dot_03 CoffeeMachineType)
        (receptacleType Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_20 DrawerType)
        (receptacleType Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_42 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_41_bar__plus_01_dot_68 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_69_bar__plus_02_dot_57 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_93_bar__plus_01_dot_69 CabinetType)
        (receptacleType Drawer_bar__minus_02_dot_11_bar__plus_00_dot_71_bar__plus_03_dot_66 DrawerType)
        (receptacleType CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98 CounterTopType)
        (receptacleType Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_53 DrawerType)
        (receptacleType Cabinet_bar__minus_00_dot_42_bar__plus_01_dot_70_bar__plus_03_dot_74 CabinetType)
        (receptacleType Cabinet_bar__minus_00_dot_42_bar__plus_00_dot_67_bar__plus_03_dot_74 CabinetType)
        (receptacleType Cabinet_bar__minus_01_dot_14_bar__plus_00_dot_39_bar__plus_03_dot_52 CabinetType)
        (receptacleType Toaster_bar__minus_02_dot_25_bar__plus_00_dot_81_bar__plus_03_dot_86 ToasterType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_00_dot_64_bar__plus_01_dot_68 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_03_dot_18 CabinetType)
        (receptacleType DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32 DiningTableType)
        (receptacleType Cabinet_bar__minus_01_dot_96_bar__plus_01_dot_93_bar__plus_03_dot_73 CabinetType)
        (receptacleType StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_77 StoveBurnerType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_06 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_95_bar__plus_01_dot_93_bar__plus_03_dot_73 CabinetType)
        (receptacleType CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80 CounterTopType)
        (receptacleType Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_17 CabinetType)
        (receptacleType StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_38 StoveBurnerType)
        (receptacleType Microwave_bar__minus_01_dot_53_bar__plus_01_dot_25_bar__plus_03_dot_88 MicrowaveType)
        (receptacleType Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13 FridgeType)
        (receptacleType StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_77 StoveBurnerType)
        (receptacleType Cabinet_bar__minus_01_dot_10_bar__plus_01_dot_93_bar__plus_03_dot_73 CabinetType)
        (receptacleType Cabinet_bar__minus_01_dot_98_bar__plus_01_dot_78_bar__plus_03_dot_73 CabinetType)
        (receptacleType Cabinet_bar__minus_01_dot_99_bar__plus_00_dot_39_bar__plus_03_dot_51 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_69 CabinetType)
        (receptacleType StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_38 StoveBurnerType)
        (receptacleType CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_02_dot_37 CounterTopType)
        (receptacleType GarbageCan_bar__plus_00_dot_93_bar__plus_00_dot_00_bar__plus_02_dot_92 GarbageCanType)
        (receptacleType Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83_bar_SinkBasin SinkBasinType)
        (receptacleType Cabinet_bar__minus_01_dot_97_bar__plus_00_dot_39_bar__plus_03_dot_52 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_00_dot_82 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_69 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_02_dot_56 CabinetType)
        (receptacleType Cabinet_bar__minus_02_dot_62_bar__plus_01_dot_93_bar__plus_03_dot_73 CabinetType)
        (receptacleType Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_00_dot_98 DrawerType)
        (objectType LightSwitch_bar__plus_00_dot_83_bar__plus_01_dot_40_bar__plus_04_dot_08 LightSwitchType)
        (objectType Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83 SinkType)
        (objectType Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50 SpoonType)
        (objectType Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25 AppleType)
        (objectType Chair_bar__minus_00_dot_87_bar__plus_00_dot_49_bar__plus_01_dot_50 ChairType)
        (objectType Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28 TomatoType)
        (objectType Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73 EggType)
        (objectType Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84 AppleType)
        (objectType Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94 SpatulaType)
        (objectType Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56 SpoonType)
        (objectType SoapBottle_bar__plus_00_dot_95_bar__plus_00_dot_82_bar__plus_00_dot_98 SoapBottleType)
        (objectType Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74 PanType)
        (objectType DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35 DishSpongeType)
        (objectType Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90 PlateType)
        (objectType Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14 ForkType)
        (objectType Window_bar__minus_01_dot_13_bar__plus_01_dot_67_bar__plus_00_dot_81 WindowType)
        (objectType StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_32 StoveKnobType)
        (objectType Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17 MugType)
        (objectType SaltShaker_bar__minus_00_dot_59_bar__plus_00_dot_16_bar__plus_03_dot_81 SaltShakerType)
        (objectType Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90 PlateType)
        (objectType Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68 BowlType)
        (objectType Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36 LettuceType)
        (objectType Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90 KnifeType)
        (objectType StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_73 StoveKnobType)
        (objectType DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92 DishSpongeType)
        (objectType PaperTowelRoll_bar__minus_00_dot_66_bar__plus_01_dot_00_bar__plus_01_dot_04 PaperTowelRollType)
        (objectType Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98 ForkType)
        (objectType Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33 BowlType)
        (objectType PepperShaker_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_98 PepperShakerType)
        (objectType ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35 ButterKnifeType)
        (objectType Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25 MugType)
        (objectType Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86 EggType)
        (objectType Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39 PotatoType)
        (objectType PepperShaker_bar__minus_02_dot_62_bar__plus_01_dot_85_bar__plus_01_dot_85 PepperShakerType)
        (objectType Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85 CupType)
        (objectType StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_89 StoveKnobType)
        (objectType Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20 PlateType)
        (objectType Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45 BreadType)
        (objectType Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56 EggType)
        (objectType StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_48 StoveKnobType)
        (objectType Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77 PotType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CoffeeMachineType MugType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DiningTableType SaltShakerType)
        (canContain DiningTableType BreadType)
        (canContain DiningTableType DishSpongeType)
        (canContain DiningTableType BowlType)
        (canContain DiningTableType PotType)
        (canContain DiningTableType MugType)
        (canContain DiningTableType EggType)
        (canContain DiningTableType ForkType)
        (canContain DiningTableType SpoonType)
        (canContain DiningTableType SoapBottleType)
        (canContain DiningTableType LettuceType)
        (canContain DiningTableType PotatoType)
        (canContain DiningTableType ButterKnifeType)
        (canContain DiningTableType CupType)
        (canContain DiningTableType PlateType)
        (canContain DiningTableType PepperShakerType)
        (canContain DiningTableType TomatoType)
        (canContain DiningTableType KnifeType)
        (canContain DiningTableType AppleType)
        (canContain DiningTableType PanType)
        (canContain DiningTableType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BreadType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType BowlType)
        (canContain FridgeType BreadType)
        (canContain FridgeType BowlType)
        (canContain FridgeType PotType)
        (canContain FridgeType MugType)
        (canContain FridgeType EggType)
        (canContain FridgeType LettuceType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType CupType)
        (canContain FridgeType PlateType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType PanType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType LettuceType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType AppleType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType LettuceType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (pickupable Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50)
        (pickupable Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25)
        (pickupable Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28)
        (pickupable Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73)
        (pickupable Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84)
        (pickupable Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94)
        (pickupable Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56)
        (pickupable SoapBottle_bar__plus_00_dot_95_bar__plus_00_dot_82_bar__plus_00_dot_98)
        (pickupable Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74)
        (pickupable DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35)
        (pickupable Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90)
        (pickupable Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14)
        (pickupable Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        (pickupable SaltShaker_bar__minus_00_dot_59_bar__plus_00_dot_16_bar__plus_03_dot_81)
        (pickupable Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90)
        (pickupable Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68)
        (pickupable Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36)
        (pickupable Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90)
        (pickupable DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92)
        (pickupable PaperTowelRoll_bar__minus_00_dot_66_bar__plus_01_dot_00_bar__plus_01_dot_04)
        (pickupable Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98)
        (pickupable Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33)
        (pickupable PepperShaker_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_98)
        (pickupable ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35)
        (pickupable Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25)
        (pickupable Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86)
        (pickupable Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39)
        (pickupable PepperShaker_bar__minus_02_dot_62_bar__plus_01_dot_85_bar__plus_01_dot_85)
        (pickupable Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85)
        (pickupable Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20)
        (pickupable Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45)
        (pickupable Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56)
        (pickupable Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77)
        (isReceptacleObject Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74)
        (isReceptacleObject Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90)
        (isReceptacleObject Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        (isReceptacleObject Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90)
        (isReceptacleObject Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68)
        (isReceptacleObject Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33)
        (isReceptacleObject Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25)
        (isReceptacleObject Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85)
        (isReceptacleObject Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20)
        (isReceptacleObject Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77)
        (openable Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_36)
        (openable Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_20)
        (openable Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_42)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_41_bar__plus_01_dot_68)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_69_bar__plus_02_dot_57)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_93_bar__plus_01_dot_69)
        (openable Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_53)
        (openable Cabinet_bar__minus_00_dot_42_bar__plus_01_dot_70_bar__plus_03_dot_74)
        (openable Cabinet_bar__minus_00_dot_42_bar__plus_00_dot_67_bar__plus_03_dot_74)
        (openable Cabinet_bar__minus_01_dot_14_bar__plus_00_dot_39_bar__plus_03_dot_52)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_00_dot_64_bar__plus_01_dot_68)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_03_dot_18)
        (openable Cabinet_bar__minus_01_dot_96_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_06)
        (openable Cabinet_bar__minus_02_dot_95_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (openable Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_17)
        (openable Microwave_bar__minus_01_dot_53_bar__plus_01_dot_25_bar__plus_03_dot_88)
        (openable Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13)
        (openable Cabinet_bar__minus_01_dot_10_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (openable Cabinet_bar__minus_01_dot_98_bar__plus_01_dot_78_bar__plus_03_dot_73)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_69)
        (openable Cabinet_bar__minus_01_dot_97_bar__plus_00_dot_39_bar__plus_03_dot_52)
        (openable Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_69)
        (openable Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_02_dot_56)
        (openable Cabinet_bar__minus_02_dot_62_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (openable Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_00_dot_98)
        
        (atLocation agent1 loc_bar_1_bar_10_bar_0_bar_30)
        
        (cleanable Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50)
        (cleanable Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25)
        (cleanable Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28)
        (cleanable Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73)
        (cleanable Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84)
        (cleanable Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94)
        (cleanable Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56)
        (cleanable Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74)
        (cleanable DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35)
        (cleanable Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90)
        (cleanable Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14)
        (cleanable Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        (cleanable Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90)
        (cleanable Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68)
        (cleanable Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36)
        (cleanable Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90)
        (cleanable DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92)
        (cleanable Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98)
        (cleanable Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33)
        (cleanable ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35)
        (cleanable Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25)
        (cleanable Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86)
        (cleanable Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39)
        (cleanable Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85)
        (cleanable Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20)
        (cleanable Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56)
        (cleanable Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77)
        
        (heatable Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25)
        (heatable Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28)
        (heatable Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73)
        (heatable Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84)
        (heatable Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90)
        (heatable Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        (heatable Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90)
        (heatable Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25)
        (heatable Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86)
        (heatable Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39)
        (heatable Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85)
        (heatable Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20)
        (heatable Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45)
        (heatable Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56)
        (coolable Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25)
        (coolable Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28)
        (coolable Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73)
        (coolable Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84)
        (coolable Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74)
        (coolable Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90)
        (coolable Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        (coolable Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90)
        (coolable Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68)
        (coolable Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36)
        (coolable Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33)
        (coolable Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25)
        (coolable Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86)
        (coolable Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39)
        (coolable Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85)
        (coolable Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20)
        (coolable Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45)
        (coolable Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56)
        (coolable Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77)
        
        (isCool Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17)
        
        
        
        (sliceable Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25)
        (sliceable Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28)
        (sliceable Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73)
        (sliceable Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84)
        (sliceable Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36)
        (sliceable Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86)
        (sliceable Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39)
        (sliceable Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45)
        (sliceable Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56)
        
        (inReceptacle Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50 Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_53)
        (inReceptacle Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85 CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98)
        (inReceptacle SoapBottle_bar__plus_00_dot_95_bar__plus_00_dot_82_bar__plus_00_dot_98 CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98)
        (inReceptacle Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98 CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98)
        (inReceptacle PepperShaker_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_98 CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98)
        (inReceptacle Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45 CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_02_dot_37)
        (inReceptacle SaltShaker_bar__minus_00_dot_59_bar__plus_00_dot_16_bar__plus_03_dot_81 Cabinet_bar__minus_00_dot_42_bar__plus_00_dot_67_bar__plus_03_dot_74)
        (inReceptacle DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35 Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_02_dot_56)
        (inReceptacle Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90 Cabinet_bar__minus_02_dot_95_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (inReceptacle Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20 Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_36)
        (inReceptacle PaperTowelRoll_bar__minus_00_dot_66_bar__plus_01_dot_00_bar__plus_01_dot_04 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36 DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32)
        (inReceptacle Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77 StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_77)
        (inReceptacle Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68 Cabinet_bar__minus_01_dot_97_bar__plus_00_dot_39_bar__plus_03_dot_52)
        (inReceptacle Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90 CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80)
        (inReceptacle Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74 CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80)
        (inReceptacle Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33 CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80)
        (inReceptacle PepperShaker_bar__minus_02_dot_62_bar__plus_01_dot_85_bar__plus_01_dot_85 Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_69)
        (inReceptacle Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90 Cabinet_bar__minus_01_dot_10_bar__plus_01_dot_93_bar__plus_03_dot_73)
        (inReceptacle Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84 Microwave_bar__minus_01_dot_53_bar__plus_01_dot_25_bar__plus_03_dot_88)
        (inReceptacle Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17 Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13)
        (inReceptacle Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39 Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13)
        (inReceptacle Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28 Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13)
        (inReceptacle DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92 GarbageCan_bar__plus_00_dot_93_bar__plus_00_dot_00_bar__plus_02_dot_92)
        (inReceptacle Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73 Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83_bar_SinkBasin)
        (inReceptacle Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86 Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83_bar_SinkBasin)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_00_dot_82 loc_bar_0_bar_5_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_36 loc_bar__minus_1_bar_11_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_58_bar__plus_00_dot_39_bar__plus_02_dot_69 loc_bar__minus_1_bar_12_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_42_bar__plus_00_dot_67_bar__plus_03_dot_74 loc_bar__minus_3_bar_12_bar_0_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_42_bar__plus_01_dot_70_bar__plus_03_dot_74 loc_bar__minus_3_bar_13_bar_0_bar_0)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_10_bar__plus_01_dot_93_bar__plus_03_dot_73 loc_bar__minus_6_bar_13_bar_0_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_14_bar__plus_00_dot_39_bar__plus_03_dot_52 loc_bar__minus_3_bar_10_bar_0_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_96_bar__plus_01_dot_93_bar__plus_03_dot_73 loc_bar__minus_6_bar_13_bar_0_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_97_bar__plus_00_dot_39_bar__plus_03_dot_52 loc_bar__minus_5_bar_10_bar_0_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_98_bar__plus_01_dot_78_bar__plus_03_dot_73 loc_bar__minus_7_bar_11_bar_0_bar_0)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_99_bar__plus_00_dot_39_bar__plus_03_dot_51 loc_bar__minus_7_bar_12_bar_0_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_00_dot_64_bar__plus_01_dot_68 loc_bar__minus_5_bar_8_bar_3_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_41_bar__plus_01_dot_68 loc_bar__minus_7_bar_6_bar_3_bar_15)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_69_bar__plus_02_dot_57 loc_bar__minus_7_bar_11_bar_3_bar_0)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_01_dot_93_bar__plus_01_dot_69 loc_bar__minus_7_bar_6_bar_3_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_06 loc_bar__minus_7_bar_6_bar_3_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_01_dot_69 loc_bar__minus_7_bar_7_bar_3_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_02_dot_56 loc_bar__minus_6_bar_9_bar_3_bar__minus_15)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_38_bar__plus_02_dot_01_bar__plus_03_dot_18 loc_bar__minus_7_bar_12_bar_3_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_17 loc_bar__minus_5_bar_13_bar_3_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_43_bar__plus_00_dot_44_bar__plus_03_dot_42 loc_bar__minus_6_bar_12_bar_3_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_62_bar__plus_01_dot_93_bar__plus_03_dot_73 loc_bar__minus_6_bar_13_bar_3_bar__minus_15)
        (receptacleAtLocation Cabinet_bar__minus_02_dot_95_bar__plus_01_dot_93_bar__plus_03_dot_73 loc_bar__minus_6_bar_13_bar_3_bar__minus_15)
        (receptacleAtLocation CoffeeMachine_bar__minus_01_dot_00_bar__plus_00_dot_89_bar__plus_01_dot_03 loc_bar__minus_4_bar_8_bar_2_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_00_dot_98 loc_bar_0_bar_5_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_86_bar__plus_00_dot_86_bar__plus_02_dot_37 loc_bar_1_bar_10_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__minus_02_dot_08_bar__plus_00_dot_86_bar__plus_03_dot_80 loc_bar__minus_7_bar_12_bar_0_bar_45)
        (receptacleAtLocation DiningTable_bar__minus_00_dot_88_bar__plus_00_dot_01_bar__plus_01_dot_32 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_00_dot_98 loc_bar_0_bar_7_bar_2_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_20 loc_bar__minus_1_bar_10_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_73_bar__plus_00_dot_70_bar__plus_02_dot_53 loc_bar__minus_1_bar_12_bar_1_bar_45)
        (receptacleAtLocation Drawer_bar__minus_02_dot_11_bar__plus_00_dot_71_bar__plus_03_dot_66 loc_bar__minus_7_bar_12_bar_0_bar_60)
        (receptacleAtLocation Fridge_bar__minus_02_dot_64_bar__plus_00_dot_00_bar__plus_02_dot_13 loc_bar__minus_7_bar_9_bar_3_bar_60)
        (receptacleAtLocation GarbageCan_bar__plus_00_dot_93_bar__plus_00_dot_00_bar__plus_02_dot_92 loc_bar_2_bar_12_bar_1_bar_60)
        (receptacleAtLocation Microwave_bar__minus_01_dot_53_bar__plus_01_dot_25_bar__plus_03_dot_88 loc_bar__minus_6_bar_13_bar_0_bar_30)
        (receptacleAtLocation Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83_bar_SinkBasin loc_bar__minus_6_bar_13_bar_0_bar_60)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_38 loc_bar_0_bar_6_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_64_bar__plus_00_dot_84_bar__plus_01_dot_77 loc_bar_0_bar_7_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_38 loc_bar_0_bar_6_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_91_bar__plus_00_dot_84_bar__plus_01_dot_77 loc_bar_0_bar_7_bar_1_bar_45)
        (receptacleAtLocation Toaster_bar__minus_02_dot_25_bar__plus_00_dot_81_bar__plus_03_dot_86 loc_bar__minus_7_bar_12_bar_0_bar_45)
        (objectAtLocation Bowl_bar__minus_02_dot_85_bar__plus_00_dot_82_bar__plus_03_dot_33 loc_bar__minus_7_bar_12_bar_0_bar_45)
        (objectAtLocation Mug_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_25 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation Apple_bar__minus_01_dot_49_bar__plus_01_dot_42_bar__plus_03_dot_84 loc_bar__minus_6_bar_13_bar_0_bar_30)
        (objectAtLocation Spoon_bar__minus_00_dot_66_bar__plus_00_dot_90_bar__plus_01_dot_56 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation DishSponge_bar__plus_00_dot_93_bar__plus_00_dot_02_bar__plus_02_dot_92 loc_bar_2_bar_12_bar_1_bar_60)
        (objectAtLocation PepperShaker_bar__minus_02_dot_62_bar__plus_01_dot_85_bar__plus_01_dot_85 loc_bar__minus_7_bar_7_bar_3_bar__minus_30)
        (objectAtLocation Egg_bar__minus_01_dot_91_bar__plus_00_dot_73_bar__plus_03_dot_73 loc_bar__minus_6_bar_13_bar_0_bar_60)
        (objectAtLocation Fork_bar__plus_00_dot_73_bar__plus_00_dot_82_bar__plus_00_dot_98 loc_bar_0_bar_5_bar_1_bar_45)
        (objectAtLocation Plate_bar__minus_02_dot_79_bar__plus_01_dot_40_bar__plus_03_dot_90 loc_bar__minus_6_bar_13_bar_3_bar__minus_15)
        (objectAtLocation Plate_bar__plus_00_dot_74_bar__plus_00_dot_13_bar__plus_02_dot_20 loc_bar__minus_1_bar_11_bar_1_bar_60)
        (objectAtLocation Egg_bar__minus_01_dot_31_bar__plus_00_dot_73_bar__plus_03_dot_86 loc_bar__minus_6_bar_13_bar_0_bar_60)
        (objectAtLocation Sink_bar__minus_01_dot_70_bar__plus_00_dot_73_bar__plus_03_dot_83 loc_bar__minus_6_bar_13_bar_0_bar_60)
        (objectAtLocation Plate_bar__minus_01_dot_31_bar__plus_01_dot_69_bar__plus_03_dot_90 loc_bar__minus_6_bar_13_bar_0_bar__minus_30)
        (objectAtLocation Fork_bar__minus_00_dot_52_bar__plus_00_dot_90_bar__plus_01_dot_14 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation LightSwitch_bar__plus_00_dot_83_bar__plus_01_dot_40_bar__plus_04_dot_08 loc_bar_2_bar_14_bar_0_bar_30)
        (objectAtLocation Bread_bar__plus_00_dot_83_bar__plus_00_dot_86_bar__plus_02_dot_45 loc_bar_1_bar_10_bar_1_bar_45)
        (objectAtLocation Chair_bar__minus_00_dot_87_bar__plus_00_dot_49_bar__plus_01_dot_50 loc_bar__minus_3_bar_8_bar_2_bar_60)
        (objectAtLocation Window_bar__minus_01_dot_13_bar__plus_01_dot_67_bar__plus_00_dot_81 loc_bar__minus_7_bar_6_bar_2_bar_0)
        (objectAtLocation Spatula_bar__minus_00_dot_66_bar__plus_00_dot_92_bar__plus_00_dot_94 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation PaperTowelRoll_bar__minus_00_dot_66_bar__plus_01_dot_00_bar__plus_01_dot_04 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation Potato_bar__minus_02_dot_52_bar__plus_00_dot_81_bar__plus_02_dot_39 loc_bar__minus_7_bar_9_bar_3_bar_60)
        (objectAtLocation SoapBottle_bar__plus_00_dot_95_bar__plus_00_dot_82_bar__plus_00_dot_98 loc_bar_0_bar_5_bar_1_bar_45)
        (objectAtLocation Egg_bar__minus_00_dot_52_bar__plus_00_dot_94_bar__plus_01_dot_56 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation Cup_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_85 loc_bar_0_bar_5_bar_1_bar_45)
        (objectAtLocation Pot_bar__plus_00_dot_91_bar__plus_00_dot_85_bar__plus_01_dot_77 loc_bar_0_bar_7_bar_1_bar_45)
        (objectAtLocation SaltShaker_bar__minus_00_dot_59_bar__plus_00_dot_16_bar__plus_03_dot_81 loc_bar__minus_3_bar_12_bar_0_bar_60)
        (objectAtLocation Pan_bar__minus_02_dot_67_bar__plus_00_dot_81_bar__plus_03_dot_74 loc_bar__minus_7_bar_12_bar_0_bar_45)
        (objectAtLocation PepperShaker_bar__plus_01_dot_10_bar__plus_00_dot_82_bar__plus_00_dot_98 loc_bar_0_bar_5_bar_1_bar_45)
        (objectAtLocation ButterKnife_bar__minus_00_dot_92_bar__plus_00_dot_90_bar__plus_01_dot_35 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_89 loc_bar_0_bar_8_bar_1_bar_30)
        (objectAtLocation StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_73 loc_bar_0_bar_7_bar_1_bar_30)
        (objectAtLocation StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_32 loc_bar_0_bar_5_bar_1_bar_30)
        (objectAtLocation StoveKnob_bar__plus_01_dot_10_bar__plus_01_dot_00_bar__plus_01_dot_48 loc_bar_0_bar_6_bar_1_bar_30)
        (objectAtLocation Tomato_bar__minus_02_dot_69_bar__plus_00_dot_84_bar__plus_02_dot_28 loc_bar__minus_7_bar_9_bar_3_bar_60)
        (objectAtLocation DishSponge_bar__minus_02_dot_58_bar__plus_01_dot_85_bar__plus_02_dot_35 loc_bar__minus_6_bar_9_bar_3_bar__minus_15)
        (objectAtLocation Lettuce_bar__minus_00_dot_58_bar__plus_00_dot_96_bar__plus_01_dot_36 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation Spoon_bar__plus_00_dot_67_bar__plus_00_dot_69_bar__plus_02_dot_50 loc_bar__minus_1_bar_12_bar_1_bar_45)
        (objectAtLocation Apple_bar__minus_01_dot_32_bar__plus_00_dot_96_bar__plus_01_dot_25 loc_bar__minus_4_bar_8_bar_2_bar_60)
        (objectAtLocation Knife_bar__minus_01_dot_12_bar__plus_00_dot_85_bar__plus_03_dot_90 loc_bar__minus_7_bar_12_bar_0_bar_45)
        (objectAtLocation Mug_bar__minus_02_dot_65_bar__plus_01_dot_60_bar__plus_02_dot_17 loc_bar__minus_7_bar_9_bar_3_bar_60)
        (objectAtLocation Bowl_bar__minus_01_dot_72_bar__plus_00_dot_13_bar__plus_03_dot_68 loc_bar__minus_5_bar_10_bar_0_bar_45)
        )
    

        (:goal
            (and
                (exists (?r - receptacle)
                    (exists (?o - object)
                        (and
                            (cleanable ?o)
                            (objectType ?o MugType)
                            (receptacleType ?r CoffeeMachineType)
                            (isClean ?o)
                            (inReceptacle ?o ?r)
                        )
                    )
                )
            )
        )
    )
    