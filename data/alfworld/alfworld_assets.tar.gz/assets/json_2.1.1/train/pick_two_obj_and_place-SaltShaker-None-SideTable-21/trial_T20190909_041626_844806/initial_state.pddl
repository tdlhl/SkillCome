
(define (problem plan_trial_T20190909_041626_844806)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88 - object
        Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85 - object
        Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71 - object
        Blinds_bar__minus_02_dot_34_bar__plus_02_dot_15_bar__minus_02_dot_44 - object
        Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15 - object
        Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98 - object
        ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51 - object
        ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63 - object
        ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19 - object
        Chair_bar__minus_01_dot_90_bar__minus_00_dot_03_bar__minus_01_dot_87 - object
        Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19 - object
        Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10 - object
        Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61 - object
        DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04 - object
        DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77 - object
        DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61 - object
        Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50 - object
        Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52 - object
        Faucet_bar__plus_01_dot_03_bar__plus_00_dot_87_bar__minus_00_dot_68 - object
        Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52 - object
        Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19 - object
        Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25 - object
        Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25 - object
        Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99 - object
        LightSwitch_bar__plus_01_dot_10_bar__plus_01_dot_37_bar__minus_03_dot_74 - object
        Mirror_bar__plus_01_dot_09_bar__plus_01_dot_60_bar__minus_00_dot_64 - object
        Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36 - object
        Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05 - object
        PepperShaker_bar__plus_00_dot_78_bar__plus_00_dot_66_bar__plus_00_dot_39 - object
        PepperShaker_bar__plus_00_dot_90_bar__plus_00_dot_66_bar__plus_00_dot_57 - object
        PepperShaker_bar__minus_01_dot_54_bar__plus_00_dot_69_bar__minus_03_dot_78 - object
        Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84 - object
        Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09 - object
        Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04 - object
        Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65 - object
        Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04 - object
        Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04 - object
        Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79 - object
        SaltShaker_bar__plus_00_dot_68_bar__plus_00_dot_01_bar__minus_00_dot_83 - object
        SaltShaker_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__plus_00_dot_60 - object
        SaltShaker_bar__plus_00_dot_95_bar__plus_01_dot_46_bar__plus_00_dot_35 - object
        SaltShaker_bar__plus_01_dot_04_bar__plus_00_dot_88_bar__minus_00_dot_91 - object
        Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68 - object
        SoapBottle_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_31 - object
        Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19 - object
        Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63 - object
        Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00 - object
        Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84 - object
        StoveKnob_bar__minus_01_dot_60_bar__plus_00_dot_87_bar__plus_00_dot_52 - object
        StoveKnob_bar__minus_01_dot_75_bar__plus_00_dot_87_bar__plus_00_dot_52 - object
        StoveKnob_bar__minus_01_dot_90_bar__plus_00_dot_87_bar__plus_00_dot_52 - object
        StoveKnob_bar__minus_02_dot_06_bar__plus_00_dot_87_bar__plus_00_dot_52 - object
        Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45 - object
        Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88 - object
        Window_bar__minus_02_dot_42_bar__plus_01_dot_64_bar__minus_02_dot_45 - object
        Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__plus_00_dot_16 - receptacle
        Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43 - receptacle
        Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67 - receptacle
        Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__minus_00_dot_40 - receptacle
        CoffeeMachine_bar__plus_00_dot_88_bar__plus_00_dot_86_bar__minus_01_dot_26 - receptacle
        CounterTop_bar__plus_00_dot_79_bar__plus_00_dot_92_bar__minus_00_dot_11 - receptacle
        DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95 - receptacle
        DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96 - receptacle
        DiningTable_bar__minus_02_dot_17_bar__minus_00_dot_03_bar__minus_03_dot_37 - receptacle
        Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13 - receptacle
        Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96 - receptacle
        GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61 - receptacle
        Microwave_bar__minus_02_dot_01_bar__plus_00_dot_69_bar__minus_03_dot_69 - receptacle
        SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45 - receptacle
        Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68_bar_SinkBasin - receptacle
        StoveBurner_bar__minus_01_dot_55_bar__plus_00_dot_89_bar__plus_00_dot_79 - receptacle
        StoveBurner_bar__minus_01_dot_56_bar__plus_00_dot_89_bar__plus_01_dot_05 - receptacle
        StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_00_dot_79 - receptacle
        StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_01_dot_05 - receptacle
        Toaster_bar__minus_00_dot_52_bar__plus_00_dot_89_bar__plus_01_dot_07 - receptacle
        loc_bar__minus_6_bar_0_bar_0_bar_45 - location
        loc_bar__minus_4_bar__minus_5_bar_3_bar_60 - location
        loc_bar_1_bar__minus_3_bar_1_bar_0 - location
        loc_bar__minus_7_bar_0_bar_0_bar_30 - location
        loc_bar__minus_7_bar__minus_11_bar_2_bar_45 - location
        loc_bar_1_bar_1_bar_1_bar__minus_30 - location
        loc_bar__minus_7_bar_0_bar_0_bar_60 - location
        loc_bar__minus_6_bar_0_bar_0_bar_60 - location
        loc_bar__minus_7_bar__minus_11_bar_2_bar_60 - location
        loc_bar_1_bar__minus_2_bar_1_bar_60 - location
        loc_bar__minus_7_bar_0_bar_0_bar_45 - location
        loc_bar_0_bar_1_bar_0_bar_60 - location
        loc_bar__minus_1_bar__minus_8_bar_1_bar_60 - location
        loc_bar__minus_2_bar__minus_1_bar_1_bar_45 - location
        loc_bar__minus_1_bar__minus_1_bar_1_bar_45 - location
        loc_bar__minus_6_bar_0_bar_0_bar_30 - location
        loc_bar__minus_7_bar__minus_10_bar_3_bar_0 - location
        loc_bar_1_bar_0_bar_1_bar_45 - location
        loc_bar_2_bar__minus_13_bar_1_bar_30 - location
        loc_bar_0_bar__minus_5_bar_1_bar_45 - location
        loc_bar__minus_1_bar_1_bar_1_bar_45 - location
        loc_bar__minus_4_bar__minus_13_bar_2_bar_60 - location
        loc_bar__minus_2_bar_1_bar_1_bar_45 - location
        loc_bar_1_bar__minus_3_bar_1_bar_60 - location
        loc_bar__minus_2_bar_1_bar_0_bar_45 - location
        loc_bar__minus_5_bar__minus_7_bar_3_bar_60 - location
        loc_bar_1_bar_0_bar_1_bar__minus_30 - location
        loc_bar__minus_7_bar__minus_10_bar_3_bar__minus_30 - location
        loc_bar__minus_1_bar__minus_4_bar_3_bar_30 - location
        )
    

(:init


        (receptacleType Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96 FridgeType)
        (receptacleType StoveBurner_bar__minus_01_dot_55_bar__plus_00_dot_89_bar__plus_00_dot_79 StoveBurnerType)
        (receptacleType CoffeeMachine_bar__plus_00_dot_88_bar__plus_00_dot_86_bar__minus_01_dot_26 CoffeeMachineType)
        (receptacleType GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61 GarbageCanType)
        (receptacleType SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45 SideTableType)
        (receptacleType Microwave_bar__minus_02_dot_01_bar__plus_00_dot_69_bar__minus_03_dot_69 MicrowaveType)
        (receptacleType Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67 CabinetType)
        (receptacleType CounterTop_bar__plus_00_dot_79_bar__plus_00_dot_92_bar__minus_00_dot_11 CounterTopType)
        (receptacleType Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__minus_00_dot_40 CabinetType)
        (receptacleType Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68_bar_SinkBasin SinkBasinType)
        (receptacleType Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__plus_00_dot_16 CabinetType)
        (receptacleType DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96 DiningTableType)
        (receptacleType Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13 DrawerType)
        (receptacleType Toaster_bar__minus_00_dot_52_bar__plus_00_dot_89_bar__plus_01_dot_07 ToasterType)
        (receptacleType StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_00_dot_79 StoveBurnerType)
        (receptacleType DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95 DiningTableType)
        (receptacleType StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_01_dot_05 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43 CabinetType)
        (receptacleType DiningTable_bar__minus_02_dot_17_bar__minus_00_dot_03_bar__minus_03_dot_37 DiningTableType)
        (receptacleType StoveBurner_bar__minus_01_dot_56_bar__plus_00_dot_89_bar__plus_01_dot_05 StoveBurnerType)
        (objectType Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25 KnifeType)
        (objectType StoveKnob_bar__minus_01_dot_90_bar__plus_00_dot_87_bar__plus_00_dot_52 StoveKnobType)
        (objectType ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51 ButterKnifeType)
        (objectType StoveKnob_bar__minus_01_dot_60_bar__plus_00_dot_87_bar__plus_00_dot_52 StoveKnobType)
        (objectType Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19 KnifeType)
        (objectType Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65 PotatoType)
        (objectType DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61 DishSpongeType)
        (objectType DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77 DishSpongeType)
        (objectType StoveKnob_bar__minus_02_dot_06_bar__plus_00_dot_87_bar__plus_00_dot_52 StoveKnobType)
        (objectType StoveKnob_bar__minus_01_dot_75_bar__plus_00_dot_87_bar__plus_00_dot_52 StoveKnobType)
        (objectType Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52 EggType)
        (objectType Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05 PanType)
        (objectType Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45 TomatoType)
        (objectType Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52 ForkType)
        (objectType Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61 CupType)
        (objectType Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19 SpatulaType)
        (objectType ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19 ButterKnifeType)
        (objectType Mirror_bar__plus_01_dot_09_bar__plus_01_dot_60_bar__minus_00_dot_64 MirrorType)
        (objectType Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25 KnifeType)
        (objectType SaltShaker_bar__plus_00_dot_68_bar__plus_00_dot_01_bar__minus_00_dot_83 SaltShakerType)
        (objectType Window_bar__minus_02_dot_42_bar__plus_01_dot_64_bar__minus_02_dot_45 WindowType)
        (objectType Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84 SpoonType)
        (objectType Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99 LettuceType)
        (objectType Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04 PotType)
        (objectType Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04 PotatoType)
        (objectType Blinds_bar__minus_02_dot_34_bar__plus_02_dot_15_bar__minus_02_dot_44 BlindsType)
        (objectType Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04 PotType)
        (objectType Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19 CupType)
        (objectType Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84 PlateType)
        (objectType DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04 DishSpongeType)
        (objectType SaltShaker_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__plus_00_dot_60 SaltShakerType)
        (objectType Chair_bar__minus_01_dot_90_bar__minus_00_dot_03_bar__minus_01_dot_87 ChairType)
        (objectType Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09 PlateType)
        (objectType Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50 EggType)
        (objectType ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63 ButterKnifeType)
        (objectType Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36 MugType)
        (objectType Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15 BowlType)
        (objectType Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88 AppleType)
        (objectType SoapBottle_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_31 SoapBottleType)
        (objectType PepperShaker_bar__minus_01_dot_54_bar__plus_00_dot_69_bar__minus_03_dot_78 PepperShakerType)
        (objectType PepperShaker_bar__plus_00_dot_90_bar__plus_00_dot_66_bar__plus_00_dot_57 PepperShakerType)
        (objectType LightSwitch_bar__plus_01_dot_10_bar__plus_01_dot_37_bar__minus_03_dot_74 LightSwitchType)
        (objectType Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68 SinkType)
        (objectType Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71 AppleType)
        (objectType Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85 AppleType)
        (objectType Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00 SpatulaType)
        (objectType SaltShaker_bar__plus_00_dot_95_bar__plus_01_dot_46_bar__plus_00_dot_35 SaltShakerType)
        (objectType Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79 PotType)
        (objectType Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63 SpatulaType)
        (objectType Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88 TomatoType)
        (objectType PepperShaker_bar__plus_00_dot_78_bar__plus_00_dot_66_bar__plus_00_dot_39 PepperShakerType)
        (objectType Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10 CupType)
        (objectType Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98 BreadType)
        (objectType SaltShaker_bar__plus_01_dot_04_bar__plus_00_dot_88_bar__minus_00_dot_91 SaltShakerType)
        (canContain FridgeType BreadType)
        (canContain FridgeType BowlType)
        (canContain FridgeType PotType)
        (canContain FridgeType MugType)
        (canContain FridgeType EggType)
        (canContain FridgeType LettuceType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType CupType)
        (canContain FridgeType PlateType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType PanType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CoffeeMachineType MugType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType LettuceType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType AppleType)
        (canContain SideTableType SaltShakerType)
        (canContain SideTableType BreadType)
        (canContain SideTableType DishSpongeType)
        (canContain SideTableType BowlType)
        (canContain SideTableType PotType)
        (canContain SideTableType MugType)
        (canContain SideTableType EggType)
        (canContain SideTableType ForkType)
        (canContain SideTableType SpoonType)
        (canContain SideTableType SoapBottleType)
        (canContain SideTableType LettuceType)
        (canContain SideTableType PotatoType)
        (canContain SideTableType ButterKnifeType)
        (canContain SideTableType CupType)
        (canContain SideTableType PlateType)
        (canContain SideTableType PepperShakerType)
        (canContain SideTableType TomatoType)
        (canContain SideTableType KnifeType)
        (canContain SideTableType AppleType)
        (canContain SideTableType PanType)
        (canContain SideTableType SpatulaType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BreadType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType BowlType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType BreadType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType LettuceType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType SpatulaType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DiningTableType SaltShakerType)
        (canContain DiningTableType BreadType)
        (canContain DiningTableType DishSpongeType)
        (canContain DiningTableType BowlType)
        (canContain DiningTableType PotType)
        (canContain DiningTableType MugType)
        (canContain DiningTableType EggType)
        (canContain DiningTableType ForkType)
        (canContain DiningTableType SpoonType)
        (canContain DiningTableType SoapBottleType)
        (canContain DiningTableType LettuceType)
        (canContain DiningTableType PotatoType)
        (canContain DiningTableType ButterKnifeType)
        (canContain DiningTableType CupType)
        (canContain DiningTableType PlateType)
        (canContain DiningTableType PepperShakerType)
        (canContain DiningTableType TomatoType)
        (canContain DiningTableType KnifeType)
        (canContain DiningTableType AppleType)
        (canContain DiningTableType PanType)
        (canContain DiningTableType SpatulaType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType DishSpongeType)
        (canContain DrawerType ForkType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain DiningTableType SaltShakerType)
        (canContain DiningTableType BreadType)
        (canContain DiningTableType DishSpongeType)
        (canContain DiningTableType BowlType)
        (canContain DiningTableType PotType)
        (canContain DiningTableType MugType)
        (canContain DiningTableType EggType)
        (canContain DiningTableType ForkType)
        (canContain DiningTableType SpoonType)
        (canContain DiningTableType SoapBottleType)
        (canContain DiningTableType LettuceType)
        (canContain DiningTableType PotatoType)
        (canContain DiningTableType ButterKnifeType)
        (canContain DiningTableType CupType)
        (canContain DiningTableType PlateType)
        (canContain DiningTableType PepperShakerType)
        (canContain DiningTableType TomatoType)
        (canContain DiningTableType KnifeType)
        (canContain DiningTableType AppleType)
        (canContain DiningTableType PanType)
        (canContain DiningTableType SpatulaType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType BowlType)
        (canContain CabinetType PotType)
        (canContain CabinetType MugType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PlateType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType PanType)
        (canContain DiningTableType SaltShakerType)
        (canContain DiningTableType BreadType)
        (canContain DiningTableType DishSpongeType)
        (canContain DiningTableType BowlType)
        (canContain DiningTableType PotType)
        (canContain DiningTableType MugType)
        (canContain DiningTableType EggType)
        (canContain DiningTableType ForkType)
        (canContain DiningTableType SpoonType)
        (canContain DiningTableType SoapBottleType)
        (canContain DiningTableType LettuceType)
        (canContain DiningTableType PotatoType)
        (canContain DiningTableType ButterKnifeType)
        (canContain DiningTableType CupType)
        (canContain DiningTableType PlateType)
        (canContain DiningTableType PepperShakerType)
        (canContain DiningTableType TomatoType)
        (canContain DiningTableType KnifeType)
        (canContain DiningTableType AppleType)
        (canContain DiningTableType PanType)
        (canContain DiningTableType SpatulaType)
        (canContain StoveBurnerType PotType)
        (canContain StoveBurnerType PanType)
        (pickupable Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25)
        (pickupable ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51)
        (pickupable Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19)
        (pickupable Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65)
        (pickupable DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61)
        (pickupable DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77)
        (pickupable Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52)
        (pickupable Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05)
        (pickupable Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45)
        (pickupable Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52)
        (pickupable Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61)
        (pickupable Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19)
        (pickupable ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19)
        (pickupable Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25)
        (pickupable SaltShaker_bar__plus_00_dot_68_bar__plus_00_dot_01_bar__minus_00_dot_83)
        (pickupable Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84)
        (pickupable Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99)
        (pickupable Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04)
        (pickupable Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04)
        (pickupable Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04)
        (pickupable Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19)
        (pickupable Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84)
        (pickupable DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04)
        (pickupable SaltShaker_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__plus_00_dot_60)
        (pickupable Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09)
        (pickupable Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50)
        (pickupable ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63)
        (pickupable Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36)
        (pickupable Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15)
        (pickupable Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88)
        (pickupable SoapBottle_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_31)
        (pickupable PepperShaker_bar__minus_01_dot_54_bar__plus_00_dot_69_bar__minus_03_dot_78)
        (pickupable PepperShaker_bar__plus_00_dot_90_bar__plus_00_dot_66_bar__plus_00_dot_57)
        (pickupable Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71)
        (pickupable Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85)
        (pickupable Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00)
        (pickupable SaltShaker_bar__plus_00_dot_95_bar__plus_01_dot_46_bar__plus_00_dot_35)
        (pickupable Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79)
        (pickupable Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63)
        (pickupable Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88)
        (pickupable PepperShaker_bar__plus_00_dot_78_bar__plus_00_dot_66_bar__plus_00_dot_39)
        (pickupable Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10)
        (pickupable Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98)
        (pickupable SaltShaker_bar__plus_01_dot_04_bar__plus_00_dot_88_bar__minus_00_dot_91)
        (isReceptacleObject Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05)
        (isReceptacleObject Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61)
        (isReceptacleObject Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04)
        (isReceptacleObject Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04)
        (isReceptacleObject Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19)
        (isReceptacleObject Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84)
        (isReceptacleObject Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09)
        (isReceptacleObject Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36)
        (isReceptacleObject Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15)
        (isReceptacleObject Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79)
        (isReceptacleObject Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10)
        (openable Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (openable Microwave_bar__minus_02_dot_01_bar__plus_00_dot_69_bar__minus_03_dot_69)
        (openable Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67)
        (openable Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__minus_00_dot_40)
        (openable Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__plus_00_dot_16)
        (openable Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (openable Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43)
        
        (atLocation agent1 loc_bar__minus_1_bar__minus_4_bar_3_bar_30)
        
        (cleanable Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25)
        (cleanable ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51)
        (cleanable Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19)
        (cleanable Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65)
        (cleanable DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61)
        (cleanable DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77)
        (cleanable Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52)
        (cleanable Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05)
        (cleanable Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45)
        (cleanable Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52)
        (cleanable Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61)
        (cleanable Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19)
        (cleanable ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19)
        (cleanable Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25)
        (cleanable Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84)
        (cleanable Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99)
        (cleanable Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04)
        (cleanable Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04)
        (cleanable Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04)
        (cleanable Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19)
        (cleanable Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84)
        (cleanable DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04)
        (cleanable Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09)
        (cleanable Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50)
        (cleanable ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63)
        (cleanable Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36)
        (cleanable Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15)
        (cleanable Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88)
        (cleanable Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71)
        (cleanable Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85)
        (cleanable Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00)
        (cleanable Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79)
        (cleanable Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63)
        (cleanable Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88)
        (cleanable Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10)
        
        (heatable Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65)
        (heatable Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52)
        (heatable Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45)
        (heatable Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61)
        (heatable Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04)
        (heatable Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19)
        (heatable Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84)
        (heatable Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09)
        (heatable Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50)
        (heatable Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36)
        (heatable Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88)
        (heatable Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71)
        (heatable Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85)
        (heatable Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88)
        (heatable Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10)
        (heatable Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98)
        (coolable Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65)
        (coolable Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52)
        (coolable Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05)
        (coolable Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45)
        (coolable Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61)
        (coolable Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99)
        (coolable Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04)
        (coolable Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04)
        (coolable Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04)
        (coolable Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19)
        (coolable Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84)
        (coolable Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09)
        (coolable Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50)
        (coolable Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36)
        (coolable Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15)
        (coolable Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88)
        (coolable Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71)
        (coolable Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85)
        (coolable Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79)
        (coolable Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88)
        (coolable Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10)
        (coolable Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98)
        
        
        
        
        
        (sliceable Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65)
        (sliceable Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52)
        (sliceable Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45)
        (sliceable Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99)
        (sliceable Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04)
        (sliceable Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50)
        (sliceable Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88)
        (sliceable Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71)
        (sliceable Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85)
        (sliceable Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88)
        (sliceable Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98)
        
        (inReceptacle Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19 Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (inReceptacle Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25 Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (inReceptacle Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00 Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (inReceptacle Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25 Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (inReceptacle Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19 Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13)
        (inReceptacle DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04 CounterTop_bar__plus_00_dot_79_bar__plus_00_dot_92_bar__minus_00_dot_11)
        (inReceptacle SaltShaker_bar__plus_01_dot_04_bar__plus_00_dot_88_bar__minus_00_dot_91 CounterTop_bar__plus_00_dot_79_bar__plus_00_dot_92_bar__minus_00_dot_11)
        (inReceptacle Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05 StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_00_dot_79)
        (inReceptacle DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77 Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43)
        (inReceptacle SaltShaker_bar__plus_00_dot_68_bar__plus_00_dot_01_bar__minus_00_dot_83 Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43)
        (inReceptacle Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79 StoveBurner_bar__minus_01_dot_55_bar__plus_00_dot_89_bar__plus_00_dot_79)
        (inReceptacle Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09 DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96)
        (inReceptacle SoapBottle_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_31 DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96)
        (inReceptacle Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52 DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96)
        (inReceptacle Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52 DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96)
        (inReceptacle Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05 StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_01_dot_05)
        (inReceptacle ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51 SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45)
        (inReceptacle ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63 SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45)
        (inReceptacle PepperShaker_bar__plus_00_dot_78_bar__plus_00_dot_66_bar__plus_00_dot_39 SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45)
        (inReceptacle PepperShaker_bar__plus_00_dot_90_bar__plus_00_dot_66_bar__plus_00_dot_57 SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45)
        (inReceptacle Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45 SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45)
        (inReceptacle Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15 Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__minus_00_dot_40)
        (inReceptacle SaltShaker_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__plus_00_dot_60 Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67)
        (inReceptacle SaltShaker_bar__plus_00_dot_95_bar__plus_01_dot_46_bar__plus_00_dot_35 Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67)
        (inReceptacle ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98 DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95)
        (inReceptacle PepperShaker_bar__minus_01_dot_54_bar__plus_00_dot_69_bar__minus_03_dot_78 DiningTable_bar__minus_02_dot_17_bar__minus_00_dot_03_bar__minus_03_dot_37)
        (inReceptacle Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61 DiningTable_bar__minus_02_dot_17_bar__minus_00_dot_03_bar__minus_03_dot_37)
        (inReceptacle Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36 CoffeeMachine_bar__plus_00_dot_88_bar__plus_00_dot_86_bar__minus_01_dot_26)
        (inReceptacle Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65 GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61)
        (inReceptacle DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61 GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61)
        (inReceptacle Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50 GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61)
        (inReceptacle Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19 Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96)
        (inReceptacle Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71 Microwave_bar__minus_02_dot_01_bar__plus_00_dot_69_bar__minus_03_dot_69)
        (inReceptacle Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85 Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68_bar_SinkBasin)
        (inReceptacle Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63 Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68_bar_SinkBasin)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__plus_00_dot_16 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_51_bar__plus_00_dot_35_bar__minus_00_dot_43 loc_bar__minus_2_bar__minus_1_bar_1_bar_45)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__plus_00_dot_67 loc_bar_1_bar_1_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_72_bar__plus_01_dot_82_bar__minus_00_dot_40 loc_bar_1_bar_0_bar_1_bar__minus_30)
        (receptacleAtLocation CoffeeMachine_bar__plus_00_dot_88_bar__plus_00_dot_86_bar__minus_01_dot_26 loc_bar_0_bar__minus_5_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_79_bar__plus_00_dot_92_bar__minus_00_dot_11 loc_bar_1_bar_0_bar_1_bar_45)
        (receptacleAtLocation DiningTable_bar__minus_00_dot_52_bar__plus_00_dot_01_bar__plus_00_dot_95 loc_bar_0_bar_1_bar_0_bar_60)
        (receptacleAtLocation DiningTable_bar__minus_01_dot_73_bar__minus_00_dot_03_bar__minus_00_dot_96 loc_bar__minus_4_bar__minus_5_bar_3_bar_60)
        (receptacleAtLocation DiningTable_bar__minus_02_dot_17_bar__minus_00_dot_03_bar__minus_03_dot_37 loc_bar__minus_7_bar__minus_11_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_71_bar__plus_00_dot_77_bar__minus_00_dot_13 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (receptacleAtLocation Fridge_bar__plus_00_dot_68_bar__minus_00_dot_03_bar__minus_01_dot_96 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_01_dot_26_bar__minus_00_dot_03_bar__minus_03_dot_61 loc_bar__minus_4_bar__minus_13_bar_2_bar_60)
        (receptacleAtLocation Microwave_bar__minus_02_dot_01_bar__plus_00_dot_69_bar__minus_03_dot_69 loc_bar__minus_7_bar__minus_11_bar_2_bar_45)
        (receptacleAtLocation SideTable_bar__plus_00_dot_77_bar__plus_00_dot_70_bar__plus_00_dot_45 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (receptacleAtLocation Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68_bar_SinkBasin loc_bar_1_bar__minus_2_bar_1_bar_60)
        (receptacleAtLocation StoveBurner_bar__minus_01_dot_55_bar__plus_00_dot_89_bar__plus_00_dot_79 loc_bar__minus_6_bar_0_bar_0_bar_45)
        (receptacleAtLocation StoveBurner_bar__minus_01_dot_56_bar__plus_00_dot_89_bar__plus_01_dot_05 loc_bar__minus_6_bar_0_bar_0_bar_30)
        (receptacleAtLocation StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_00_dot_79 loc_bar__minus_7_bar_0_bar_0_bar_45)
        (receptacleAtLocation StoveBurner_bar__minus_02_dot_10_bar__plus_00_dot_89_bar__plus_01_dot_05 loc_bar__minus_7_bar_0_bar_0_bar_30)
        (receptacleAtLocation Toaster_bar__minus_00_dot_52_bar__plus_00_dot_89_bar__plus_01_dot_07 loc_bar__minus_2_bar_1_bar_0_bar_45)
        (objectAtLocation Knife_bar__plus_00_dot_77_bar__plus_00_dot_78_bar__minus_00_dot_25 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Tomato_bar__plus_00_dot_66_bar__plus_00_dot_71_bar__plus_00_dot_45 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (objectAtLocation DishSponge_bar__minus_01_dot_22_bar__plus_00_dot_05_bar__minus_03_dot_61 loc_bar__minus_4_bar__minus_13_bar_2_bar_60)
        (objectAtLocation ButterKnife_bar__plus_00_dot_60_bar__plus_00_dot_67_bar__plus_00_dot_51 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (objectAtLocation PepperShaker_bar__plus_00_dot_78_bar__plus_00_dot_66_bar__plus_00_dot_39 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (objectAtLocation SaltShaker_bar__plus_00_dot_68_bar__plus_00_dot_01_bar__minus_00_dot_83 loc_bar__minus_2_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Cup_bar__plus_00_dot_82_bar__plus_00_dot_66_bar__minus_02_dot_19 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Potato_bar__minus_01_dot_33_bar__plus_00_dot_09_bar__minus_03_dot_65 loc_bar__minus_4_bar__minus_13_bar_2_bar_60)
        (objectAtLocation Spatula_bar__plus_00_dot_67_bar__plus_00_dot_77_bar__minus_00_dot_19 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Egg_bar__minus_01_dot_26_bar__plus_00_dot_09_bar__minus_03_dot_50 loc_bar__minus_4_bar__minus_13_bar_2_bar_60)
        (objectAtLocation Apple_bar__plus_00_dot_79_bar__plus_00_dot_72_bar__minus_01_dot_88 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Plate_bar__minus_01_dot_80_bar__plus_00_dot_71_bar__minus_01_dot_09 loc_bar__minus_4_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Pot_bar__minus_01_dot_55_bar__plus_00_dot_93_bar__plus_00_dot_79 loc_bar__minus_6_bar_0_bar_0_bar_45)
        (objectAtLocation Apple_bar__minus_01_dot_95_bar__plus_00_dot_85_bar__minus_03_dot_71 loc_bar__minus_7_bar__minus_11_bar_2_bar_45)
        (objectAtLocation SaltShaker_bar__plus_01_dot_04_bar__plus_00_dot_88_bar__minus_00_dot_91 loc_bar_1_bar_0_bar_1_bar_45)
        (objectAtLocation SaltShaker_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__plus_00_dot_60 loc_bar_1_bar_1_bar_1_bar__minus_30)
        (objectAtLocation PepperShaker_bar__plus_00_dot_90_bar__plus_00_dot_66_bar__plus_00_dot_57 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (objectAtLocation Knife_bar__plus_00_dot_62_bar__plus_00_dot_78_bar__minus_00_dot_25 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Cup_bar__minus_00_dot_25_bar__plus_00_dot_90_bar__plus_01_dot_10 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation Pot_bar__plus_00_dot_75_bar__plus_01_dot_37_bar__minus_02_dot_04 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Spatula_bar__plus_00_dot_87_bar__plus_00_dot_78_bar__plus_00_dot_00 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation ButterKnife_bar__plus_00_dot_72_bar__plus_00_dot_67_bar__plus_00_dot_63 loc_bar__minus_1_bar_1_bar_1_bar_45)
        (objectAtLocation DishSponge_bar__plus_00_dot_84_bar__plus_00_dot_02_bar__minus_00_dot_77 loc_bar__minus_2_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Mirror_bar__plus_01_dot_09_bar__plus_01_dot_60_bar__minus_00_dot_64 loc_bar_1_bar__minus_3_bar_1_bar_0)
        (objectAtLocation Sink_bar__plus_00_dot_75_bar__plus_00_dot_88_bar__minus_00_dot_68 loc_bar_1_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Pot_bar__plus_00_dot_75_bar__plus_00_dot_47_bar__minus_02_dot_04 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Plate_bar__minus_00_dot_05_bar__plus_00_dot_90_bar__plus_00_dot_84 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation StoveKnob_bar__minus_01_dot_90_bar__plus_00_dot_87_bar__plus_00_dot_52 loc_bar__minus_7_bar_0_bar_0_bar_60)
        (objectAtLocation StoveKnob_bar__minus_01_dot_75_bar__plus_00_dot_87_bar__plus_00_dot_52 loc_bar__minus_7_bar_0_bar_0_bar_60)
        (objectAtLocation StoveKnob_bar__minus_02_dot_06_bar__plus_00_dot_87_bar__plus_00_dot_52 loc_bar__minus_7_bar_0_bar_0_bar_60)
        (objectAtLocation StoveKnob_bar__minus_01_dot_60_bar__plus_00_dot_87_bar__plus_00_dot_52 loc_bar__minus_6_bar_0_bar_0_bar_60)
        (objectAtLocation Fork_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_52 loc_bar__minus_4_bar__minus_5_bar_3_bar_60)
        (objectAtLocation SoapBottle_bar__minus_02_dot_05_bar__plus_00_dot_70_bar__minus_01_dot_31 loc_bar__minus_4_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Apple_bar__plus_00_dot_84_bar__plus_00_dot_83_bar__minus_00_dot_85 loc_bar_1_bar__minus_2_bar_1_bar_60)
        (objectAtLocation Pan_bar__minus_02_dot_10_bar__plus_00_dot_93_bar__plus_01_dot_05 loc_bar__minus_7_bar_0_bar_0_bar_30)
        (objectAtLocation Window_bar__minus_02_dot_42_bar__plus_01_dot_64_bar__minus_02_dot_45 loc_bar__minus_7_bar__minus_10_bar_3_bar_0)
        (objectAtLocation Egg_bar__minus_01_dot_97_bar__plus_00_dot_74_bar__minus_01_dot_52 loc_bar__minus_4_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Spatula_bar__plus_00_dot_84_bar__plus_00_dot_79_bar__minus_00_dot_63 loc_bar_1_bar__minus_2_bar_1_bar_60)
        (objectAtLocation Potato_bar__plus_00_dot_71_bar__plus_01_dot_19_bar__minus_02_dot_04 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Cup_bar__minus_01_dot_60_bar__plus_00_dot_70_bar__minus_03_dot_61 loc_bar__minus_7_bar__minus_11_bar_2_bar_60)
        (objectAtLocation SaltShaker_bar__plus_00_dot_95_bar__plus_01_dot_46_bar__plus_00_dot_35 loc_bar_1_bar_1_bar_1_bar__minus_30)
        (objectAtLocation PepperShaker_bar__minus_01_dot_54_bar__plus_00_dot_69_bar__minus_03_dot_78 loc_bar__minus_7_bar__minus_11_bar_2_bar_60)
        (objectAtLocation ButterKnife_bar__minus_00_dot_86_bar__plus_00_dot_89_bar__plus_01_dot_19 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation DishSponge_bar__plus_00_dot_80_bar__plus_00_dot_88_bar__minus_00_dot_04 loc_bar_1_bar_0_bar_1_bar_45)
        (objectAtLocation Bread_bar__minus_00_dot_87_bar__plus_00_dot_93_bar__plus_00_dot_98 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation LightSwitch_bar__plus_01_dot_10_bar__plus_01_dot_37_bar__minus_03_dot_74 loc_bar_2_bar__minus_13_bar_1_bar_30)
        (objectAtLocation Lettuce_bar__minus_01_dot_16_bar__plus_00_dot_97_bar__plus_00_dot_99 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation Chair_bar__minus_01_dot_90_bar__minus_00_dot_03_bar__minus_01_dot_87 loc_bar__minus_5_bar__minus_7_bar_3_bar_60)
        (objectAtLocation Tomato_bar__plus_00_dot_67_bar__plus_01_dot_21_bar__minus_01_dot_88 loc_bar__minus_1_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Spoon_bar__minus_01_dot_06_bar__plus_00_dot_89_bar__plus_00_dot_84 loc_bar_0_bar_1_bar_0_bar_60)
        (objectAtLocation Knife_bar__plus_00_dot_57_bar__plus_00_dot_78_bar__minus_00_dot_19 loc_bar__minus_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Mug_bar__plus_00_dot_70_bar__plus_00_dot_94_bar__minus_01_dot_36 loc_bar_0_bar__minus_5_bar_1_bar_45)
        (objectAtLocation Blinds_bar__minus_02_dot_34_bar__plus_02_dot_15_bar__minus_02_dot_44 loc_bar__minus_7_bar__minus_10_bar_3_bar__minus_30)
        (objectAtLocation Bowl_bar__plus_00_dot_86_bar__plus_01_dot_46_bar__minus_00_dot_15 loc_bar_1_bar_0_bar_1_bar__minus_30)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (exists (?o1 - object)
                                (and
                                    (objectType ?o1 SaltShakerType)
                                    (receptacleType ?r SideTableType)
                                    (inReceptacle ?o1 ?r)
                                    (exists (?o2 - object)
                                        (and
                                            (not (= ?o1 ?o2))
                                            (objectType ?o2 SaltShakerType)
                                            (receptacleType ?r SideTableType)
                                            (inReceptacle ?o2 ?r)
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            