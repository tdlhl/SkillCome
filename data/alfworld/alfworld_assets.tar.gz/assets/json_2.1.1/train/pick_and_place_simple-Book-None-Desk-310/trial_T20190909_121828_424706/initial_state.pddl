
(define (problem plan_trial_T20190909_121828_424706)
(:domain alfred)
(:objects
agent1 - agent
SaltShaker - object
        HousePlant - object
        Candle - object
        SprayBottle - object
        Bowl - object
        Window - object
        CD - object
        Egg - object
        Glassbottle - object
        Sink - object
        Pillow - object
        Spoon - object
        SoapBottle - object
        TeddyBear - object
        ButterKnife - object
        Cup - object
        Plate - object
        RemoteControl - object
        Tomato - object
        Statue - object
        HandTowel - object
        Knife - object
        StoveKnob - object
        LightSwitch - object
        Pen - object
        Painting - object
        DishSponge - object
        Vase - object
        Mug - object
        ToiletPaper - object
        Box - object
        Mirror - object
        Ladle - object
        Fork - object
        Blinds - object
        Footstool - object
        KeyChain - object
        Cloth - object
        Laptop - object
        TissueBox - object
        PepperShaker - object
        FloorLamp - object
        WateringCan - object
        Apple - object
        Pan - object
        PaperTowel - object
        PaperTowelRoll - object
        Newspaper - object
        Television - object
        Chair - object
        CellPhone - object
        CreditCard - object
        Lettuce - object
        BasketBall - object
        Potato - object
        Curtains - object
        Boots - object
        Pencil - object
        AlarmClock - object
        ToiletPaperRoll - object
        Spatula - object
        Book - object
        Bread - object
        SoapBar - object
        Watch - object
        DeskLamp - object
        Kettle - object
        Pot - object
        ScrubBrush - object
        WineBottle - object
        ShowerDoor - object
        Bathtub - object
        LaundryHamperLid - object
        ShowerGlass - object
        Poster - object
        TennisRacket - object
        BaseballBat - object
        Towel - object
        Plunger - object
SaltShakerType - otype
        HousePlantType - otype
        CandleType - otype
        SprayBottleType - otype
        BowlType - otype
        WindowType - otype
        CDType - otype
        EggType - otype
        GlassbottleType - otype
        SinkType - otype
        PillowType - otype
        SpoonType - otype
        SoapBottleType - otype
        TeddyBearType - otype
        ButterKnifeType - otype
        CupType - otype
        PlateType - otype
        RemoteControlType - otype
        TomatoType - otype
        StatueType - otype
        HandTowelType - otype
        KnifeType - otype
        StoveKnobType - otype
        LightSwitchType - otype
        PenType - otype
        PaintingType - otype
        DishSpongeType - otype
        VaseType - otype
        MugType - otype
        ToiletPaperType - otype
        BoxType - otype
        MirrorType - otype
        LadleType - otype
        ForkType - otype
        BlindsType - otype
        FootstoolType - otype
        KeyChainType - otype
        ClothType - otype
        LaptopType - otype
        TissueBoxType - otype
        PepperShakerType - otype
        FloorLampType - otype
        WateringCanType - otype
        AppleType - otype
        PanType - otype
        PaperTowelType - otype
        PaperTowelRollType - otype
        NewspaperType - otype
        TelevisionType - otype
        ChairType - otype
        CellPhoneType - otype
        CreditCardType - otype
        LettuceType - otype
        BasketBallType - otype
        PotatoType - otype
        CurtainsType - otype
        BootsType - otype
        PencilType - otype
        AlarmClockType - otype
        ToiletPaperRollType - otype
        SpatulaType - otype
        BookType - otype
        BreadType - otype
        SoapBarType - otype
        WatchType - otype
        DeskLampType - otype
        KettleType - otype
        PotType - otype
        ScrubBrushType - otype
        WineBottleType - otype
        ShowerDoorType - otype
        BathtubType - otype
        LaundryHamperLidType - otype
        ShowerGlassType - otype
        PosterType - otype
        TennisRacketType - otype
        BaseballBatType - otype
        TowelType - otype
        PlungerType - otype
SafeType - rtype
        DrawerType - rtype
        CoffeeMachineType - rtype
        HandTowelHolderType - rtype
        SinkBasinType - rtype
        DresserType - rtype
        LaundryHamperType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CabinetType - rtype
        FridgeType - rtype
        DeskType - rtype
        ToiletType - rtype
        CartType - rtype
        SideTableType - rtype
        SofaType - rtype
        CoffeeTableType - rtype
        DiningTableType - rtype
        CounterTopType - rtype
        GarbageCanType - rtype
        ArmChairType - rtype
        ShelfType - rtype
        MicrowaveType - rtype
        ToasterType - rtype
        BedType - rtype
        PaintingHangerType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype


        AlarmClock_bar__minus_01_dot_63_bar__plus_00_dot_84_bar__minus_01_dot_86 - object
        BaseballBat_bar__minus_01_dot_60_bar__plus_00_dot_02_bar__plus_00_dot_36 - object
        BasketBall_bar__minus_00_dot_34_bar__plus_00_dot_12_bar__plus_01_dot_03 - object
        Blinds_bar__minus_01_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_25 - object
        Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__plus_00_dot_78 - object
        Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__minus_00_dot_12 - object
        Book_bar__plus_00_dot_58_bar__plus_00_dot_65_bar__plus_00_dot_78 - object
        Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03 - object
        CD_bar__plus_00_dot_15_bar__plus_00_dot_15_bar__minus_02_dot_20 - object
        CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_00_dot_99 - object
        CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_01_dot_14 - object
        CellPhone_bar__plus_01_dot_15_bar__plus_00_dot_65_bar__plus_00_dot_24 - object
        Chair_bar__minus_01_dot_09_bar__plus_00_dot_02_bar__minus_01_dot_57 - object
        CreditCard_bar__minus_00_dot_71_bar__plus_00_dot_84_bar__minus_01_dot_86 - object
        CreditCard_bar__minus_00_dot_90_bar__plus_01_dot_35_bar__minus_02_dot_12 - object
        KeyChain_bar__plus_01_dot_62_bar__plus_00_dot_37_bar__minus_00_dot_93 - object
        KeyChain_bar__plus_01_dot_64_bar__plus_00_dot_08_bar__minus_00_dot_93 - object
        KeyChain_bar__plus_01_dot_72_bar__plus_00_dot_68_bar__minus_00_dot_91 - object
        Lamp_bar__minus_01_dot_67_bar__plus_01_dot_77_bar__minus_02_dot_19 - object
        Laptop_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_00_dot_24 - object
        Laptop_bar__minus_00_dot_94_bar__plus_01_dot_78_bar__minus_02_dot_16 - object
        LightSwitch_bar__plus_01_dot_90_bar__plus_01_dot_30_bar__minus_01_dot_30 - object
        Mirror_bar__plus_00_dot_88_bar__plus_01_dot_58_bar__minus_02_dot_40 - object
        Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_00_dot_76 - object
        Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_01_dot_07 - object
        Pencil_bar__minus_01_dot_17_bar__plus_00_dot_84_bar__minus_01_dot_75 - object
        Pen_bar__minus_00_dot_24_bar__plus_00_dot_84_bar__minus_02_dot_08 - object
        Pen_bar__minus_00_dot_24_bar__plus_01_dot_78_bar__minus_02_dot_28 - object
        Pen_bar__minus_00_dot_94_bar__plus_00_dot_84_bar__minus_02_dot_29 - object
        Pillow_bar__plus_01_dot_15_bar__plus_00_dot_74_bar__plus_00_dot_78 - object
        Poster_bar__minus_01_dot_93_bar__plus_01_dot_41_bar__minus_01_dot_46 - object
        TennisRacket_bar__minus_01_dot_67_bar__plus_00_dot_00_bar__plus_00_dot_82 - object
        Window_bar__minus_02_dot_03_bar__plus_01_dot_39_bar__minus_00_dot_27 - object
        Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24 - receptacle
        Cabinet_bar__minus_00_dot_03_bar__plus_01_dot_53_bar__minus_01_dot_92 - receptacle
        Cabinet_bar__minus_00_dot_79_bar__plus_01_dot_53_bar__minus_01_dot_92 - receptacle
        Cabinet_bar__minus_01_dot_08_bar__plus_01_dot_53_bar__minus_01_dot_92 - receptacle
        Cabinet_bar__minus_01_dot_84_bar__plus_01_dot_53_bar__minus_01_dot_92 - receptacle
        Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06 - receptacle
        Drawer_bar__plus_01_dot_60_bar__plus_00_dot_17_bar__minus_00_dot_99 - receptacle
        Drawer_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 - receptacle
        GarbageCan_bar__plus_00_dot_13_bar__plus_00_dot_00_bar__minus_02_dot_15 - receptacle
        Shelf_bar__minus_00_dot_94_bar__plus_01_dot_34_bar__minus_02_dot_12 - receptacle
        SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 - receptacle
        loc_bar__minus_2_bar__minus_5_bar_2_bar_60 - location
        loc_bar_3_bar__minus_5_bar_1_bar_60 - location
        loc_bar_0_bar__minus_5_bar_2_bar_60 - location
        loc_bar__minus_2_bar_3_bar_0_bar_60 - location
        loc_bar__minus_5_bar_1_bar_3_bar_60 - location
        loc_bar__minus_6_bar__minus_4_bar_2_bar_30 - location
        loc_bar__minus_6_bar__minus_1_bar_3_bar_30 - location
        loc_bar_4_bar__minus_3_bar_1_bar_60 - location
        loc_bar__minus_6_bar__minus_1_bar_3_bar__minus_30 - location
        loc_bar__minus_2_bar__minus_5_bar_2_bar_15 - location
        loc_bar__minus_6_bar__minus_4_bar_2_bar_15 - location
        loc_bar__minus_1_bar__minus_5_bar_2_bar_15 - location
        loc_bar_5_bar__minus_5_bar_1_bar_30 - location
        loc_bar_4_bar__minus_7_bar_2_bar_0 - location
        loc_bar__minus_4_bar__minus_4_bar_2_bar_60 - location
        loc_bar_2_bar__minus_6_bar_1_bar_60 - location
        loc_bar__minus_5_bar_3_bar_3_bar_60 - location
        loc_bar__minus_2_bar_1_bar_1_bar_45 - location
        loc_bar__minus_6_bar__minus_5_bar_0_bar_30 - location
        )
    

(:init


        (receptacleType Cabinet_bar__minus_00_dot_03_bar__plus_01_dot_53_bar__minus_01_dot_92 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 DrawerType)
        (receptacleType Cabinet_bar__minus_01_dot_08_bar__plus_01_dot_53_bar__minus_01_dot_92 CabinetType)
        (receptacleType Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06 DeskType)
        (receptacleType Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24 BedType)
        (receptacleType Shelf_bar__minus_00_dot_94_bar__plus_01_dot_34_bar__minus_02_dot_12 ShelfType)
        (receptacleType SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 SideTableType)
        (receptacleType GarbageCan_bar__plus_00_dot_13_bar__plus_00_dot_00_bar__minus_02_dot_15 GarbageCanType)
        (receptacleType Cabinet_bar__minus_01_dot_84_bar__plus_01_dot_53_bar__minus_01_dot_92 CabinetType)
        (receptacleType Cabinet_bar__minus_00_dot_79_bar__plus_01_dot_53_bar__minus_01_dot_92 CabinetType)
        (receptacleType Drawer_bar__plus_01_dot_60_bar__plus_00_dot_17_bar__minus_00_dot_99 DrawerType)
        (objectType Laptop_bar__minus_00_dot_94_bar__plus_01_dot_78_bar__minus_02_dot_16 LaptopType)
        (objectType Mirror_bar__plus_00_dot_88_bar__plus_01_dot_58_bar__minus_02_dot_40 MirrorType)
        (objectType CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_00_dot_99 CDType)
        (objectType KeyChain_bar__plus_01_dot_64_bar__plus_00_dot_08_bar__minus_00_dot_93 KeyChainType)
        (objectType Laptop_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_00_dot_24 LaptopType)
        (objectType CellPhone_bar__plus_01_dot_15_bar__plus_00_dot_65_bar__plus_00_dot_24 CellPhoneType)
        (objectType CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_01_dot_14 CDType)
        (objectType Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__plus_00_dot_78 BookType)
        (objectType BaseballBat_bar__minus_01_dot_60_bar__plus_00_dot_02_bar__plus_00_dot_36 BaseballBatType)
        (objectType Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_01_dot_07 PencilType)
        (objectType Window_bar__minus_02_dot_03_bar__plus_01_dot_39_bar__minus_00_dot_27 WindowType)
        (objectType Pen_bar__minus_00_dot_24_bar__plus_00_dot_84_bar__minus_02_dot_08 PenType)
        (objectType Blinds_bar__minus_01_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_25 BlindsType)
        (objectType CD_bar__plus_00_dot_15_bar__plus_00_dot_15_bar__minus_02_dot_20 CDType)
        (objectType TennisRacket_bar__minus_01_dot_67_bar__plus_00_dot_00_bar__plus_00_dot_82 TennisRacketType)
        (objectType KeyChain_bar__plus_01_dot_62_bar__plus_00_dot_37_bar__minus_00_dot_93 KeyChainType)
        (objectType BasketBall_bar__minus_00_dot_34_bar__plus_00_dot_12_bar__plus_01_dot_03 BasketBallType)
        (objectType AlarmClock_bar__minus_01_dot_63_bar__plus_00_dot_84_bar__minus_01_dot_86 AlarmClockType)
        (objectType Pillow_bar__plus_01_dot_15_bar__plus_00_dot_74_bar__plus_00_dot_78 PillowType)
        (objectType Pencil_bar__minus_01_dot_17_bar__plus_00_dot_84_bar__minus_01_dot_75 PencilType)
        (objectType Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03 BoxType)
        (objectType Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_00_dot_76 PencilType)
        (objectType CreditCard_bar__minus_00_dot_71_bar__plus_00_dot_84_bar__minus_01_dot_86 CreditCardType)
        (objectType Chair_bar__minus_01_dot_09_bar__plus_00_dot_02_bar__minus_01_dot_57 ChairType)
        (objectType KeyChain_bar__plus_01_dot_72_bar__plus_00_dot_68_bar__minus_00_dot_91 KeyChainType)
        (objectType Poster_bar__minus_01_dot_93_bar__plus_01_dot_41_bar__minus_01_dot_46 PosterType)
        (objectType Pen_bar__minus_00_dot_24_bar__plus_01_dot_78_bar__minus_02_dot_28 PenType)
        (objectType Book_bar__plus_00_dot_58_bar__plus_00_dot_65_bar__plus_00_dot_78 BookType)
        (objectType LightSwitch_bar__plus_01_dot_90_bar__plus_01_dot_30_bar__minus_01_dot_30 LightSwitchType)
        (objectType Pen_bar__minus_00_dot_94_bar__plus_00_dot_84_bar__minus_02_dot_29 PenType)
        (objectType CreditCard_bar__minus_00_dot_90_bar__plus_01_dot_35_bar__minus_02_dot_12 CreditCardType)
        (objectType Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__minus_00_dot_12 BookType)
        (canContain CabinetType BookType)
        (canContain CabinetType CDType)
        (canContain CabinetType BoxType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (canContain CabinetType BookType)
        (canContain CabinetType CDType)
        (canContain CabinetType BoxType)
        (canContain DeskType PenType)
        (canContain DeskType BookType)
        (canContain DeskType CDType)
        (canContain DeskType BoxType)
        (canContain DeskType CellPhoneType)
        (canContain DeskType KeyChainType)
        (canContain DeskType CreditCardType)
        (canContain DeskType BasketBallType)
        (canContain DeskType TennisRacketType)
        (canContain DeskType LaptopType)
        (canContain DeskType PencilType)
        (canContain DeskType AlarmClockType)
        (canContain BedType BasketBallType)
        (canContain BedType BaseballBatType)
        (canContain BedType TennisRacketType)
        (canContain BedType LaptopType)
        (canContain BedType BookType)
        (canContain BedType CellPhoneType)
        (canContain BedType PillowType)
        (canContain ShelfType PenType)
        (canContain ShelfType BookType)
        (canContain ShelfType CDType)
        (canContain ShelfType BoxType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType PencilType)
        (canContain ShelfType AlarmClockType)
        (canContain SideTableType PenType)
        (canContain SideTableType BookType)
        (canContain SideTableType CDType)
        (canContain SideTableType BoxType)
        (canContain SideTableType CellPhoneType)
        (canContain SideTableType KeyChainType)
        (canContain SideTableType CreditCardType)
        (canContain SideTableType BasketBallType)
        (canContain SideTableType BaseballBatType)
        (canContain SideTableType TennisRacketType)
        (canContain SideTableType LaptopType)
        (canContain SideTableType PencilType)
        (canContain SideTableType AlarmClockType)
        (canContain GarbageCanType PenType)
        (canContain GarbageCanType CDType)
        (canContain GarbageCanType PencilType)
        (canContain CabinetType BookType)
        (canContain CabinetType CDType)
        (canContain CabinetType BoxType)
        (canContain CabinetType BookType)
        (canContain CabinetType CDType)
        (canContain CabinetType BoxType)
        (canContain DrawerType PenType)
        (canContain DrawerType BookType)
        (canContain DrawerType CDType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType PencilType)
        (pickupable Laptop_bar__minus_00_dot_94_bar__plus_01_dot_78_bar__minus_02_dot_16)
        (pickupable CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_00_dot_99)
        (pickupable KeyChain_bar__plus_01_dot_64_bar__plus_00_dot_08_bar__minus_00_dot_93)
        (pickupable Laptop_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_00_dot_24)
        (pickupable CellPhone_bar__plus_01_dot_15_bar__plus_00_dot_65_bar__plus_00_dot_24)
        (pickupable CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_01_dot_14)
        (pickupable Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__plus_00_dot_78)
        (pickupable BaseballBat_bar__minus_01_dot_60_bar__plus_00_dot_02_bar__plus_00_dot_36)
        (pickupable Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_01_dot_07)
        (pickupable Pen_bar__minus_00_dot_24_bar__plus_00_dot_84_bar__minus_02_dot_08)
        (pickupable CD_bar__plus_00_dot_15_bar__plus_00_dot_15_bar__minus_02_dot_20)
        (pickupable TennisRacket_bar__minus_01_dot_67_bar__plus_00_dot_00_bar__plus_00_dot_82)
        (pickupable KeyChain_bar__plus_01_dot_62_bar__plus_00_dot_37_bar__minus_00_dot_93)
        (pickupable BasketBall_bar__minus_00_dot_34_bar__plus_00_dot_12_bar__plus_01_dot_03)
        (pickupable AlarmClock_bar__minus_01_dot_63_bar__plus_00_dot_84_bar__minus_01_dot_86)
        (pickupable Pillow_bar__plus_01_dot_15_bar__plus_00_dot_74_bar__plus_00_dot_78)
        (pickupable Pencil_bar__minus_01_dot_17_bar__plus_00_dot_84_bar__minus_01_dot_75)
        (pickupable Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03)
        (pickupable Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_00_dot_76)
        (pickupable CreditCard_bar__minus_00_dot_71_bar__plus_00_dot_84_bar__minus_01_dot_86)
        (pickupable KeyChain_bar__plus_01_dot_72_bar__plus_00_dot_68_bar__minus_00_dot_91)
        (pickupable Pen_bar__minus_00_dot_24_bar__plus_01_dot_78_bar__minus_02_dot_28)
        (pickupable Book_bar__plus_00_dot_58_bar__plus_00_dot_65_bar__plus_00_dot_78)
        (pickupable Pen_bar__minus_00_dot_94_bar__plus_00_dot_84_bar__minus_02_dot_29)
        (pickupable CreditCard_bar__minus_00_dot_90_bar__plus_01_dot_35_bar__minus_02_dot_12)
        (pickupable Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__minus_00_dot_12)
        (isReceptacleObject Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03)
        (openable Cabinet_bar__minus_00_dot_03_bar__plus_01_dot_53_bar__minus_01_dot_92)
        (openable Drawer_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (openable Cabinet_bar__minus_01_dot_08_bar__plus_01_dot_53_bar__minus_01_dot_92)
        (openable Cabinet_bar__minus_01_dot_84_bar__plus_01_dot_53_bar__minus_01_dot_92)
        (openable Cabinet_bar__minus_00_dot_79_bar__plus_01_dot_53_bar__minus_01_dot_92)
        (openable Drawer_bar__plus_01_dot_60_bar__plus_00_dot_17_bar__minus_00_dot_99)
        
        (atLocation agent1 loc_bar__minus_6_bar__minus_5_bar_0_bar_30)
        
        
        
        
        
        
        
        
        
        
        
        
        (inReceptacle CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_00_dot_99 SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle KeyChain_bar__plus_01_dot_72_bar__plus_00_dot_68_bar__minus_00_dot_91 SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_00_dot_76 SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_01_dot_14 SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_01_dot_07 SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle KeyChain_bar__plus_01_dot_64_bar__plus_00_dot_08_bar__minus_00_dot_93 Drawer_bar__plus_01_dot_60_bar__plus_00_dot_17_bar__minus_00_dot_99)
        (inReceptacle Laptop_bar__minus_00_dot_94_bar__plus_01_dot_78_bar__minus_02_dot_16 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle AlarmClock_bar__minus_01_dot_63_bar__plus_00_dot_84_bar__minus_01_dot_86 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle Pen_bar__minus_00_dot_24_bar__plus_00_dot_84_bar__minus_02_dot_08 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle Pencil_bar__minus_01_dot_17_bar__plus_00_dot_84_bar__minus_01_dot_75 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle Pen_bar__minus_00_dot_24_bar__plus_01_dot_78_bar__minus_02_dot_28 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle CreditCard_bar__minus_00_dot_71_bar__plus_00_dot_84_bar__minus_01_dot_86 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle Pen_bar__minus_00_dot_94_bar__plus_00_dot_84_bar__minus_02_dot_29 Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06)
        (inReceptacle KeyChain_bar__plus_01_dot_62_bar__plus_00_dot_37_bar__minus_00_dot_93 Drawer_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99)
        (inReceptacle Pillow_bar__plus_01_dot_15_bar__plus_00_dot_74_bar__plus_00_dot_78 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle Laptop_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_00_dot_24 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle CellPhone_bar__plus_01_dot_15_bar__plus_00_dot_65_bar__plus_00_dot_24 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle Book_bar__plus_00_dot_58_bar__plus_00_dot_65_bar__plus_00_dot_78 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__plus_00_dot_78 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__minus_00_dot_12 Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24)
        (inReceptacle CreditCard_bar__minus_00_dot_90_bar__plus_01_dot_35_bar__minus_02_dot_12 Shelf_bar__minus_00_dot_94_bar__plus_01_dot_34_bar__minus_02_dot_12)
        (inReceptacle CD_bar__plus_00_dot_15_bar__plus_00_dot_15_bar__minus_02_dot_20 GarbageCan_bar__plus_00_dot_13_bar__plus_00_dot_00_bar__minus_02_dot_15)
        
        
        (receptacleAtLocation Bed_bar__plus_01_dot_18_bar__plus_00_dot_00_bar__plus_00_dot_24 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_03_bar__plus_01_dot_53_bar__minus_01_dot_92 loc_bar__minus_1_bar__minus_5_bar_2_bar_15)
        (receptacleAtLocation Cabinet_bar__minus_00_dot_79_bar__plus_01_dot_53_bar__minus_01_dot_92 loc_bar__minus_2_bar__minus_5_bar_2_bar_15)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_08_bar__plus_01_dot_53_bar__minus_01_dot_92 loc_bar__minus_6_bar__minus_4_bar_2_bar_15)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_84_bar__plus_01_dot_53_bar__minus_01_dot_92 loc_bar__minus_6_bar__minus_4_bar_2_bar_15)
        (receptacleAtLocation Desk_bar__minus_00_dot_96_bar_00_dot_00_bar__minus_02_dot_06 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_60_bar__plus_00_dot_17_bar__minus_00_dot_99 loc_bar_2_bar__minus_6_bar_1_bar_60)
        (receptacleAtLocation Drawer_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 loc_bar_3_bar__minus_5_bar_1_bar_60)
        (receptacleAtLocation GarbageCan_bar__plus_00_dot_13_bar__plus_00_dot_00_bar__minus_02_dot_15 loc_bar_0_bar__minus_5_bar_2_bar_60)
        (receptacleAtLocation Shelf_bar__minus_00_dot_94_bar__plus_01_dot_34_bar__minus_02_dot_12 loc_bar__minus_2_bar__minus_5_bar_2_bar_15)
        (receptacleAtLocation SideTable_bar__plus_01_dot_60_bar__plus_00_dot_46_bar__minus_00_dot_99 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation CD_bar__plus_00_dot_15_bar__plus_00_dot_15_bar__minus_02_dot_20 loc_bar_0_bar__minus_5_bar_2_bar_60)
        (objectAtLocation CreditCard_bar__minus_00_dot_71_bar__plus_00_dot_84_bar__minus_01_dot_86 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation KeyChain_bar__plus_01_dot_62_bar__plus_00_dot_37_bar__minus_00_dot_93 loc_bar_3_bar__minus_5_bar_1_bar_60)
        (objectAtLocation Pencil_bar__minus_01_dot_17_bar__plus_00_dot_84_bar__minus_01_dot_75 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation Laptop_bar__plus_01_dot_44_bar__plus_00_dot_64_bar__plus_00_dot_24 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation Pen_bar__minus_00_dot_94_bar__plus_00_dot_84_bar__minus_02_dot_29 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__plus_00_dot_78 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation Book_bar__plus_00_dot_58_bar__plus_00_dot_65_bar__plus_00_dot_78 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation KeyChain_bar__plus_01_dot_64_bar__plus_00_dot_08_bar__minus_00_dot_93 loc_bar_2_bar__minus_6_bar_1_bar_60)
        (objectAtLocation Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_01_dot_07 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Pen_bar__minus_00_dot_24_bar__plus_00_dot_84_bar__minus_02_dot_08 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_00_dot_99 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Book_bar__plus_00_dot_30_bar__plus_00_dot_65_bar__minus_00_dot_12 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation Chair_bar__minus_01_dot_09_bar__plus_00_dot_02_bar__minus_01_dot_57 loc_bar__minus_4_bar__minus_4_bar_2_bar_60)
        (objectAtLocation Mirror_bar__plus_00_dot_88_bar__plus_01_dot_58_bar__minus_02_dot_40 loc_bar_4_bar__minus_7_bar_2_bar_0)
        (objectAtLocation Box_bar__minus_00_dot_42_bar__plus_02_dot_07_bar__minus_02_dot_03 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation LightSwitch_bar__plus_01_dot_90_bar__plus_01_dot_30_bar__minus_01_dot_30 loc_bar_5_bar__minus_5_bar_1_bar_30)
        (objectAtLocation Pillow_bar__plus_01_dot_15_bar__plus_00_dot_74_bar__plus_00_dot_78 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation AlarmClock_bar__minus_01_dot_63_bar__plus_00_dot_84_bar__minus_01_dot_86 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation BasketBall_bar__minus_00_dot_34_bar__plus_00_dot_12_bar__plus_01_dot_03 loc_bar__minus_2_bar_3_bar_0_bar_60)
        (objectAtLocation BaseballBat_bar__minus_01_dot_60_bar__plus_00_dot_02_bar__plus_00_dot_36 loc_bar__minus_5_bar_1_bar_3_bar_60)
        (objectAtLocation Pen_bar__minus_00_dot_24_bar__plus_01_dot_78_bar__minus_02_dot_28 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation CellPhone_bar__plus_01_dot_15_bar__plus_00_dot_65_bar__plus_00_dot_24 loc_bar__minus_2_bar_1_bar_1_bar_45)
        (objectAtLocation TennisRacket_bar__minus_01_dot_67_bar__plus_00_dot_00_bar__plus_00_dot_82 loc_bar__minus_5_bar_3_bar_3_bar_60)
        (objectAtLocation Poster_bar__minus_01_dot_93_bar__plus_01_dot_41_bar__minus_01_dot_46 loc_bar__minus_6_bar__minus_4_bar_2_bar_30)
        (objectAtLocation Laptop_bar__minus_00_dot_94_bar__plus_01_dot_78_bar__minus_02_dot_16 loc_bar__minus_2_bar__minus_5_bar_2_bar_60)
        (objectAtLocation Pencil_bar__plus_01_dot_76_bar__plus_00_dot_68_bar__minus_00_dot_76 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation KeyChain_bar__plus_01_dot_72_bar__plus_00_dot_68_bar__minus_00_dot_91 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation CreditCard_bar__minus_00_dot_90_bar__plus_01_dot_35_bar__minus_02_dot_12 loc_bar__minus_2_bar__minus_5_bar_2_bar_15)
        (objectAtLocation CD_bar__plus_01_dot_63_bar__plus_00_dot_68_bar__minus_01_dot_14 loc_bar_4_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Window_bar__minus_02_dot_03_bar__plus_01_dot_39_bar__minus_00_dot_27 loc_bar__minus_6_bar__minus_1_bar_3_bar_30)
        (objectAtLocation Blinds_bar__minus_01_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_25 loc_bar__minus_6_bar__minus_1_bar_3_bar__minus_30)
        )
    

        (:goal
            (and
                (exists (?r - receptacle)
                    (exists (?o - object)
                        (and
                            (inReceptacle ?o ?r)
                            (objectType ?o BookType)
                            (receptacleType ?r DeskType)
                        )
                    )
                )
            )
        )
    )
    