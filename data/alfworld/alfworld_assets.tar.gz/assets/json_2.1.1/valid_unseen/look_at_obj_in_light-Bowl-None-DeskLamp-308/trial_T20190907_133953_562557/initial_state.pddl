
(define (problem plan_trial_T20190907_133953_562557)
(:domain alfred)
(:objects
agent1 - agent
RemoteControl - object
        Laptop - object
        Kettle - object
        Pen - object
        Fork - object
        Cloth - object
        HousePlant - object
        Plunger - object
        SoapBottle - object
        Cup - object
        Candle - object
        Tomato - object
        Television - object
        TennisRacket - object
        Towel - object
        SaltShaker - object
        Spoon - object
        Apple - object
        Poster - object
        Curtains - object
        Footstool - object
        AlarmClock - object
        Ladle - object
        PaperTowelRoll - object
        BaseballBat - object
        Knife - object
        Spatula - object
        SoapBar - object
        CreditCard - object
        Sink - object
        Newspaper - object
        LaundryHamperLid - object
        KeyChain - object
        Glassbottle - object
        ButterKnife - object
        Chair - object
        HandTowel - object
        ToiletPaperRoll - object
        Plate - object
        Pot - object
        WineBottle - object
        Boots - object
        PepperShaker - object
        PaperTowel - object
        Bowl - object
        SprayBottle - object
        ScrubBrush - object
        Box - object
        CD - object
        Pan - object
        Statue - object
        Vase - object
        ShowerGlass - object
        DishSponge - object
        Egg - object
        Lettuce - object
        Book - object
        TeddyBear - object
        ToiletPaper - object
        ShowerDoor - object
        Window - object
        Blinds - object
        CellPhone - object
        FloorLamp - object
        Pillow - object
        Mirror - object
        Painting - object
        TissueBox - object
        Pencil - object
        Potato - object
        LightSwitch - object
        StoveKnob - object
        Mug - object
        Bathtub - object
        DeskLamp - object
        Watch - object
        WateringCan - object
        BasketBall - object
        Bread - object
RemoteControlType - otype
        LaptopType - otype
        KettleType - otype
        PenType - otype
        ForkType - otype
        ClothType - otype
        HousePlantType - otype
        PlungerType - otype
        SoapBottleType - otype
        CupType - otype
        CandleType - otype
        TomatoType - otype
        TelevisionType - otype
        TennisRacketType - otype
        TowelType - otype
        SaltShakerType - otype
        SpoonType - otype
        AppleType - otype
        PosterType - otype
        CurtainsType - otype
        FootstoolType - otype
        AlarmClockType - otype
        LadleType - otype
        PaperTowelRollType - otype
        BaseballBatType - otype
        KnifeType - otype
        SpatulaType - otype
        SoapBarType - otype
        CreditCardType - otype
        SinkType - otype
        NewspaperType - otype
        LaundryHamperLidType - otype
        KeyChainType - otype
        GlassbottleType - otype
        ButterKnifeType - otype
        ChairType - otype
        HandTowelType - otype
        ToiletPaperRollType - otype
        PlateType - otype
        PotType - otype
        WineBottleType - otype
        BootsType - otype
        PepperShakerType - otype
        PaperTowelType - otype
        BowlType - otype
        SprayBottleType - otype
        ScrubBrushType - otype
        BoxType - otype
        CDType - otype
        PanType - otype
        StatueType - otype
        VaseType - otype
        ShowerGlassType - otype
        DishSpongeType - otype
        EggType - otype
        LettuceType - otype
        BookType - otype
        TeddyBearType - otype
        ToiletPaperType - otype
        ShowerDoorType - otype
        WindowType - otype
        BlindsType - otype
        CellPhoneType - otype
        FloorLampType - otype
        PillowType - otype
        MirrorType - otype
        PaintingType - otype
        TissueBoxType - otype
        PencilType - otype
        PotatoType - otype
        LightSwitchType - otype
        StoveKnobType - otype
        MugType - otype
        BathtubType - otype
        DeskLampType - otype
        WatchType - otype
        WateringCanType - otype
        BasketBallType - otype
        BreadType - otype
SinkBasinType - rtype
        GarbageCanType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype
        CabinetType - rtype
        SideTableType - rtype
        DiningTableType - rtype
        CoffeeTableType - rtype
        SafeType - rtype
        DresserType - rtype
        DeskType - rtype
        BedType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        MicrowaveType - rtype
        SofaType - rtype
        CartType - rtype
        ArmChairType - rtype
        HandTowelHolderType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CoffeeMachineType - rtype
        ToasterType - rtype
        LaundryHamperType - rtype
        DrawerType - rtype
        FridgeType - rtype
        ToiletType - rtype
        ShelfType - rtype
        PaintingHangerType - rtype
        CounterTopType - rtype


        AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58 - object
        AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58 - object
        BaseballBat_bar__plus_01_dot_95_bar__plus_00_dot_66_bar__minus_01_dot_81 - object
        BasketBall_bar__plus_01_dot_98_bar__plus_00_dot_12_bar__plus_00_dot_21 - object
        Blinds_bar__plus_00_dot_60_bar__plus_02_dot_16_bar__minus_01_dot_92 - object
        Blinds_bar__minus_00_dot_40_bar__plus_02_dot_16_bar__minus_01_dot_92 - object
        Book_bar__plus_00_dot_60_bar__plus_00_dot_78_bar__plus_01_dot_66 - object
        Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66 - object
        Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66 - object
        Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37 - object
        CD_bar__minus_00_dot_47_bar__plus_00_dot_08_bar__minus_01_dot_09 - object
        CD_bar__minus_00_dot_79_bar__plus_00_dot_20_bar__minus_00_dot_31 - object
        CD_bar__minus_01_dot_34_bar__plus_01_dot_35_bar__plus_00_dot_41 - object
        CellPhone_bar__minus_02_dot_03_bar__plus_00_dot_04_bar__plus_02_dot_63 - object
        Chair_bar__minus_00_dot_13_bar__plus_00_dot_53_bar__minus_01_dot_58 - object
        Chair_bar__minus_01_dot_42_bar__plus_00_dot_53_bar__plus_00_dot_80 - object
        CreditCard_bar__minus_00_dot_51_bar__plus_00_dot_36_bar__minus_01_dot_01 - object
        DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75 - object
        KeyChain_bar__minus_02_dot_07_bar__plus_00_dot_39_bar__plus_00_dot_68 - object
        KeyChain_bar__minus_02_dot_34_bar__plus_00_dot_04_bar__plus_02_dot_63 - object
        Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_00_dot_79 - object
        Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_01_dot_95 - object
        LaundryHamperLid_bar__plus_00_dot_16_bar__plus_00_dot_48_bar__plus_02_dot_64 - object
        LightSwitch_bar__plus_02_dot_15_bar__plus_01_dot_23_bar__minus_00_dot_52 - object
        Mirror_bar__minus_01_dot_36_bar__plus_01_dot_43_bar__plus_02_dot_86 - object
        Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01 - object
        Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83 - object
        Pencil_bar__minus_01_dot_39_bar__plus_01_dot_73_bar__plus_00_dot_45 - object
        Pencil_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_67 - object
        Pen_bar__minus_01_dot_73_bar__plus_01_dot_73_bar__plus_00_dot_37 - object
        Pillow_bar__plus_01_dot_12_bar__plus_00_dot_87_bar__plus_02_dot_46 - object
        Pillow_bar__plus_01_dot_21_bar__plus_00_dot_92_bar__plus_01_dot_37 - object
        Pillow_bar__plus_01_dot_41_bar__plus_00_dot_92_bar__plus_01_dot_95 - object
        Window_bar__plus_00_dot_58_bar__plus_01_dot_53_bar__minus_01_dot_95 - object
        Window_bar__minus_00_dot_42_bar__plus_01_dot_53_bar__minus_01_dot_95 - object
        Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67 - receptacle
        Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35 - receptacle
        Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67 - receptacle
        Drawer_bar__minus_00_dot_51_bar__plus_00_dot_19_bar__minus_00_dot_85 - receptacle
        Drawer_bar__minus_00_dot_51_bar__plus_00_dot_47_bar__minus_00_dot_85 - receptacle
        Drawer_bar__minus_00_dot_51_bar__plus_00_dot_72_bar__minus_00_dot_85 - receptacle
        Drawer_bar__minus_02_dot_07_bar__plus_00_dot_21_bar__plus_00_dot_73 - receptacle
        Drawer_bar__minus_02_dot_07_bar__plus_00_dot_49_bar__plus_00_dot_73 - receptacle
        Drawer_bar__minus_02_dot_07_bar__plus_00_dot_74_bar__plus_00_dot_73 - receptacle
        GarbageCan_bar__minus_00_dot_75_bar__plus_00_dot_00_bar__minus_00_dot_34 - receptacle
        LaundryHamper_bar__plus_00_dot_16_bar__plus_00_dot_01_bar__plus_02_dot_64 - receptacle
        Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58 - receptacle
        Shelf_bar__minus_01_dot_29_bar__plus_00_dot_87_bar__plus_00_dot_41 - receptacle
        Shelf_bar__minus_01_dot_29_bar__plus_01_dot_34_bar__plus_00_dot_41 - receptacle
        Shelf_bar__minus_01_dot_29_bar__plus_01_dot_72_bar__plus_00_dot_41 - receptacle
        Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41 - receptacle
        Shelf_bar__minus_01_dot_96_bar__plus_01_dot_34_bar__plus_00_dot_41 - receptacle
        Shelf_bar__minus_01_dot_96_bar__plus_01_dot_72_bar__plus_00_dot_41 - receptacle
        loc_bar__minus_5_bar_6_bar_3_bar_45 - location
        loc_bar_1_bar_0_bar_3_bar_60 - location
        loc_bar_1_bar__minus_5_bar_3_bar_60 - location
        loc_bar_2_bar__minus_6_bar_3_bar_0 - location
        loc_bar_2_bar__minus_5_bar_2_bar_15 - location
        loc_bar__minus_4_bar_8_bar_3_bar_60 - location
        loc_bar_6_bar_0_bar_1_bar_60 - location
        loc_bar_0_bar_9_bar_0_bar_60 - location
        loc_bar_6_bar__minus_5_bar_2_bar_60 - location
        loc_bar__minus_1_bar_3_bar_3_bar_45 - location
        loc_bar__minus_4_bar_5_bar_2_bar_0 - location
        loc_bar__minus_8_bar_5_bar_2_bar_60 - location
        loc_bar__minus_1_bar_6_bar_1_bar_45 - location
        loc_bar_6_bar__minus_2_bar_1_bar_30 - location
        loc_bar_2_bar__minus_6_bar_3_bar__minus_30 - location
        loc_bar_2_bar__minus_6_bar_2_bar__minus_30 - location
        loc_bar_1_bar__minus_5_bar_3_bar_45 - location
        loc_bar_0_bar__minus_3_bar_3_bar_60 - location
        loc_bar__minus_5_bar_9_bar_0_bar_15 - location
        loc_bar__minus_4_bar_6_bar_2_bar_30 - location
        loc_bar_2_bar__minus_6_bar_3_bar_60 - location
        loc_bar__minus_3_bar_4_bar_3_bar_15 - location
        loc_bar__minus_7_bar_6_bar_2_bar_30 - location
        loc_bar__minus_7_bar_5_bar_2_bar_0 - location
        loc_bar__minus_2_bar_2_bar_3_bar_15 - location
        loc_bar__minus_7_bar_5_bar_2_bar_60 - location
        loc_bar__minus_1_bar_4_bar_2_bar_30 - location
        )
    

(:init


        (receptacleType Drawer_bar__minus_00_dot_51_bar__plus_00_dot_47_bar__minus_00_dot_85 DrawerType)
        (receptacleType LaundryHamper_bar__plus_00_dot_16_bar__plus_00_dot_01_bar__plus_02_dot_64 LaundryHamperType)
        (receptacleType Drawer_bar__minus_00_dot_51_bar__plus_00_dot_19_bar__minus_00_dot_85 DrawerType)
        (receptacleType Drawer_bar__minus_02_dot_07_bar__plus_00_dot_21_bar__plus_00_dot_73 DrawerType)
        (receptacleType Drawer_bar__minus_02_dot_07_bar__plus_00_dot_49_bar__plus_00_dot_73 DrawerType)
        (receptacleType Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67 DeskType)
        (receptacleType Shelf_bar__minus_01_dot_29_bar__plus_01_dot_72_bar__plus_00_dot_41 ShelfType)
        (receptacleType Drawer_bar__minus_02_dot_07_bar__plus_00_dot_74_bar__plus_00_dot_73 DrawerType)
        (receptacleType Shelf_bar__minus_01_dot_96_bar__plus_01_dot_72_bar__plus_00_dot_41 ShelfType)
        (receptacleType Shelf_bar__minus_01_dot_96_bar__plus_01_dot_34_bar__plus_00_dot_41 ShelfType)
        (receptacleType Drawer_bar__minus_00_dot_51_bar__plus_00_dot_72_bar__minus_00_dot_85 DrawerType)
        (receptacleType Shelf_bar__minus_01_dot_29_bar__plus_00_dot_87_bar__plus_00_dot_41 ShelfType)
        (receptacleType Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58 SafeType)
        (receptacleType Shelf_bar__minus_01_dot_29_bar__plus_01_dot_34_bar__plus_00_dot_41 ShelfType)
        (receptacleType GarbageCan_bar__minus_00_dot_75_bar__plus_00_dot_00_bar__minus_00_dot_34 GarbageCanType)
        (receptacleType Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67 BedType)
        (receptacleType Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41 ShelfType)
        (receptacleType Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35 DeskType)
        (objectType Pillow_bar__plus_01_dot_21_bar__plus_00_dot_92_bar__plus_01_dot_37 PillowType)
        (objectType LightSwitch_bar__plus_02_dot_15_bar__plus_01_dot_23_bar__minus_00_dot_52 LightSwitchType)
        (objectType KeyChain_bar__minus_02_dot_34_bar__plus_00_dot_04_bar__plus_02_dot_63 KeyChainType)
        (objectType CD_bar__minus_01_dot_34_bar__plus_01_dot_35_bar__plus_00_dot_41 CDType)
        (objectType Mirror_bar__minus_01_dot_36_bar__plus_01_dot_43_bar__plus_02_dot_86 MirrorType)
        (objectType DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75 DeskLampType)
        (objectType Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_01_dot_95 LaptopType)
        (objectType Pencil_bar__minus_01_dot_39_bar__plus_01_dot_73_bar__plus_00_dot_45 PencilType)
        (objectType Blinds_bar__minus_00_dot_40_bar__plus_02_dot_16_bar__minus_01_dot_92 BlindsType)
        (objectType Window_bar__minus_00_dot_42_bar__plus_01_dot_53_bar__minus_01_dot_95 WindowType)
        (objectType Pencil_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_67 PencilType)
        (objectType Window_bar__plus_00_dot_58_bar__plus_01_dot_53_bar__minus_01_dot_95 WindowType)
        (objectType AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58 AlarmClockType)
        (objectType KeyChain_bar__minus_02_dot_07_bar__plus_00_dot_39_bar__plus_00_dot_68 KeyChainType)
        (objectType Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66 BowlType)
        (objectType Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66 BowlType)
        (objectType Pillow_bar__plus_01_dot_12_bar__plus_00_dot_87_bar__plus_02_dot_46 PillowType)
        (objectType Book_bar__plus_00_dot_60_bar__plus_00_dot_78_bar__plus_01_dot_66 BookType)
        (objectType BaseballBat_bar__plus_01_dot_95_bar__plus_00_dot_66_bar__minus_01_dot_81 BaseballBatType)
        (objectType CD_bar__minus_00_dot_79_bar__plus_00_dot_20_bar__minus_00_dot_31 CDType)
        (objectType LaundryHamperLid_bar__plus_00_dot_16_bar__plus_00_dot_48_bar__plus_02_dot_64 LaundryHamperLidType)
        (objectType Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_00_dot_79 LaptopType)
        (objectType Pillow_bar__plus_01_dot_41_bar__plus_00_dot_92_bar__plus_01_dot_95 PillowType)
        (objectType CellPhone_bar__minus_02_dot_03_bar__plus_00_dot_04_bar__plus_02_dot_63 CellPhoneType)
        (objectType Chair_bar__minus_00_dot_13_bar__plus_00_dot_53_bar__minus_01_dot_58 ChairType)
        (objectType CreditCard_bar__minus_00_dot_51_bar__plus_00_dot_36_bar__minus_01_dot_01 CreditCardType)
        (objectType CD_bar__minus_00_dot_47_bar__plus_00_dot_08_bar__minus_01_dot_09 CDType)
        (objectType AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58 AlarmClockType)
        (objectType Blinds_bar__plus_00_dot_60_bar__plus_02_dot_16_bar__minus_01_dot_92 BlindsType)
        (objectType Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01 MugType)
        (objectType Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83 MugType)
        (objectType Chair_bar__minus_01_dot_42_bar__plus_00_dot_53_bar__plus_00_dot_80 ChairType)
        (objectType Pen_bar__minus_01_dot_73_bar__plus_01_dot_73_bar__plus_00_dot_37 PenType)
        (objectType BasketBall_bar__plus_01_dot_98_bar__plus_00_dot_12_bar__plus_00_dot_21 BasketBallType)
        (objectType Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37 BowlType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain DeskType LaptopType)
        (canContain DeskType AlarmClockType)
        (canContain DeskType PenType)
        (canContain DeskType CellPhoneType)
        (canContain DeskType BowlType)
        (canContain DeskType CreditCardType)
        (canContain DeskType CDType)
        (canContain DeskType PencilType)
        (canContain DeskType KeyChainType)
        (canContain DeskType MugType)
        (canContain DeskType BasketBallType)
        (canContain DeskType BookType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain DrawerType PenType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType CDType)
        (canContain DrawerType PencilType)
        (canContain DrawerType KeyChainType)
        (canContain DrawerType BookType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain SafeType CellPhoneType)
        (canContain SafeType KeyChainType)
        (canContain SafeType CreditCardType)
        (canContain SafeType CDType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain GarbageCanType PenType)
        (canContain GarbageCanType CDType)
        (canContain GarbageCanType PencilType)
        (canContain BedType CellPhoneType)
        (canContain BedType BaseballBatType)
        (canContain BedType PillowType)
        (canContain BedType LaptopType)
        (canContain BedType BasketBallType)
        (canContain BedType BookType)
        (canContain ShelfType AlarmClockType)
        (canContain ShelfType PenType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType CDType)
        (canContain ShelfType PencilType)
        (canContain ShelfType KeyChainType)
        (canContain ShelfType MugType)
        (canContain ShelfType BookType)
        (canContain DeskType LaptopType)
        (canContain DeskType AlarmClockType)
        (canContain DeskType PenType)
        (canContain DeskType CellPhoneType)
        (canContain DeskType BowlType)
        (canContain DeskType CreditCardType)
        (canContain DeskType CDType)
        (canContain DeskType PencilType)
        (canContain DeskType KeyChainType)
        (canContain DeskType MugType)
        (canContain DeskType BasketBallType)
        (canContain DeskType BookType)
        (pickupable Pillow_bar__plus_01_dot_21_bar__plus_00_dot_92_bar__plus_01_dot_37)
        (pickupable KeyChain_bar__minus_02_dot_34_bar__plus_00_dot_04_bar__plus_02_dot_63)
        (pickupable CD_bar__minus_01_dot_34_bar__plus_01_dot_35_bar__plus_00_dot_41)
        (pickupable Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_01_dot_95)
        (pickupable Pencil_bar__minus_01_dot_39_bar__plus_01_dot_73_bar__plus_00_dot_45)
        (pickupable Pencil_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_67)
        (pickupable AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58)
        (pickupable KeyChain_bar__minus_02_dot_07_bar__plus_00_dot_39_bar__plus_00_dot_68)
        (pickupable Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (pickupable Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (pickupable Pillow_bar__plus_01_dot_12_bar__plus_00_dot_87_bar__plus_02_dot_46)
        (pickupable Book_bar__plus_00_dot_60_bar__plus_00_dot_78_bar__plus_01_dot_66)
        (pickupable BaseballBat_bar__plus_01_dot_95_bar__plus_00_dot_66_bar__minus_01_dot_81)
        (pickupable CD_bar__minus_00_dot_79_bar__plus_00_dot_20_bar__minus_00_dot_31)
        (pickupable Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_00_dot_79)
        (pickupable Pillow_bar__plus_01_dot_41_bar__plus_00_dot_92_bar__plus_01_dot_95)
        (pickupable CellPhone_bar__minus_02_dot_03_bar__plus_00_dot_04_bar__plus_02_dot_63)
        (pickupable CreditCard_bar__minus_00_dot_51_bar__plus_00_dot_36_bar__minus_01_dot_01)
        (pickupable CD_bar__minus_00_dot_47_bar__plus_00_dot_08_bar__minus_01_dot_09)
        (pickupable AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58)
        (pickupable Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01)
        (pickupable Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83)
        (pickupable Pen_bar__minus_01_dot_73_bar__plus_01_dot_73_bar__plus_00_dot_37)
        (pickupable BasketBall_bar__plus_01_dot_98_bar__plus_00_dot_12_bar__plus_00_dot_21)
        (pickupable Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37)
        (isReceptacleObject Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (isReceptacleObject Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (isReceptacleObject Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01)
        (isReceptacleObject Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83)
        (isReceptacleObject Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37)
        (openable Drawer_bar__minus_00_dot_51_bar__plus_00_dot_19_bar__minus_00_dot_85)
        (openable Drawer_bar__minus_02_dot_07_bar__plus_00_dot_74_bar__plus_00_dot_73)
        (openable Drawer_bar__minus_00_dot_51_bar__plus_00_dot_72_bar__minus_00_dot_85)
        (openable Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58)
        
        (atLocation agent1 loc_bar__minus_1_bar_4_bar_2_bar_30)
        
        (cleanable Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (cleanable Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (cleanable Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01)
        (cleanable Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83)
        (cleanable Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37)
        
        (heatable Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01)
        (heatable Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83)
        (coolable Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (coolable Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66)
        (coolable Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01)
        (coolable Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83)
        (coolable Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37)
        
        
        (toggleable DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75)
        
        
        
        
        (inReceptacle Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83 Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67)
        (inReceptacle Pencil_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_67 Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67)
        (inReceptacle AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58 Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67)
        (inReceptacle DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75 Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67)
        (inReceptacle AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58 Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67)
        (inReceptacle CreditCard_bar__minus_00_dot_51_bar__plus_00_dot_36_bar__minus_01_dot_01 Drawer_bar__minus_00_dot_51_bar__plus_00_dot_47_bar__minus_00_dot_85)
        (inReceptacle KeyChain_bar__minus_02_dot_07_bar__plus_00_dot_39_bar__plus_00_dot_68 Drawer_bar__minus_02_dot_07_bar__plus_00_dot_49_bar__plus_00_dot_73)
        (inReceptacle Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01 Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35)
        (inReceptacle Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66 Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35)
        (inReceptacle Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66 Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35)
        (inReceptacle CD_bar__minus_00_dot_47_bar__plus_00_dot_08_bar__minus_01_dot_09 Drawer_bar__minus_00_dot_51_bar__plus_00_dot_19_bar__minus_00_dot_85)
        (inReceptacle Pillow_bar__plus_01_dot_21_bar__plus_00_dot_92_bar__plus_01_dot_37 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle Book_bar__plus_00_dot_60_bar__plus_00_dot_78_bar__plus_01_dot_66 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_00_dot_79 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle Pillow_bar__plus_01_dot_41_bar__plus_00_dot_92_bar__plus_01_dot_95 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_01_dot_95 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle Pillow_bar__plus_01_dot_12_bar__plus_00_dot_87_bar__plus_02_dot_46 Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67)
        (inReceptacle CD_bar__minus_00_dot_79_bar__plus_00_dot_20_bar__minus_00_dot_31 GarbageCan_bar__minus_00_dot_75_bar__plus_00_dot_00_bar__minus_00_dot_34)
        (inReceptacle Pencil_bar__minus_01_dot_39_bar__plus_01_dot_73_bar__plus_00_dot_45 Shelf_bar__minus_01_dot_29_bar__plus_01_dot_72_bar__plus_00_dot_41)
        (inReceptacle Pen_bar__minus_01_dot_73_bar__plus_01_dot_73_bar__plus_00_dot_37 Shelf_bar__minus_01_dot_96_bar__plus_01_dot_72_bar__plus_00_dot_41)
        (inReceptacle Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37 Shelf_bar__minus_01_dot_96_bar__plus_01_dot_34_bar__plus_00_dot_41)
        (inReceptacle AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58 Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41)
        (inReceptacle DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75 Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41)
        (inReceptacle AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58 Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41)
        (inReceptacle CellPhone_bar__minus_02_dot_03_bar__plus_00_dot_04_bar__plus_02_dot_63 Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58)
        (inReceptacle KeyChain_bar__minus_02_dot_34_bar__plus_00_dot_04_bar__plus_02_dot_63 Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58)
        
        
        (receptacleAtLocation Bed_bar__plus_01_dot_23_bar__plus_00_dot_00_bar__plus_01_dot_67 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (receptacleAtLocation Desk_bar__minus_00_dot_57_bar__plus_00_dot_00_bar__minus_01_dot_35 loc_bar_1_bar__minus_5_bar_3_bar_60)
        (receptacleAtLocation Desk_bar__minus_01_dot_58_bar__plus_00_dot_02_bar__plus_00_dot_67 loc_bar__minus_1_bar_3_bar_3_bar_45)
        (receptacleAtLocation Drawer_bar__minus_00_dot_51_bar__plus_00_dot_19_bar__minus_00_dot_85 loc_bar_2_bar__minus_6_bar_3_bar_60)
        (receptacleAtLocation Drawer_bar__minus_00_dot_51_bar__plus_00_dot_47_bar__minus_00_dot_85 loc_bar_0_bar__minus_3_bar_3_bar_60)
        (receptacleAtLocation Drawer_bar__minus_00_dot_51_bar__plus_00_dot_72_bar__minus_00_dot_85 loc_bar_1_bar__minus_5_bar_3_bar_45)
        (receptacleAtLocation Drawer_bar__minus_02_dot_07_bar__plus_00_dot_21_bar__plus_00_dot_73 loc_bar__minus_8_bar_5_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__minus_02_dot_07_bar__plus_00_dot_49_bar__plus_00_dot_73 loc_bar__minus_8_bar_5_bar_2_bar_60)
        (receptacleAtLocation Drawer_bar__minus_02_dot_07_bar__plus_00_dot_74_bar__plus_00_dot_73 loc_bar__minus_5_bar_6_bar_3_bar_45)
        (receptacleAtLocation GarbageCan_bar__minus_00_dot_75_bar__plus_00_dot_00_bar__minus_00_dot_34 loc_bar_1_bar_0_bar_3_bar_60)
        (receptacleAtLocation LaundryHamper_bar__plus_00_dot_16_bar__plus_00_dot_01_bar__plus_02_dot_64 loc_bar_0_bar_9_bar_0_bar_60)
        (receptacleAtLocation Safe_bar__minus_02_dot_18_bar__plus_00_dot_00_bar__plus_02_dot_58 loc_bar__minus_4_bar_8_bar_3_bar_60)
        (receptacleAtLocation Shelf_bar__minus_01_dot_29_bar__plus_00_dot_87_bar__plus_00_dot_41 loc_bar__minus_4_bar_6_bar_2_bar_30)
        (receptacleAtLocation Shelf_bar__minus_01_dot_29_bar__plus_01_dot_34_bar__plus_00_dot_41 loc_bar__minus_2_bar_2_bar_3_bar_15)
        (receptacleAtLocation Shelf_bar__minus_01_dot_29_bar__plus_01_dot_72_bar__plus_00_dot_41 loc_bar__minus_4_bar_5_bar_2_bar_0)
        (receptacleAtLocation Shelf_bar__minus_01_dot_96_bar__plus_00_dot_87_bar__plus_00_dot_41 loc_bar__minus_7_bar_6_bar_2_bar_30)
        (receptacleAtLocation Shelf_bar__minus_01_dot_96_bar__plus_01_dot_34_bar__plus_00_dot_41 loc_bar__minus_3_bar_4_bar_3_bar_15)
        (receptacleAtLocation Shelf_bar__minus_01_dot_96_bar__plus_01_dot_72_bar__plus_00_dot_41 loc_bar__minus_7_bar_5_bar_2_bar_0)
        (objectAtLocation Mug_bar__minus_00_dot_65_bar__plus_00_dot_86_bar__minus_01_dot_01 loc_bar_1_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Pencil_bar__minus_01_dot_39_bar__plus_01_dot_73_bar__plus_00_dot_45 loc_bar__minus_4_bar_5_bar_2_bar_0)
        (objectAtLocation CD_bar__minus_01_dot_34_bar__plus_01_dot_35_bar__plus_00_dot_41 loc_bar__minus_2_bar_2_bar_3_bar_15)
        (objectAtLocation KeyChain_bar__minus_02_dot_34_bar__plus_00_dot_04_bar__plus_02_dot_63 loc_bar__minus_4_bar_8_bar_3_bar_60)
        (objectAtLocation Pillow_bar__plus_01_dot_12_bar__plus_00_dot_87_bar__plus_02_dot_46 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation Bowl_bar__minus_00_dot_82_bar__plus_00_dot_86_bar__minus_00_dot_66 loc_bar_1_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_01_dot_95 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation AlarmClock_bar__minus_02_dot_27_bar__plus_00_dot_88_bar__plus_00_dot_58 loc_bar__minus_7_bar_6_bar_2_bar_30)
        (objectAtLocation Pillow_bar__plus_01_dot_21_bar__plus_00_dot_92_bar__plus_01_dot_37 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation CD_bar__minus_00_dot_79_bar__plus_00_dot_20_bar__minus_00_dot_31 loc_bar_1_bar_0_bar_3_bar_60)
        (objectAtLocation Bowl_bar__minus_00_dot_57_bar__plus_00_dot_86_bar__minus_00_dot_66 loc_bar_1_bar__minus_5_bar_3_bar_60)
        (objectAtLocation Chair_bar__minus_01_dot_42_bar__plus_00_dot_53_bar__plus_00_dot_80 loc_bar__minus_7_bar_5_bar_2_bar_60)
        (objectAtLocation Book_bar__plus_00_dot_60_bar__plus_00_dot_78_bar__plus_01_dot_66 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation LaundryHamperLid_bar__plus_00_dot_16_bar__plus_00_dot_48_bar__plus_02_dot_64 loc_bar_0_bar_9_bar_0_bar_60)
        (objectAtLocation Chair_bar__minus_00_dot_13_bar__plus_00_dot_53_bar__minus_01_dot_58 loc_bar_2_bar__minus_6_bar_3_bar_60)
        (objectAtLocation LightSwitch_bar__plus_02_dot_15_bar__plus_01_dot_23_bar__minus_00_dot_52 loc_bar_6_bar__minus_2_bar_1_bar_30)
        (objectAtLocation AlarmClock_bar__minus_02_dot_09_bar__plus_00_dot_88_bar__plus_00_dot_58 loc_bar__minus_7_bar_6_bar_2_bar_30)
        (objectAtLocation BasketBall_bar__plus_01_dot_98_bar__plus_00_dot_12_bar__plus_00_dot_21 loc_bar_6_bar_0_bar_1_bar_60)
        (objectAtLocation Pen_bar__minus_01_dot_73_bar__plus_01_dot_73_bar__plus_00_dot_37 loc_bar__minus_7_bar_5_bar_2_bar_0)
        (objectAtLocation Laptop_bar__plus_00_dot_80_bar__plus_00_dot_78_bar__plus_00_dot_79 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation BaseballBat_bar__plus_01_dot_95_bar__plus_00_dot_66_bar__minus_01_dot_81 loc_bar_6_bar__minus_5_bar_2_bar_60)
        (objectAtLocation Bowl_bar__minus_02_dot_05_bar__plus_01_dot_35_bar__plus_00_dot_37 loc_bar__minus_3_bar_4_bar_3_bar_15)
        (objectAtLocation Pillow_bar__plus_01_dot_41_bar__plus_00_dot_92_bar__plus_01_dot_95 loc_bar__minus_1_bar_6_bar_1_bar_45)
        (objectAtLocation KeyChain_bar__minus_02_dot_07_bar__plus_00_dot_39_bar__plus_00_dot_68 loc_bar__minus_8_bar_5_bar_2_bar_60)
        (objectAtLocation CreditCard_bar__minus_00_dot_51_bar__plus_00_dot_36_bar__minus_01_dot_01 loc_bar_0_bar__minus_3_bar_3_bar_60)
        (objectAtLocation CellPhone_bar__minus_02_dot_03_bar__plus_00_dot_04_bar__plus_02_dot_63 loc_bar__minus_4_bar_8_bar_3_bar_60)
        (objectAtLocation Mirror_bar__minus_01_dot_36_bar__plus_01_dot_43_bar__plus_02_dot_86 loc_bar__minus_5_bar_9_bar_0_bar_15)
        (objectAtLocation DeskLamp_bar__minus_02_dot_30_bar__plus_00_dot_87_bar__plus_00_dot_75 loc_bar__minus_7_bar_6_bar_2_bar_30)
        (objectAtLocation CD_bar__minus_00_dot_47_bar__plus_00_dot_08_bar__minus_01_dot_09 loc_bar_2_bar__minus_6_bar_3_bar_60)
        (objectAtLocation Window_bar__minus_00_dot_42_bar__plus_01_dot_53_bar__minus_01_dot_95 loc_bar_2_bar__minus_6_bar_3_bar_0)
        (objectAtLocation Window_bar__plus_00_dot_58_bar__plus_01_dot_53_bar__minus_01_dot_95 loc_bar_2_bar__minus_5_bar_2_bar_15)
        (objectAtLocation Pencil_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_67 loc_bar__minus_1_bar_3_bar_3_bar_45)
        (objectAtLocation Mug_bar__minus_01_dot_74_bar__plus_00_dot_88_bar__plus_00_dot_83 loc_bar__minus_1_bar_3_bar_3_bar_45)
        (objectAtLocation Blinds_bar__plus_00_dot_60_bar__plus_02_dot_16_bar__minus_01_dot_92 loc_bar_2_bar__minus_6_bar_2_bar__minus_30)
        (objectAtLocation Blinds_bar__minus_00_dot_40_bar__plus_02_dot_16_bar__minus_01_dot_92 loc_bar_2_bar__minus_6_bar_3_bar__minus_30)
        )
    

        (:goal
             (and
                 (exists (?ot - object
                          ?r - receptacle
                          ?a - agent
                          ?l - location)
                     (and
                         (objectType ?ot DeskLampType)
                         (toggleable ?ot)
                         (isToggled ?ot)
                         (receptacleAtLocation ?r ?l)
                         (atLocation ?a ?l)
                         (inReceptacle ?ot ?r)
                     )
                 )
                 (exists (?o - object
                          ?a - agent)
                     (and
                         (objectType ?o BowlType)
                         (holds ?a ?o)
                     )
                 )
             )
        )
    )
    